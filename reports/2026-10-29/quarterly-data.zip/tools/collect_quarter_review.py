"""Archive dated fund quarterly disclosures, preserving identity and PDF page evidence."""
import argparse
import hashlib
import json
import re
from datetime import datetime
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

from archive_deep_sources import archive

ROOT = Path(__file__).resolve().parents[1]


def title_matches(title, quarter):
    normalized = title.replace("二0二六", "2026").replace("二〇二六", "2026")
    return bool(re.search(r"2026年?第?" + quarter + r"季度报告$", normalized)) and "提示" not in title


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--codes", required=True)
    parser.add_argument("--quarters", default="1,2,3")
    args = parser.parse_args()
    today = datetime.now(ZoneInfo("Asia/Shanghai")).date().isoformat()
    directory = ROOT / "data/quarter_review" / today
    directory.mkdir(parents=True, exist_ok=True)
    for code in args.codes.split(","):
        assert re.fullmatch(r"\d{6}", code)
        folder = directory / code
        folder.mkdir(exist_ok=True)
        records = []
        for page in range(1, 4):
            url = "https://api.fund.eastmoney.com/f10/JJGG?" + urlencode(
                {"fundcode": code, "pageIndex": page, "pageSize": 100, "type": 0}
            )
            request = Request(url, headers={"User-Agent": "Mozilla/5.0",
                                          "Referer": "https://fund.eastmoney.com/"})
            with urlopen(request, timeout=30) as response:
                raw = response.read()
            (folder / f"index-{page}.json").write_bytes(raw)
            data = json.loads(raw)
            records.extend(r for r in data["Data"] if r.get("FUNDCODE") == code)
            if all(any(title_matches(r["TITLE"], q) for r in records)
                   for q in args.quarters.split(",")):
                break
            if page * 100 >= data["TotalCount"]:
                break
        result = []
        for quarter in args.quarters.split(","):
            matches = [r for r in records
                       if title_matches(r["TITLE"], quarter)
                       and r["PUBLISHDATE"][:10] <= today]
            if not matches:
                result.append({"quarter": quarter, "status": "not_found", "code": code})
                continue
            record = max(matches, key=lambda r: r["PUBLISHDATE"])
            article = record["ID"]
            assert re.fullmatch(r"AN\d+", article)
            item = {"id": article, "code": code, "quarter": quarter,
                    "title": record["TITLE"], "published_on": record["PUBLISHDATE"][:10],
                    "holdings_asof": {"1": "2026-03-31", "2": "2026-06-30",
                                     "3": "2026-09-30"}[quarter],
                    "url": f"https://pdf.dfcfw.com/pdf/H2_{article}_1.pdf",
                    "index_url": url}
            try:
                row = archive(item, folder, pdf=True)
                pages = json.loads((folder / (article + ".text.json")).read_text())
                text = "\n\n".join(f'--- PDF PAGE {p["page"]} ---\n{p["text"] or ""}'
                                   for p in pages)
                assert code in re.sub(r"\s+", "", text), "Fund share code absent in report"
                (folder / f"Q{quarter}.txt").write_text(text)
                row["sha256"] = hashlib.sha256((folder / (article + ".pdf")).read_bytes()).hexdigest()
                row["text_file"] = str((folder / f"Q{quarter}.txt").relative_to(ROOT))
            except Exception as exc:
                row = {**item, "status": "failed", "error": str(exc)}
            result.append(row)
            print(code, quarter, row["status"], row["published_on"], flush=True)
        (folder / "manifest.json").write_text(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
