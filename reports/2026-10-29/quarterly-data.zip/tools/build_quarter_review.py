"""Build the dated manager review from archived disclosures and independently checked calculations."""
import hashlib
import json
import zipfile
from html import escape as esc
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATE = "2026-10-29"
BASE = ROOT / "data/quarter_review" / DATE
R = json.loads((ROOT / f"research/quarter_review_{DATE}.json").read_text())
for row in R["funds"] + R["watch"]:
    if row["code"] in R.get("manager_names", {}):
        row["manager"] = R["manager_names"][row["code"]]
A = json.loads((BASE / "analysis.json").read_text())
F = json.loads((ROOT / f"data/ideal_review/{DATE}/forward.json").read_text())
POLICY = json.loads((ROOT / f"research/ideal_policy_{DATE}.json").read_text())
weights = {p["code"]: p["amount_cny"] / POLICY["total_cny"] for p in POLICY["positions"]}
main_codes = [p["code"] for p in R["funds"][:7]]
assert all(r["passed"] for r in A["nav_disclosure_checks"])
assert len(A["funds"]) == 15


def pct(v, scale=1):
    return "—" if v is None else f"{v * scale:+.2f}%"


def table(headers, rows):
    return '<div class="scroll"><table><thead><tr>' + "".join(f"<th>{esc(h)}</th>" for h in headers) + \
        "</tr></thead><tbody>" + "".join("<tr>" + "".join(f"<td>{esc(str(v))}</td>" for v in r) +
                                       "</tr>" for r in rows) + "</tbody></table></div>"


def mdtable(headers, rows):
    return ["| " + " | ".join(headers) + " |", "|" + "|".join(["---"] * len(headers)) + "|"] + \
        ["| " + " | ".join(str(v).replace("|", "/") for v in r) + " |" for r in rows]


summary = []
for fund in R["funds"]:
    c = fund["code"]
    q = A["funds"][c]["3"]
    obs = A["behavior"][c]["periods"]["October"]
    summary.append([fund["name"], fund["judgment"], pct(q["quarter_return_pct"]),
                    pct(q["benchmark_return_pct"]), pct(obs["return"], 100),
                    f'{q["stock_pct_net"]:.2f}%' if c not in ["002611", "006075"] else "ETF联接"])
size_rows = []
for fund in R["funds"][:7]:
    d = A["funds"][fund["code"]]
    size_rows.append([fund["name"], *[f'{d[q]["stock_pct_net"]:.2f}%' for q in ["1", "2", "3"]],
                      f'{d["2"]["nav_cny"]/1e8:.2f} → {d["3"]["nav_cny"]/1e8:.2f}亿元'])

# Visible holdings only: a lower bound on stock exposure, not a bound on total portfolio losses.
groups = {
    "光通信": {"300502", "300308", "300394", "688498", "688048", "688313"},
    "半导体/网络/液冷/元件": {"688072", "688012", "688256", "002837", "002396", "000938",
                           "300408", "688020", "000063", "600183", "000636", "002384", "603256"},
    "创新药/CXO": {"688235", "600276", "603259", "300759"},
    "煤炭/有色/金矿": {"601899", "600188", "01171", "601168", "603979", "600348", "601699",
                     "600123", "600546", "601898", "600489"}
}
visible = []
for name, members in groups.items():
    contributions = {c: weights[c] * sum(h["weight_pct"] / 100 for h in A["funds"][c]["3"]["top10"]
                                       if h["code"] in members) for c in main_codes}
    total = sum(contributions.values())
    visible.append({"name": name, "target_weight": total, "shock": -.2,
                    "target_impact": -.2 * total, "impact_cny": -.2 * total * POLICY["total_cny"],
                    "contributions": contributions})
visible_rows = [[r["name"], f'{r["target_weight"]*100:.2f}%',
                 pct(r["target_impact"], 100), f'{r["impact_cny"]/10000:.2f}万元'] for r in visible]
cash_cny = sum(weights[c] * A["funds"][c]["3"]["cash_pct_net"] / 100 * POLICY["total_cny"]
               for c in ["021902", "519697"])
cash_note = f"仅广发主题与交银优势两只，按截图目标映射的基金内部银行存款和结算备付金约{cash_cny/10000:.2f}万元，占目标{cash_cny/POLICY['total_cny']*100:.2f}%。这是9月30日结构映射，不是你的账户现金，也不是全组合现金总额。"
shared = "产业与广发十大可见重合由0增至4.17%；科益与华商由9.49%至10.14%，但行业和风险强度仍不同。该指标为两只基金已披露股票权重逐只取较小值后加总，十大之外未知，不能把0当作完全不重叠。"

parts = [f"<p class='eyebrow'>2026 Q3 / {DATE}</p><h1>{esc(R['title'])}</h1>",
         f"<p class='lead'>{esc(R['verdict'])}</p><p class='muted'>{esc(R['scope'])}</p>",
         '<nav><a href="index.html">本日完整报告</a><a href="quarterly.md">下载研究正文</a><a href="quarterly-data.zip">证据与计算</a><a href="../../archive.html">日期档案</a></nav>',
         '<section class="cards">' + "".join(f"<article><h3>{esc(h['title'])}</h3><p>{esc(h['text'])}</p></article>" for h in R["highlights"]) + "</section>",
         "<h2>经理质地与职责：这次改什么</h2>", table(["基金", "新判断", "三季度", "本基金基准", "10月以来", "期末股票/净值"], summary),
         "<p class='muted'>收益统一使用C类，交银优势与低碳没有核实独立C类。10月以来截至境内10月28日、QDII10月27日；不同基金的合同基准不可直接横比超额。</p>",
         "<h2>三次披露，把低仓位与低风险分开</h2><div id='allocation-chart' class='chart' aria-label='一至三季度股票净资产占比'></div>",
         table(["基金", "一季度", "二季度", "三季度", "二→三季度总规模"], size_rows),
         f"<p>{esc(cash_note)}</p>",
         "<h2>净值是否支持持仓变化</h2><label>基金 <select id='behavior-fund'>" +
         "".join(f"<option value='{f['code']}'>{esc(f['name'])}</option>" for f in R["funds"][:7]) +
         "</select></label><div id='behavior-chart' class='chart' aria-label='二季度三季度与10月的日收益相关'></div>",
         "<p class='muted'>各基金与各参照按共同正式估值日计算，单因子相关不等于持仓占比或alpha。二、三季度是独立日历区间，10月仅15个境内观察日；披露后样本不足以检验预测。</p>",
         "<h2>共同风险已经发生迁移</h2>", table(["七只境内基金十大可见部分", "占246.80万目标", "该组单独−20%的贡献", "目标金额映射"], visible_rows),
         "<p class='muted'>已披露权重映射，股票按公司经营领域归组，不代表收入全来自该领域。其余资产假设不变，未计个股差异和经理后续交易；这是局部冲击敏感性，不是全组合预测或损失下限。每组分别冲击，不叠加。</p>",
         f"<p>{esc(shared)}</p><h2>逐只经理：支持证据、反证、未来用途</h2>"]
md = [f"# {R['title']} · {DATE}", "", R["verdict"], "", R["scope"], "", R["limitations"], "",
      "## 经理质地与职责", ""] + mdtable(["基金", "新判断", "三季度", "本基金基准", "10月以来", "股票/净值"], summary)
md += ["", "## 三期结构与规模", ""] + mdtable(["基金", "一季度", "二季度", "三季度", "规模"], size_rows)
md += ["", cash_note, "", "## 十大已披露部分的局部敏感性", ""] + mdtable(["可见部分", "占目标", "单独−20%贡献", "金额"], visible_rows)
md += ["", "其余资产假设不变，是局部冲击贡献，不是全组合预测或损失下限。每组分别冲击，不叠加。", shared, ""]
for fund in R["funds"]:
    code = fund["code"]
    docs = A["funds"][code]
    links = " · ".join(f'<a href="{esc(v["url"])}" target="_blank" rel="noopener">Q{q}原文</a>' for q, v in docs.items())
    body = f"<p class='role'>{esc(fund['role'])} · {esc(fund['quality'])}</p>"
    md += [f"## {fund['name']} · {fund['manager']}", "", fund["judgment"], "", fund["quality"], ""]
    for key, label in [("evidence", "支持证据"), ("counter", "反证与限制"),
                       ("future", "未来几周的用途"), ("falsifier", "何时改判")]:
        body += f"<p><b>{label}</b>　{esc(fund[key])}</p>"
        md += [f"**{label}**：{fund[key]}", ""]
    parts.append(f"<details class='fund-review' id='fund-{code}'><summary><strong>{esc(fund['name'])}</strong> · {esc(fund['judgment'])}<small>{esc(fund['manager'])}</small></summary>{body}<p>{links}</p></details>")
    md += [" · ".join(f'[Q{q}原文]({v["url"]})' for q, v in docs.items()), ""]
parts.append("<h2>今天落地的证据与未来几周</h2>")
md += ["## 宏观与产业新证据", ""]
for event in R["macro"]:
    parts.append(f"<article class='macro'><h3><a href='{esc(event['url'])}'>{esc(event['title'])} ↗</a></h3><p>{esc(event['text'])}</p><small>{esc(event['date'])} · {esc(event['grade'])}</small></article>")
    md += [f"### [{event['title']}]({event['url']})", "", event["text"], "", event["grade"], ""]
scenario_rows = [[s["name"], s["signals"], s["impact"], s["action"]] for s in R["scenarios"]]
parts.append(table(["分支", "需要核实的信号", "组合关系", "处理"], scenario_rows))
md += ["## 条件分支", ""] + mdtable(["分支", "信号", "组合关系", "处理"], scenario_rows)
target = next(r for r in F["robust"] if r["id"] == "target")
odds = f"更新因子后的目标20日期望响应，在冻结人工权重范围内为{pct(target['mean_range'][0],100)}至{pct(target['mean_range'][1],100)}，条件盈亏比{target['gain_loss_ratio_range'][0]:.2f}—{target['gain_loss_ratio_range'][1]:.2f}。不是实际期望收益预测，也不是市场真实赔率；新旧模型结果不直接可比。"
parts += [f"<p class='callout'>{esc(odds)}</p><p><a href='index.html#forward'>查看全部路径、尾部与方案敏感性 ↗</a></p>",
          "<h2>旧仓与观察项</h2>", table(["基金 / 经理", "新判断", "依据"], [[r["name"]+" / "+r.get("manager",""), r["verdict"], r["text"]] for r in R["watch"]]),
          f"<h2>当前处理倾向</h2><p class='lead'>{esc(R['decision'])}</p>",
          "<h2>判据与追溯</h2>" + "".join(f"<p>{esc(s)}</p>" for s in R["review_rules"]),
          f"<p class='muted'>{esc(R['limitations'])}</p>"]
md += ["", odds, "", "## 旧仓与观察项", ""] + mdtable(["基金 / 经理", "判断", "依据"], [[r["name"]+" / "+r.get("manager",""), r["verdict"], r["text"]] for r in R["watch"]])
md += ["", "## 处理倾向", "", R["decision"], "", "## 判据与追溯", ""] + R["review_rules"]
documents = [d for qs in A["funds"].values() for d in qs.values()]
parts.append(f"<p class='muted'>{len(documents)}份报告均保留原文链接、页码与SHA-256；{len(A['nav_disclosure_checks'])}个完整季度收益与正式净值重建一致（允许公开净值舍入）。微软网页读取成功但本地全文归档失败，已单列。</p>")
parts.append("<details><summary>全部季度原文与哈希</summary>" + table(["基金代码", "季度", "发布日期", "SHA-256"], [[d["code"], "Q"+d["quarter"], d["published_on"], d["sha256"]] for d in documents]) + "</details>")
md += ["", "## 季度原文", ""] + [f'- [{d["code"]} Q{d["quarter"]}]({d["url"]})，披露{d["published_on"]}，SHA-256 `{d["sha256"]}`' for d in documents]
payload = {"review": R, "analysis": A, "visible_sensitivity": visible, "internal_cash_cny_two_funds": cash_cny,
           "forward": {"model": F["estimation"], "target_robust": target}, "main_codes": main_codes}
(BASE / "review.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2))
(BASE / "review.md").write_text("\n".join(md))
css = """*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:#0a0d0f;color:#e8edeb;font:15px/1.8 -apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif}main{max-width:1180px;margin:auto;padding:48px 32px 100px}h1{font-size:46px;line-height:1.2;letter-spacing:-.03em}h2{font-size:26px;margin-top:64px}h3{font-size:19px}a{color:#99ddc3;text-underline-offset:4px}.eyebrow,small,.muted{color:#95a29e;font-size:12px}.lead{font-size:19px;color:#d5e7df}.cards{display:grid;grid-template-columns:1fr 1fr;gap:28px;margin:36px 0}.cards article,.macro{border-top:1px solid #41584f;padding:12px 0}nav{display:flex;gap:24px;flex-wrap:wrap;margin:25px 0}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:13px}td,th{text-align:left;vertical-align:top;padding:14px 12px;border-bottom:1px solid #26322d;min-width:95px}th{color:#90aa9d;font-weight:500}td:nth-child(2){min-width:150px}.chart{height:460px}.fund-review{border-top:1px solid #2b3a34;padding:20px 0}summary{cursor:pointer;color:#c4d6ce}summary small{display:block;margin-top:6px}.fund-review p{max-width:950px}.role{color:#98c5b1}select{color:#e8edeb;background:#152019;border:1px solid #486052;padding:8px;font:inherit}.callout{border-left:2px solid #ceba82;padding:15px 22px;background:#c6a9720b}b{color:#c6d9d0}@media(max-width:760px){main{padding:28px 20px 70px}h1{font-size:34px}h2{font-size:23px;margin-top:45px}.cards{grid-template-columns:1fr;gap:8px}.lead{font-size:17px}.chart{height:490px}table{font-size:12px}td,th{padding:10px 8px}}"""
js = """
const charts=[];
const fundNames=Q.main_codes.map(c=>Q.review.funds.find(f=>f.code===c).name.replace('易方达','').replace('混合',''));
const axis={axisLine:{lineStyle:{color:'#42574d'}},axisLabel:{color:'#acbeb5'},splitLine:{lineStyle:{color:'#202e27'}}};
function mount(id,option){const c=echarts.init(document.getElementById(id));c.setOption(option);charts.push(c);return c}
mount('allocation-chart',{tooltip:{trigger:'axis'},legend:{textStyle:{color:'#bacdc3'}},grid:{left:140,right:30,top:50,bottom:30},xAxis:{...axis,type:'value',max:100,name:'股票/净资产 %'},yAxis:{...axis,type:'category',data:fundNames,inverse:true},series:['1','2','3'].map((q,i)=>({name:['一季度','二季度','三季度'][i],type:'bar',itemStyle:{color:['#46695b','#83ad99','#d5c391'][i]},data:Q.main_codes.map(c=>Q.analysis.funds[c][q].stock_pct_net.toFixed(2))}))});
const b=mount('behavior-chart',{});
function behavior(){const c=document.getElementById('behavior-fund').value,keys=['communication','semiconductor','metals','dividend'];b.setOption({tooltip:{trigger:'axis'},legend:{textStyle:{color:'#bacdc3'}},grid:{left:52,right:25,top:55,bottom:40},xAxis:{...axis,type:'category',data:['通信','半导体','有色','红利']},yAxis:{...axis,type:'value',min:-1,max:1},series:['Q2','Q3','October'].map((q,i)=>({name:['二季度','三季度','10月'][i],type:'bar',itemStyle:{color:['#46695b','#83ad99','#d5c391'][i]},data:keys.map(k=>Q.analysis.behavior[c].factors[q][k].correlation.toFixed(3))}))},true)}
document.getElementById('behavior-fund').addEventListener('change',behavior);behavior();
addEventListener('resize',()=>charts.forEach(c=>c.resize()));window.QUARTER_REVIEW_READY=true;
"""
vendor = (ROOT / "report/vendor/echarts.min.js").read_text()
data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c")
html = f'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>{esc(R["title"])} · {DATE}</title><style>{css}</style><main>{"".join(parts)}</main><script>{vendor}</script><script>const Q={data};{js}</script></html>'
(BASE / "review.html").write_text(html)
with zipfile.ZipFile(BASE / "review-data.zip", "w", zipfile.ZIP_DEFLATED) as z:
    sources = list(BASE.glob("*/*.text.json")) + list(BASE.glob("*/manifest.json")) + \
        list(BASE.glob("nav/*.csv")) + [BASE / "analysis.json", BASE / "review.json",
            ROOT / f"research/quarter_review_{DATE}.json",
            ROOT / "tools/collect_quarter_review.py", ROOT / "tools/analyze_quarter_review.py", Path(__file__)]
    sources += list((ROOT / f"data/ideal_review/{DATE}/nav").glob("*.csv"))
    sources += list((BASE / "macro").glob("*.txt")) + list((BASE / "macro").glob("*.meta.json"))
    for p in sources:
        z.write(p, str(p.relative_to(ROOT)))
(BASE / "review-manifest.json").write_text(json.dumps({p.name: hashlib.sha256(p.read_bytes()).hexdigest()
    for p in [BASE / "review.html", BASE / "review.md", BASE / "review.json", BASE / "review-data.zip"]}, indent=2))
print(json.dumps({"report": str(BASE / "review.html"), "reports": len(documents), "visible": visible,
                  "two_funds_cash_cny": cash_cny}, ensure_ascii=False))
