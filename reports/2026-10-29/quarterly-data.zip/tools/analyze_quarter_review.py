"""Reproduce disclosure measurements and post-period NAV diagnostics without backfilling holdings."""
import json
import re
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATE = datetime.now(ZoneInfo("Asia/Shanghai")).date().isoformat()
BASE = ROOT / "data/quarter_review" / DATE
NAV = ROOT / "data/ideal_review" / DATE / "nav"
DOMESTIC = ["022714", "021180", "010390", "011370", "519697",
            "022415", "021902", "002244", "002051"]
SINGLE = {"519697", "002244"}
NUM = r"[\d,]+\.\d+"


def number(s):
    return float(s.replace(",", ""))


def section(text, start, end):
    m = re.search(r"^\s*" + re.escape(start) + r"\s.*?(?=^\s*" +
                  re.escape(end) + r"\s)", text, re.S | re.M)
    return m[0] if m else ""


def parse(row):
    text = (ROOT / row["text_file"]).read_text()
    clean = re.sub(r"--- PDF PAGE \d+ ---\n[^\n]*\n(?:第[^\n]*\n| \d+ \n)?", "\n", text)
    financial = section(clean, "3.1", "3.2")
    asset = section(clean, "5.1", "5.2")
    navs = re.search(r"期末基金资产净值\s+(.*?)(?=5\.\s*期末基金份额净值)", financial, re.S)
    assert navs, row
    net_assets = sum(number(x) for x in re.findall(r"[\d,]+\.\d{2}", re.sub(r"\s+", "", navs[1])))
    equity = re.search(r"权益投资\s+(" + NUM + r")\s+([\d.]+)", asset)
    cash = re.search(r"银行存\s*款和\s*结算备付\s*金?\s*合计\s+(" + NUM + r")", asset)
    if not cash:
        cash = re.search(r"银行存款和结算备付金合计\s+(" + NUM + r")", asset)
    return_rows = re.findall(r"过去三\s*个\s*月\s+(-?[\d.]+)%\s+(-?[\d.]+)%\s+(-?[\d.]+)%", clean)
    which = 0 if row["code"] in SINGLE else 1
    perf = return_rows[which] if len(return_rows) > which else None
    result = {**row, "nav_cny": net_assets,
              "stock_pct_net": number(equity[1]) / net_assets * 100 if equity else 0,
              "stock_pct_total": float(equity[2]) if equity else 0,
              "cash_pct_net": number(cash[1]) / net_assets * 100 if cash else None,
              "quarter_return_pct": float(perf[0]) if perf else None,
              "benchmark_return_pct": float(perf[2]) if perf else None}
    if row["code"] in DOMESTIC:
        stocks = section(clean, "5.3", "5.4")
        holdings = []
        pattern = r"^\s*(\d{1,2})\s+(\d{5,6})\s+(.+?)\s+([\d,]+)\s+(" + NUM + r")\s+([\d.]+)"
        for m in re.finditer(pattern, stocks, re.M | re.S):
            holdings.append({"rank": int(m[1]), "code": m[2],
                             "name": re.sub(r"\s+", "", m[3]), "shares": int(m[4].replace(",", "")),
                             "value_cny": number(m[5]), "weight_pct": float(m[6])})
        assert set(h["rank"] for h in holdings) == set(range(1, 11)), (row["code"], row["quarter"], holdings)
        assert all(abs(h["value_cny"] / net_assets * 100 - h["weight_pct"]) < .015
                   for h in holdings), (row["code"], row["quarter"], net_assets)
        result["top10"] = holdings
        result["top10_pct"] = sum(h["weight_pct"] for h in holdings)
        result["mining_pct"] = sum(float(m[1]) for m in re.finditer(
            r"采矿业\s+" + NUM + r"\s+([\d.]+)", section(clean, "5.2", "5.3")))
        result["strategy"] = section(clean, "4.4", "4.5")
    result["pages"] = {key: [i["page"] for i in json.loads(
        (ROOT / row["file"]).with_suffix(".text.json").read_text())
        if re.search(pattern, i["text"] or "")]
        for key, pattern in {"strategy": r"投资策略和|组合层面|操作方面",
                             "holdings": r"股票投资明细|股票投资明\s*细",
                             "financials": "期末基金资产净值"}.items()}
    return result


def load(code):
    p = NAV / f"{code}.csv"
    if not p.exists():
        p = BASE / "nav" / f"{code}.csv"
    if not p.exists():
        return None
    return pd.read_csv(p, parse_dates=["date"]).set_index("date").wealth


def stats(s, start, end):
    v = s.loc[start:end]
    if len(v) < 2:
        return None
    r = v.pct_change(fill_method=None).dropna()
    return {"start": str(v.index[0].date()), "end": str(v.index[-1].date()), "n": len(r),
            "return": float(v.iloc[-1] / v.iloc[0] - 1),
            "vol": float(r.std() * np.sqrt(252)),
            "mdd": float((v / v.cummax() - 1).min())}


def main():
    funds = {}
    errors = []
    for p in sorted(BASE.glob("*/manifest.json")):
        if not re.fullmatch(r"\d{6}", p.parent.name):
            continue
        funds[p.parent.name] = {}
        for row in json.loads(p.read_text()):
            if row["status"] != "archived":
                errors.append(row)
                continue
            result = parse(row)
            funds[p.parent.name][row["quarter"]] = result
    factors = {"market": "510300", "communication": "515880", "semiconductor": "512480",
               "dividend": "510880", "metals": "512400", "coal": "515220",
               "innovative_drug": "159992", "consumer": "159928", "sp500": "006075"}
    periods = {"Q1": ("2025-12-31", "2026-03-31"), "Q2": ("2026-03-31", "2026-06-30"),
               "Q3": ("2026-06-30", "2026-09-30"), "October": ("2026-09-30", DATE),
               "post_publication": ("2026-10-27", DATE)}
    behavior = {}
    for code in funds:
        s = load(code)
        if s is None:
            continue
        behavior[code] = {"periods": {k: stats(s, *v) for k, v in periods.items()}, "factors": {}}
        for key, (start, end) in periods.items():
            rows = {}
            for name, ref in factors.items():
                other = load(ref)
                if other is None:
                    continue
                # Returns are computed on each native daily grid, then joined; missing days are not compounded.
                both = pd.concat([s.pct_change(fill_method=None), other.pct_change(fill_method=None)],
                                 axis=1).loc[start:end].dropna()
                both = both.loc[both.index > pd.Timestamp(start)]
                if len(both) < 10:
                    continue
                y, x = both.iloc[:, 0], both.iloc[:, 1]
                rows[name] = {"n": len(both), "correlation": float(x.corr(y)),
                              "beta": float(x.cov(y) / x.var())}
            behavior[code]["factors"][key] = rows
    overlap = {}
    for q in ["2", "3"]:
        table = {c: {h["code"]: h["weight_pct"] for h in d[q].get("top10", [])}
                 for c, d in funds.items() if q in d and c in DOMESTIC}
        overlap[q] = [{"a": a, "b": b, "visible_overlap_pct": sum(min(table[a][h], table[b][h])
                      for h in table[a].keys() & table[b].keys()),
                      "common": sorted(table[a].keys() & table[b].keys())}
                      for i, a in enumerate(table) for b in list(table)[i+1:]]
    verification = []
    for c, quarters in funds.items():
        for q, row in quarters.items():
            if row.get("quarter_return_pct") is None or c not in behavior:
                continue
            observed = behavior[c]["periods"].get("Q" + q)
            if not observed or observed["n"] < 45:
                continue
            discrepancy = observed["return"] * 100 - row["quarter_return_pct"]
            verification.append({"code": c, "quarter": q, "difference_pp": discrepancy,
                                 "passed": abs(discrepancy) < .06})
    assert all(r["passed"] for r in verification), [r for r in verification if not r["passed"]]
    output = {"date": DATE, "holdings_asof": "2026-09-30", "funds": funds, "behavior": behavior,
              "visible_overlap": overlap, "nav_disclosure_checks": verification,
              "missing": errors, "method": "持仓权重统一净资产分母；十大以外不推定为零；股票数量变化不等于主动交易，未调整份额流入与公司行动。单因子相关和beta是行为描述，不是选股alpha。披露后仅1个境内净值区间，不够验证新策略。"}
    (BASE / "analysis.json").write_text(json.dumps(output, ensure_ascii=False, indent=2))
    print(json.dumps({"funds": len(funds), "reports": sum(map(len, funds.values())),
                      "nav_checks": len(verification), "missing": errors}, ensure_ascii=False))


if __name__ == "__main__":
    main()
