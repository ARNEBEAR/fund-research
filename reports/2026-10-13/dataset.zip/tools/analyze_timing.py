"""Dated timing comparison; no account backfill and no future labels before realization."""
import json
import hashlib
from datetime import datetime
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
from analyze_portfolio import ROOT, serial

date=datetime.now(ZoneInfo("Asia/Shanghai")).date().isoformat()
base=ROOT/f"data/portfolio/{date}"
policy_path=ROOT/f"research/timing_policy_{date}.json"
policy=json.loads(policy_path.read_text())
levels={p.stem:pd.read_csv(p,parse_dates=["date"]).set_index("date").wealth for p in (base/"nav").glob("*.csv")}
focus=["002244","011370","021902","022415","021180","022714","515880","512480","512720","510300","510880"]
joined=pd.concat([levels[c].rename(c) for c in focus],axis=1).dropna()
latest=joined.index[-1]
snapshot=[]
for c in focus:
    s=joined[c]
    snapshot.append({"code":c,"date":str(latest.date()),"last_day":s.iloc[-1]/s.iloc[-2]-1,
        "return5":s.iloc[-1]/s.iloc[-6]-1,"return20":s.iloc[-1]/s.iloc[-21]-1,
        "return60":s.iloc[-1]/s.iloc[-61]-1,"drawdown120":s.iloc[-1]/s.tail(121).max()-1,
        "distance_ma20":s.iloc[-1]/s.tail(20).mean()-1})
dates=pd.date_range("2021-01-01",pd.Timestamp(date)-pd.Timedelta(days=1),freq="W-FRI")
weekly={}
for c,s in levels.items():
    v=[s.loc[:d].iloc[-1] if len(s.loc[:d]) and (d-s.loc[:d].index[-1]).days<=7 else np.nan for d in dates]
    weekly[c]=pd.Series(v,index=dates).pct_change(fill_method=None)
w=pd.DataFrame(weekly)
tech=w[policy["study_tech_codes"]].mean(axis=1,skipna=False)
m4=(1+tech).rolling(4).apply(np.prod,raw=True)-1
dd=(1+tech).rolling(26).apply(lambda x:np.prod(x)/np.max(np.r_[1,np.cumprod(x)])-1,raw=True)
state=(m4<=-.08)&(dd<=-.15)
funds=pd.concat([levels[c].rename(c) for c in ["002244","011370","021902"]],axis=1).dropna()
events=[]
for signal in state[state].index:
    if signal<pd.Timestamp(policy["study_manager_floor"]):continue
    after=funds.loc[funds.index>signal]
    if len(after)==0:continue
    entry=after.index[0]
    later=funds.loc[funds.index>=entry+pd.Timedelta(days=14)]
    if len(later)==0:continue
    end=later.index[0]
    if (end-entry).days>18:continue
    ret=funds.loc[end]/funds.loc[entry]-1
    waiting=ret["002244"]*.75+ret["011370"]*.25
    immediate=ret["021902"]
    events.append({"signal":str(signal.date()),"entry":str(entry.date()),"end":str(end.date()),
        "technology_4week":m4.loc[signal],"technology_drawdown26":dd.loc[signal],
        "waiting_return":waiting,"immediate_return":immediate,"immediate_advantage":immediate-waiting,
        "immediate_advantage_on_20wan":200000*(immediate-waiting)})
spaced=[];last=None
for event in events:
    current=pd.Timestamp(event["signal"])
    if last is None or (current-last).days>=28:spaced.append(event);last=current
def describe(rows):
    x=np.array([r["immediate_advantage"] for r in rows])
    return {"n":len(x),"mean_advantage":x.mean() if len(x) else None,"median_advantage":np.median(x) if len(x) else None,
            "immediate_better_fraction":np.mean(x>0) if len(x) else None,
            "min_advantage":x.min() if len(x) else None,"max_advantage":x.max() if len(x) else None}
defense=json.loads((base/"defense.json").read_text())
scenarios=[]
for sc in defense["projections"]:
    for fraction in [0,.5,1]:
        outputs=[]
        for window in [60,120,252]:
            k=f"window{window}"
            remaining=sum(amount*sc["fund_response"][c][k] for c,amount in policy["candidate_transfer"].items())
            receiving=sum(policy["candidate_transfer"].values())*sc["fund_response"][policy["destination"]][k]
            outputs.append(remaining*(1-fraction)+receiving*fraction)
        scenarios.append({"scenario":sc["id"],"name":sc["name"],"transfer_fraction":fraction,
            "min_change_cny":min(outputs),"max_change_cny":max(outputs),
            "note":"仅20万待调整预算的一月条件响应，不是全账户损益；分批剩余部分假设在整个情景期仍未转换。"})
weights=json.loads((ROOT/"data/positions_2026-09-17.json").read_text())
held={x["code"]:x["amount_cny"] for x in weights["positions"] if x["status"]!="pending_cancellable"}
first=held.copy()
for c,v in policy["candidate_transfer"].items():first[c]-=v*.5
first["021902"]+=100000
assert sum(first.values())==2290000
result={"date":date,"latest_domestic_date":str(latest.date()),"policy":policy,"snapshot":snapshot,
        "latest_complete_week":{"date":str(dates[-1].date()),"technology_4week":m4.iloc[-1],"drawdown26":dd.iloc[-1],"state":bool(state.iloc[-1])},
        "timing_study":{"all":describe(events),"spaced":describe(spaced),"events":events,"spaced_events":spaced},
        "scenario_budget":scenarios,"first_tranche_amounts":first,
        "source_hashes":{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in [policy_path,base/"nav/manifest.json",base/"defense.json",ROOT/"tools/analyze_timing.py"]}}
(base/"timing.json").write_text(json.dumps(serial(result),ensure_ascii=False,indent=2,allow_nan=False))
print(json.dumps(serial({k:v for k,v in result.items() if k!="source_hashes"}),ensure_ascii=False,indent=2))
