"""Compare defensive destinations and technology beta; dated, reproducible research."""
import argparse
import hashlib
import json
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
import statsmodels.api as sm
from analyze_portfolio import serial, block_indices

ROOT=Path(__file__).resolve().parents[1]


def fit(y,x):
    joined=pd.concat([y.rename("fund"),x],axis=1).dropna()
    model=sm.OLS(joined["fund"],sm.add_constant(joined.drop(columns="fund"))).fit(cov_type="HAC",cov_kwds={"maxlags":5})
    interval=model.conf_int(alpha=.10)
    return {"n":len(joined),"start":str(joined.index[0].date()),"end":str(joined.index[-1].date()),
            "coefficients":model.params.to_dict(),"ci90":{k:interval.loc[k].tolist() for k in interval.index},
            "r2":model.rsquared,"residual_daily_std":model.resid.std(ddof=1),
            "note":"HAC(5)区间；相关回归不能证明因果或将截距视为可持续alpha。"}


def risk(r):
    a=np.r_[1,(1+r).cumprod()]
    return {"return":a[-1]-1,"vol":r.std(ddof=1)*np.sqrt(52),"mdd":min(a/np.maximum.accumulate(a)-1)}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--date",default=datetime.now(ZoneInfo("Asia/Shanghai")).date().isoformat())
    args=parser.parse_args();date=args.date
    base=ROOT/f"data/portfolio/{date}"
    policy=json.loads((ROOT/f"research/defense_policy_{date}.json").read_text())
    manifest=json.loads((base/"nav/manifest.json").read_text())
    assert len(manifest)>=30 and all(s["status"]=="collected" for s in manifest)
    raw={p.stem:pd.read_csv(p,parse_dates=["date"]).set_index("date") for p in (base/"nav").glob("*.csv")}
    level={c:f.wealth for c,f in raw.items()}
    codes=policy["funds"];refs=["510300","515880","512480","512720","510880"]
    domestic=pd.DataFrame({c:level[c] for c in codes+refs}).dropna()
    daily=domestic.pct_change(fill_method=None).dropna()
    all_week_dates=pd.date_range("2021-01-08",pd.Timestamp(date)-pd.Timedelta(days=1),freq="W-FRI")
    weekly_values={}
    for c,s in level.items():
        values=[]
        for d in all_week_dates:
            part=s.loc[:d]
            values.append(part.iloc[-1] if len(part) and (d-part.index[-1]).days<=7 else np.nan)
        weekly_values[c]=values
    weekly=pd.DataFrame(weekly_values,index=all_week_dates).pct_change(fill_method=None)
    tech=weekly[["515880","512480","512720"]].mean(axis=1,skipna=False)
    weekly["tech"]=tech
    start=pd.Timestamp(policy["comparison_start"])
    pair=weekly.loc[weekly.index-pd.Timedelta(days=7)>=start,codes+["tech","510300","510880"]].dropna()
    comparison=[]
    for window in policy["windows_weeks"]:
        for c in codes:
            frame=pair.tail(window)
            if c=="011370":
                frame=frame.loc[frame.index-pd.Timedelta(days=7)>=pd.Timestamp("2025-03-04")]
            r=frame[c]
            conditional={}
            masks={"科技下跌":frame.tech<0,"科技急跌":frame.tech<=-.03,"科技反弹":frame.tech>=.03,
                   "科技弱价值强":(frame.tech<0)&(frame["510880"]>0),"市场与科技同跌":(frame["510300"]<0)&(frame.tech<0)}
            for name,mask in masks.items():
                selected=r[mask]
                conditional[name]={"n":len(selected),"mean":selected.mean() if len(selected) else None,
                    "q10":selected.quantile(.10) if len(selected) else None,
                    "positive_fraction":(selected>0).mean() if len(selected) else None,
                    "tech_mean":frame.tech[mask].mean() if mask.any() else None}
            comparison.append({"code":c,"window":window,"n":len(frame),"start":str(frame.index[0].date()),"end":str(frame.index[-1].date()),
                **risk(r),"tech_corr":r.corr(frame.tech),"market_beta":np.cov(r,frame["510300"])[0,1]/frame["510300"].var(),
                "conditional":conditional})
    # Correlation/beta in monthly snapshots, and historical A sensitivity without splicing.
    monthly=[]
    for end in pd.date_range("2025-01-31",date,freq="M"):
        frame=pair.loc[:end].tail(26)
        if len(frame)>=20:
            monthly.append({"date":str(end.date()),"n":len(frame),
                "funds":{c:{"tech_corr":frame[c].corr(frame.tech),"vol":frame[c].std()*np.sqrt(52)} for c in codes}})
    theme_long=weekly.loc[weekly.index-pd.Timedelta(days=7)>=pd.Timestamp("2024-02-02"),["000477","tech","510300"]].dropna()
    long_sensitivity={"code":"000477","start":str(theme_long.index[0].date()),"end":str(theme_long.index[-1].date()),
                      "n":len(theme_long),**risk(theme_long["000477"]),"tech_corr":theme_long["000477"].corr(theme_long.tech),
                      "note":"同产品A类单列，保守取2024年2月后避免共管交接；不拼C、不等于前海同长度对照。"}
    # Fund beta depends on the chosen reference; retain both single- and multifactor outputs.
    beta=[]
    for window in policy["beta_windows_days"]:
        for c in codes:
            r=daily.tail(window)
            if c=="011370":r=r.loc["2025-03-05":]
            one={ref:fit(r[c],r[[ref]]) for ref in ["515880","510300"]}
            x=pd.DataFrame({"market":r["510300"],"technology_excess":r["515880"]-r["510300"],
                            "value_excess":r["510880"]-r["510300"]})
            beta.append({"code":c,"window":window,"single":one,"multi":fit(r[c],x)})
    # Recent two-day residual using a model estimated before those two days.
    pre=daily.loc[:"2026-09-30"].tail(60)
    prefit=fit(pre["011370"],pre[["515880"]])
    latest=daily.loc["2026-10-08":,["011370","515880","510300"]]
    event=[]
    for d,r in latest.iterrows():
        predicted=prefit["coefficients"]["const"]+prefit["coefficients"]["515880"]*r["515880"]
        event.append({"date":str(d.date()),"huashang":r["011370"],"communication":r["515880"],"market":r["510300"],
                      "pre_event_fitted_return":predicted,"unexplained_return":r["011370"]-predicted})
    # One budget, same valuation dates; reinvest fully into every destination.
    positions=json.loads((ROOT/"data/positions_2026-09-17.json").read_text())
    amounts={p["code"]:p["amount_cny"] for p in positions["positions"] if p["status"]!="pending_cancellable"}
    plans={"baseline":amounts.copy()}
    destinations={"theme":{"021902":1},"qianhai":{"022415":1},"industry":{"021180":1},
                  "old_half":{"021180":.5,"022415":.5},"defensive_half":{"021902":.5,"022415":.5}}
    for name,dest in destinations.items():
        plan=amounts.copy();plan["002244"]-=150000
        for c,f in dest.items():plan[c]+=150000*f
        plans[name]=plan
    hs=amounts.copy();hs["011370"]-=50000;hs["021902"]+=50000;plans["huashang_trim5"]=hs
    proposed=plans["theme"].copy();proposed["011370"]-=50000;proposed["021902"]+=50000;plans["theme_and_trim"]=proposed
    whole=weekly[list(amounts)].dropna().tail(52)
    rng=np.random.default_rng(20261010)
    indexes=block_indices(len(whole),2000,4,rng)
    baseline=whole.to_numpy()@np.array(list(amounts.values()))/2290000
    transfers=[]
    for name,plan in plans.items():
        r=whole.to_numpy()@np.array([plan[c] for c in whole.columns])/2290000
        diff=(r[indexes].std(axis=1,ddof=1)-baseline[indexes].std(axis=1,ddof=1))*np.sqrt(52)
        dn=tech.reindex(whole.index)<0;up=tech.reindex(whole.index)>=.03
        transfers.append({"id":name,"n":len(whole),"start":str(whole.index[0].date()),"end":str(whole.index[-1].date()),
                          "amounts":plan,**risk(pd.Series(r)),"vol_delta_ci90":np.quantile(diff,[.05,.95]),
                          "mean_tech_down_week":r[dn].mean(),"mean_tech_rebound_week":r[up].mean(),
                          "note":"全体真实C共同样本；同额每周再平衡，不计申赎成本。"})
    # Direct paired comparison answers theme vs qianhai rather than two separate baselines.
    tr=next(x for x in transfers if x["id"]=="theme")
    qr=next(x for x in transfers if x["id"]=="qianhai")
    rt=whole.to_numpy()@np.array([tr["amounts"][c] for c in whole.columns])/2290000
    rq=whole.to_numpy()@np.array([qr["amounts"][c] for c in whole.columns])/2290000
    paired_ci=np.quantile((rt[indexes].std(axis=1,ddof=1)-rq[indexes].std(axis=1,ddof=1))*np.sqrt(52),[.05,.95])
    projection=[]
    for sc in policy["scenarios"]:
        shock=np.array([sc["market"],sc["communication"]-sc["market"],sc["dividend"]-sc["market"]])
        outputs={}
        for c in codes:
            responses=[]
            for window in [60,120,252]:
                m=next(b["multi"] for b in beta if b["code"]==c and b["window"]==window)
                b=m["coefficients"]
                responses.append(float(np.array([b["market"],b["technology_excess"],b["value_excess"]])@shock))
            outputs[c]={"window60":responses[0],"window120":responses[1],"window252":responses[2],"min":min(responses),"max":max(responses)}
        marginal={}
        for name,dest in destinations.items():
            responses=[]
            for w in ["window60","window120","window252"]:
                responses.append(sum(f*outputs[c][w] for c,f in dest.items())-outputs["002244"][w])
            marginal[name]={"delta_return_on_15wan_range":[min(responses),max(responses)],
                            "delta_cny_range":[150000*min(responses),150000*max(responses)]}
        projection.append({**sc,"fund_response":outputs,"transfer_benefit":marginal})
    # A simple prospective market-state model must beat an unconditional base rate.
    # Keep the calendar grid: dropping missing weeks would turn a four-week
    # label into a longer interval and leak its outcome into early training.
    div=weekly["510880"].reindex(tech.index)
    momentum13=(1+tech).rolling(13).apply(np.prod,raw=True)-1
    momentum4=(1+tech).rolling(4).apply(np.prod,raw=True)-1
    dividend4=(1+div).rolling(4).apply(np.prod,raw=True)-1
    drawdown26=(1+tech).rolling(26).apply(
        lambda a:np.prod(a)/np.max(np.r_[1,np.cumprod(a)])-1,raw=True)
    available=momentum13.notna()&momentum4.notna()&dividend4.notna()&drawdown26.notna()
    state=((momentum13<0)&(momentum4<dividend4)&(drawdown26<=-.10)).where(available)
    forward=(1+tech).rolling(4).apply(np.prod,raw=True).shift(-4)-1
    candidates=pd.DataFrame({"state":state,"forward":forward}).dropna()
    candidates["state"]=candidates["state"].astype(bool)
    sample=candidates[candidates.state]
    nonoverlap=[];last=None
    for d in sample.index:
        if last is None or (d-last).days>=28:nonoverlap.append(d);last=d
    walk=[]
    for d in pd.date_range("2024-01-05",date,freq="4W-FRI"):
        if d not in candidates.index:continue
        train=candidates.loc[candidates.index+pd.Timedelta(days=28)<=d]
        match=train[train.state==candidates.loc[d,"state"]]
        if len(match)<12 or len(train)<52:continue
        prob=((match.forward>0).sum()+1)/(len(match)+2)
        baseprob=((train.forward>0).sum()+1)/(len(train)+2)
        outcome=int(candidates.loc[d,"forward"]>0)
        walk.append({"date":str(d.date()),"p":prob,"base":baseprob,"actual":outcome,"n_training":len(match)})
    score_difference=np.array([(r["p"]-r["actual"])**2-(r["base"]-r["actual"])**2 for r in walk])
    score_indexes=block_indices(len(walk),2000,2,np.random.default_rng(20261012))
    analog={"rule":policy["analogue_rule"],"latest_state":bool(state.iloc[-1]) if pd.notna(state.iloc[-1]) else None,"latest_date":str(state.index[-1].date()),
            "past_matching_overlapping_nodes":len(sample),"spaced_28day_anchors":len(nonoverlap),
            "past_four_week_positive_fraction":(sample.forward>0).mean(),
            "past_four_week_quantiles":sample.forward.quantile([.1,.5,.9]).tolist(),
            "evaluation_n":len(walk),"brier":np.mean([(r["p"]-r["actual"])**2 for r in walk]),
            "baseline_brier":np.mean([(r["base"]-r["actual"])**2 for r in walk]),"walk_forward":walk,
            "brier_difference_ci90":np.quantile(score_difference[score_indexes].mean(axis=1),[.05,.95]),
            "note":"本次回测运行前固定规则，不是当年已发布的真实策略。两观察点块重采样仅作误差差异敏感性；样本少、训练标签重叠，当前宏观因素未进入模型，不能用历史频率替代校准预测。"}
    monthly_labels=[str(d.date()) for d in domestic.index]
    output={"date":date,"policy":policy,"latest_date":monthly_labels[-1],"weekly_end":str(pair.index[-1].date()),
            "comparison":comparison,"monthly":monthly,"theme_a_sensitivity":long_sensitivity,"beta":beta,
            "pre_event_fit":prefit,"recent_event":event,"transfers":transfers,"theme_minus_qianhai_vol_ci90":paired_ci,
            "projections":projection,"analogue":analog,
            "paths":{"dates":monthly_labels[-121:],"levels":{c:(domestic[c].tail(121)/domestic[c].tail(121).iloc[0]).tolist() for c in codes}},
            "daily_latest":{c:float(daily[c].iloc[-1]) for c in codes+refs},
            "source_hashes":{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/f"research/defense_policy_{date}.json",base/"nav/manifest.json",Path(__file__)]}}
    (base/"defense.json").write_text(json.dumps(serial(output),ensure_ascii=False,indent=2,allow_nan=False))
    print(json.dumps(serial({"comparison":comparison,"event":event,"transfers":[{k:r[k] for k in ["id","n","vol","mdd","return"]} for r in transfers],
        "beta":[{"code":b["code"],"window":b["window"],"comm_beta":b["single"]["515880"]["coefficients"]["515880"],
                 "r2":b["single"]["515880"]["r2"]} for b in beta],"analog":{k:v for k,v in analog.items() if k!="walk_forward"},
        "paired_ci":paired_ci}),ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
