"""Compare a fixed 50/50 pair against dated held amounts on identical samples."""
import argparse
import hashlib
import json
from datetime import datetime
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
from analyze_portfolio import ROOT, serial, block_indices


def metrics(r, annual=52):
    path=np.r_[1,(1+r).cumprod()]
    return {"n":len(r),"return":path[-1]-1,"vol":r.std(ddof=1)*np.sqrt(annual),
            "mdd":(path/np.maximum.accumulate(path)-1).min(),"worst":r.min()}


def pair_stats(frame):
    x,y=frame.iloc[:,0],frame.iloc[:,1]
    r=(x+y)/2
    cov=frame.cov().to_numpy()
    w=np.array([.5,.5])
    variance=w@cov@w
    buyhold=(1+frame).cumprod().mean(axis=1)
    bh=buyhold.div(buyhold.shift(1).fillna(1))-1
    down=x<0
    return {**metrics(r),"start":str(frame.index[0].date()),"end":str(frame.index[-1].date()),
        "correlation":x.corr(y),"individual":[metrics(x),metrics(y)],
        "risk_contribution":w*(cov@w)/variance,
        "vol_reduction_vs_perfect_positive":1-np.sqrt(variance)/(.5*x.std()+.5*y.std()),
        "both_negative_weeks":int(((x<0)&(y<0)).sum()),
        "eco_down_weeks":int(down.sum()),
        "macro_mean_when_eco_down":y[down].mean(),
        "macro_positive_when_eco_down":(y[down]>0).mean(),
        "downside_correlation":x[down].corr(y[down]) if down.sum()>=8 else None,
        "buyhold":metrics(bh),
        "ending_buyhold_weights":((1+frame).prod()/(1+frame).prod().sum()).to_dict()}


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--date",default=datetime.now(ZoneInfo("Asia/Shanghai")).date().isoformat())
    date=p.parse_args().date
    base=ROOT/f"data/portfolio/{date}"
    policy=json.loads((ROOT/f"research/defense_policy_{date}.json").read_text())["pair_policy"]
    levels={f.stem:pd.read_csv(f,parse_dates=["date"]).set_index("date").wealth for f in (base/"nav").glob("*.csv")}
    dates=pd.date_range("2021-01-01",pd.Timestamp(date)-pd.Timedelta(days=1),freq="W-FRI")
    weekly={}
    for c,s in levels.items():
        weekly[c]=[s.loc[:d].iloc[-1] if len(s.loc[:d]) and (d-s.loc[:d].index[-1]).days<=7 else np.nan for d in dates]
    w=pd.DataFrame(weekly,index=dates).pct_change(fill_method=None)
    pair=w[policy["codes"]].dropna()
    windows=[{"window":n,**pair_stats(w[policy["codes"]].tail(n).dropna())} for n in policy["windows"]]
    long_c=pair_stats(pair)
    along=w.loc[w.index-pd.Timedelta(days=7)>=pd.Timestamp(policy["a_start"]),policy["a_sensitivity"]].dropna()
    annual=[{"year":int(year),**pair_stats(f)} for year,f in along.groupby(along.index.year) if len(f)>=4]
    rolling=[]
    for d in pd.date_range(pair.index[0],date,freq="M"):
        f=w[policy["codes"]].loc[:d].tail(26).dropna()
        if len(f)>=20:
            rolling.append({"date":str(d.date()),"n":len(f),"correlation":f.iloc[:,0].corr(f.iloc[:,1]),
                            "vol":f.mean(axis=1).std()*np.sqrt(52)})
    pos=json.loads((ROOT/"data/positions_2026-09-17.json").read_text())
    amounts={r["code"]:r["amount_cny"] for r in pos["positions"] if r["status"]!="pending_cancellable"}
    codes=list(amounts)
    common=w[codes+policy["codes"]].dropna().tail(52)
    held=common[codes].to_numpy()@np.array(list(amounts.values()))/sum(amounts.values())
    pair_r=common[policy["codes"]].mean(axis=1).to_numpy()
    def fundplan(label, weights):
        r=common[list(weights)].to_numpy()@np.array(list(weights.values()))/sum(weights.values())
        return label,r
    proposed=amounts.copy()
    proposed["002244"]-=150000;proposed["011370"]-=50000;proposed["021902"]+=200000
    plan_returns={"held":held,"pair":pair_r}
    plan_returns.update([fundplan("theme_and_trim",proposed),fundplan("existing_core_equal",{"022714":.5,"022415":.5}),
                         fundplan("industry_theme_equal",{"021180":.5,"021902":.5})])
    rng=np.random.default_rng(20261012)
    idx=block_indices(len(common),2000,4,rng)
    comparisons=[]
    for name,r in plan_returns.items():
        delta=(r[idx].std(axis=1,ddof=1)-held[idx].std(axis=1,ddof=1))*np.sqrt(52)
        comparisons.append({"id":name,**metrics(pd.Series(r)),"vol_delta_vs_held_ci90":np.quantile(delta,[.05,.95])})
    # Buy-and-hold sensitivity for both sides of the main comparison.
    common_levels=pd.DataFrame({c:levels[c] for c in codes+policy["codes"]}).dropna()
    daily=common_levels.pct_change(fill_method=None).dropna()
    long_daily={}
    for kind,selection in [("c",policy["codes"]),("a",policy["a_sensitivity"])]:
        actual=pd.DataFrame({c:levels[c] for c in selection}).dropna().pct_change(fill_method=None).dropna()
        long_daily[kind]={"start":str(actual.index[0].date()),"end":str(actual.index[-1].date()),
                         **metrics(actual.mean(axis=1),252),
                         "correlation":actual.iloc[:,0].corr(actual.iloc[:,1]),
                         "note":"连续实际共同净值日，每日50/50再平衡；含周内峰谷，不能与周频回撤直接比大小。"}
    daily_pair=daily[policy["codes"]].mean(axis=1)
    daily_held=daily[codes].to_numpy()@np.array(list(amounts.values()))/sum(amounts.values())
    # For weekly buy-and-hold, include the start value of 1 before the first return.
    wl=(1+common).cumprod()
    held_bh=wl[codes].to_numpy()@np.array(list(amounts.values()))/sum(amounts.values())
    pair_bh=wl[policy["codes"]].mean(axis=1).to_numpy()
    def frompath(values):
        return metrics(pd.Series(values/np.r_[1,values[:-1]]-1))
    latest=pd.DataFrame({c:levels[c] for c in policy["codes"]}).dropna()
    lr=latest.pct_change(fill_method=None).dropna()
    event=[{"date":str(d.date()),"eco":r["019032"],"macro":r["017787"],"pair":r.mean()}
           for d,r in lr.loc["2026-09-23":].iterrows()]
    # No extrapolation from quarterly holdings: fund-return interactions only.
    interactions=[]
    for c in ["022714","022415","021180","011370","002244","021902"]:
        f=w[[c]+policy["codes"]].dropna().tail(52)
        interactions.append({"code":c,"n":len(f),"eco_corr":f[c].corr(f["019032"]),"macro_corr":f[c].corr(f["017787"])})
    result={"date":date,"policy":policy,"latest_nav_date":str(latest.index[-1].date()),
        "windows":windows,"full_c":long_c,"a_sensitivity":{"stats":pair_stats(along),"annual":annual,
            "note":"两只同产品A类独立计算，2021起均在现经理任内；不与C类拼接。年份按周终点分组，并非官方日历年收益。"},
        "long_daily":long_daily,
        "weekly_path_limit":"长窗口可能存在超过7自然日未估值的假期缺周；不填0，长窗收益/回撤仅为有效周复合，不作为完整持有期收益。连续全期风险另看long_daily。主表25周无缺周。",
        "rolling":rolling,"common":{"start":str(common.index[0].date()),"end":str(common.index[-1].date()),
            "n":len(common),"results":comparisons,"buyhold":{"held":frompath(held_bh),"pair":frompath(pair_bh)},
            "paths":{"dates":[str((common.index[0]-pd.Timedelta(days=7)).date())]+[str(d.date()) for d in common.index],
                     "levels":{name:[1]+np.cumprod(1+r).tolist() for name,r in plan_returns.items()}}},
        "daily_common":{"start":str(daily.index[0].date()),"end":str(daily.index[-1].date()),
            "note":"真实C共同估值日，日频恢复权重，与主表周频是不同再平衡假设；仅作峰谷敏感性。",
            "pair":metrics(daily_pair,252),"held":metrics(pd.Series(daily_held),252)},
        "recent_event":event,"interactions":interactions,
        "source_hashes":{str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest()
                         for f in [ROOT/f"research/defense_policy_{date}.json",base/"nav/manifest.json",ROOT/"tools/analyze_pair.py"]}}
    (base/"pair.json").write_text(json.dumps(serial(result),ensure_ascii=False,indent=2,allow_nan=False))
    print(json.dumps(serial({k:v for k,v in result.items() if k not in ["source_hashes","rolling"]}),ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
