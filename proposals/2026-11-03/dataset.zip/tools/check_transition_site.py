"""Exercise the transition report controls and verify its published evidence bundle."""
import argparse
import hashlib
import json
import threading
import zipfile
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / "publish/github-pages"
parser = argparse.ArgumentParser()
parser.add_argument("--url")
args = parser.parse_args()
server = None
if args.url:
    url = args.url.rstrip("/") + "/"
else:
    class Quiet(SimpleHTTPRequestHandler):
        def log_message(self, *args):
            pass
    server = ThreadingHTTPServer(("127.0.0.1", 0), partial(Quiet, directory=str(PUBLIC)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{server.server_address[1]}/"
target = PUBLIC / "proposals/2026-11-03"
manifest = json.loads((target / "manifest.json").read_text())
for row in json.loads((PUBLIC / "reports/index.json").read_text()):
    folder = PUBLIC / row["path"]
    for name, digest in json.loads((folder / "manifest.json").read_text())["files"].items():
        assert hashlib.sha256((folder / name).read_bytes()).hexdigest() == digest
screens = ROOT / "report/transition-check"
screens.mkdir(parents=True, exist_ok=True)
errors = []
with sync_playwright() as pw:
    browser = pw.chromium.launch(headless=True)
    for width in [1440, 390]:
        page = browser.new_page(viewport={"width": width, "height": 950 if width == 1440 else 844})
        page.on("pageerror", lambda error: errors.append(str(error)))
        page.on("console", lambda message: errors.append(message.text) if message.type == "error" else None)
        page.goto(url + "archive.html", wait_until="networkidle")
        page.wait_for_function("window.PROPOSAL_ARCHIVE_READY")
        page.locator('#proposals a[href="proposals/2026-11-03/"]').click()
        page.wait_for_function("window.TRANSITION_READY")
        assert page.locator("canvas").count() == 3
        assert page.locator(".step").count() == 3
        assert "11月4日" in page.locator(".step").first.inner_text()
        assert "未来一周" in page.locator("main").inner_text()
        page.screenshot(path=str(screens / f"overview-{width}.png"))
        for inventory in ["keyi_confirmed", "reported"]:
            page.select_option("#inventory", inventory)
            assert page.locator("#inventory").input_value() == inventory
        for branch in ["bull", "bear", "rates", "base"]:
            before = page.locator("#scenario-detail").inner_text()
            page.select_option("#branch", branch)
            assert before != page.locator("#scenario-detail").inner_text()
        before = page.locator("#timing-chart").evaluate("(e)=>echarts.getInstanceByDom(e).getOption().series[0].data")
        page.select_option("#timing-profile", "late5")
        after = page.locator("#timing-chart").evaluate("(e)=>echarts.getInstanceByDom(e).getOption().series[0].data")
        assert before != after
        page.select_option("#timing-profile", "early5")
        for selector in ["risk-chart", "scenario-chart", "timing-chart"]:
            page.locator("#" + selector).scroll_into_view_if_needed()
            page.screenshot(path=str(screens / f"{selector}-{width}.png"))
        page.locator("details > summary").click()
        assert page.evaluate("document.documentElement.scrollWidth <= innerWidth + 1")
        with page.expect_download() as download:
            page.locator('a[href="dataset.zip"]').first.click()
        archive = screens / f"dataset-{width}.zip"
        download.value.save_as(str(archive))
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None and "tools/verify_transition.py" in z.namelist()
        for name, digest in manifest["files"].items():
            response = page.request.get(url + "proposals/2026-11-03/" + name)
            assert response.ok and hashlib.sha256(response.body()).hexdigest() == digest, name
        page.goto(url, wait_until="networkidle")
        latest = json.loads((PUBLIC / "reports/index.json").read_text())[0]["date"]
        assert f"/reports/{latest}/" in page.url
        page.close()
    browser.close()
if server:
    server.shutdown()
assert not errors, errors
result = {"passed": True, "url": args.url or "local", "viewports": [1440, 390],
          "checks": ["科益状态切换", "风险与情景图", "等待时序敏感性", "下载包与逐文件哈希", "原报告未改写", "默认每日入口"],
          "manifest_sha256": hashlib.sha256((target / "manifest.json").read_bytes()).hexdigest()}
(screens / ("live.json" if args.url else "local.json")).write_text(json.dumps(result, ensure_ascii=False, indent=2))
print(json.dumps(result, ensure_ascii=False))
