"""Publish the transition plan as an independent dated proposal."""
import hashlib
import json
import shutil
import zipfile
from html import escape
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATE = "2026-11-03"
BASE = ROOT / "data/transition_review" / DATE
PUBLIC = ROOT / "publish/github-pages"
TARGET = PUBLIC / "proposals" / DATE
x = json.loads((BASE / "analysis.json").read_text())
n = json.loads((ROOT / f"research/transition_notes_{DATE}.json").read_text())
v = json.loads((BASE / "verification.json").read_text())
assert v["passed"]
TARGET.mkdir(parents=True, exist_ok=True)
e = escape
def pct(v):
    return f"{v*100:+.2f}%"
def table(headers, rows):
    return '<div class="scroll"><table><thead><tr>' + ''.join(f"<th>{e(s)}</th>" for s in headers) + '</tr></thead><tbody>' + ''.join('<tr>'+''.join(f"<td>{e(str(s))}</td>" for s in row)+'</tr>' for row in rows) + '</tbody></table></div>'
def mdtable(headers, rows):
    return ["| " + " | ".join(headers) + " |", "|" + "|".join(["---"] * len(headers)) + "|"] + ["| " + " | ".join(str(v).replace("|", "/") for v in row) + " |" for row in rows]

date_note = "收盘行情：11月3日；境内正式基金净值：11月2日；QDII：10月30日；共同模型终点：" + x["common_end"] + "。本报告没有虚构今日基金正式收益。"
parts = [f'<div class="eyebrow">TRANSITION REVIEW · {DATE}</div><h1>{e(n["headline"])}</h1><p class="lead">{e(n["verdict"])}</p><p class="muted">{e(n["scope"])}</p><p class="muted">{date_note}</p>',
         '<nav><a href="../../">每日研究</a><a href="../../archive.html">日期档案</a><a href="../2026-11-02/">昨日8只提案</a><a href="report.md">下载正文</a><a href="dataset.zip">数据与证据包</a></nav>',
         '<h2>未来一周，怎样执行</h2>']
md = [f"# 短期调仓计划 · {DATE}", "", n["headline"], "", n["verdict"], "", n["scope"], "", date_note, "", "## 分批计划", ""]
for i, step in enumerate(n["plan"]):
    parts.append(f'<article class="step"><span class="step-no">0{i+1}</span><div><h3>{e(step["date"])}</h3><p class="lead">{e(step["action"])}</p><p>{e(step["condition"])}</p><p class="muted">{e(step["recipient"])}</p></div></article>')
    md += [f'### {step["date"]}', "", step["action"], "", step["condition"], "", step["recipient"], ""]
parts += [f'<p class="notice">{e(n["execution"])}</p>', '<h2>为什么现在需要调整</h2><div class="cards">']
md += [n["execution"], "", "## 判断依据", ""]
for row in n["judgments"]:
    parts.append(f'<article><h3>{e(row["title"])}</h3><p>{e(row["text"])}</p></article>')
    md += ["### " + row["title"], "", row["text"], ""]
parts.append("</div>")
rows = [[f["name"], f["date"], f'{f["Q3_pct"]:+.2f}%', pct(f["return_since_sep30"]), pct(f["return20"]), pct(f["return5"])]
        for f in x["funds"] if f["code"] in ["011370", "002244", "022714", "010390", "021902", "022415"]]
parts += [table(["基金", "实际净值日期", "第三季度", "9月30日起", "近20净值日", "近5净值日"], rows),
          '<p class="muted">以上是基金区间表现，不是个人收益；不同窗口相互重叠，不称独立重复证据。</p>']
md += mdtable(["基金", "净值日期", "Q3", "9月30日起", "20日", "5日"], rows) + [""]
parts += ['<h2>主要风险仍来自哪里</h2><label>科益状态 <select id="inventory"><option value="reported">未确认科益 · 旧229万结构参照</option><option value="keyi_confirmed">若科益已买入 · 旧244万结构参照</option></select></label>',
          '<div id="risk-chart" class="chart"></div><p class="muted">最近20个共同净值日的方差贡献。资金权重使用旧清单归一，不能当作当前市值；贡献比例不是未来损失比例。只剔除华商后，万家和低碳的共同风险仍存在。</p>']
corr = [[x["names"][r["a"]] + " / " + x["names"][r["b"]], f'{r["20"]:.2f}', f'{r["60"]:.2f}', f'{r["26w"]:.2f}'] for r in x["correlations"]]
parts.append(table(["基金对", "20日相关", "60日相关", "26周相关"], corr))
drift = next(r for r in x["drift_sensitivity"] if r["inventory"] == "reported" and r["stage"] == "hold")
drift_risk = sum(drift["risk20"][c] for c in ["022714", "002244", "011370"])
parts.append(f'<p class="muted">即使假设旧金额按后续净值变化机械滚动至10月30日，万家、低碳、华商仍贡献约{drift_risk*100:.1f}%的近期方差。该敏感性不是账户市值重建，具体起点假设见下载数据。</p>')
md += ["## 共同波动", ""] + mdtable(["基金对", "20日", "60日", "26周"], corr) + [""]
md += [x["drift_note"], "", f'上述三只在金额漂移敏感性中仍贡献约{drift_risk*100:.1f}%近期方差。', ""]
parts += ['<h2>减少风险，也让出一部分反弹</h2>',
          '<p>下图比较完成各批调整后的结构，同样的未来20日额外冲击应用于全部方案。原组合、第一批、两批完成和另减万家分别比较。</p>',
          '<label>条件分支 <select id="branch">' + ''.join(f'<option value="{b["id"]}">{e(b["name"])}</option>' for b in x["model"]["branches"]) + '</select></label><div id="scenario-chart" class="chart"></div><p id="scenario-detail"></p>',
          '<p class="muted">人工冲击未校准为市场概率；模型尾部不是损失上限。共同模型尚未纳入今天全部正式基金净值，不能把这张表当作今晚完成估值后的精确预测；今日已发生损失没有重复计入。</p>']
branch_rows = [[b["name"]] + [pct(b["response"]["reported_" + k]["mean"]) for k in ["hold", "first", "second", "wanjia"]] for b in x["model"]["branches"]]
md += ["## 完成调整后的20日条件响应", ""] + mdtable(["分支", "维持", "第一批", "两批完成", "另减万家"], branch_rows) + [""]
parts += ['<h3>先分批，还是再等5天</h3>', f'<p>{e(n["timing"])}</p>',
          '<label>冲击到达时间 <select id="timing-profile"><option value="early5">集中在前5日</option><option value="even">均匀分布20日</option><option value="late5">集中在后5日</option></select></label>',
          '<div id="timing-chart" class="chart"></div><p class="muted">等待比较固定使用旧229万元参照。柱状数值＝先分两批相对保留原结构再等5个交易日的模型平均收益差；正值表示先分批较好，负值表示等待较好。第一批后隔2个交易日完成第二批；假设无申赎空档，实际不能保证。</p>']
md += ["## 等待的交换", "", n["timing"], ""] + mdtable(["冲击分支", "到达时间", "先分批减去等5日"], [
    [r["branch"], r["profile"], pct(r["two_batches_minus_wait5"]["mean"])] for r in x["model"]["timing"]]) + [""]
parts += ['<details><summary>历史比较、调整后权重与模型限制</summary>']
comparison = [[p["name"], f'{x["statistics"][p["id"]]["weekly"]["vol"]*100:.2f}%', pct(x["statistics"][p["id"]]["weekly"]["mdd"]),
               pct(x["statistics"][p["id"]]["since_sep30"]["return"]), pct(x["statistics"][p["id"]]["since_sep30"]["buyhold"])]
              for p in x["plans"] if p["inventory"] == "reported"]
parts += [table(["旧229万参照", "26周年化波动", "26周最大回撤", "9月底以来恢复权重", "不再平衡"], comparison),
          f'<p class="muted">完整周截至{x["weekly_end"]}，9月底以来共同终点{x["common_end"]}。固定权重事后回放，不是调仓后已经取得的收益。</p>']
md += ["## 历史敏感性", ""] + mdtable(["方案", "波动", "回撤", "9月底以来", "不再平衡"], comparison) + [""]
selected = [p for p in x["plans"] if p["inventory"] == "reported"]
weight_rows = [[x["names"][c]] + [f'{p["weights"][c]*100:.2f}%' for p in selected] for c in x["codes"]]
parts += [table(["旧229万参照"] + [p["name"] for p in selected], weight_rows),
          '<p class="muted">权益近似只映射直接股票与已核股票基金，不含衍生品名义敞口，也不等于最新穿透持仓。实际按当前份额操作，不能用旧金额直接下单。</p>',
          ''.join(f"<p>{e(t)}</p>" for t in x["limits"]) + '</details>']
md += ["## 权重参照", ""] + mdtable(["基金"] + [p["name"] for p in selected], weight_rows) + [""] + x["limits"] + [""]
parts += ['<h2>交易费用与新公告</h2>']
for row in n["fees"]:
    parts.append(f'<article class="fee"><h3><a href="{e(row["url"])}">{e(row["fund"])} ↗</a></h3><p>{e(row["rule"])}</p><p class="muted">{e(row["meaning"])}</p></article>')
    md += [f'### [{row["fund"]}]({row["url"]})', "", row["rule"], "", row["meaning"], ""]
parts += [f'<p><a href="{e(n["benchmark_url"])}">低碳基准变更原文 ↗</a></p><p>{e(n["new_disclosure"])}</p>',
          f'<p class="notice">{e(n["review_rule"])}</p>', '<h2>可追溯证据</h2>']
md += [f'[低碳基准变更原文]({n["benchmark_url"]})', "", n["new_disclosure"], "", n["review_rule"], ""]
for row in n["sources"]:
    parts.append(f'<p><a href="{e(row["url"])}">{e(row["label"])}</a><span class="muted"> · {e(row["status"])}</span></p>')
    md += [f'- [{row["label"]}]({row["url"]})：{row["status"]}']
parts += ['<nav><a href="analysis.json">全部计算</a><a href="verification.json">复算核验</a><a href="dataset.zip">CSV、原文与脚本</a><a href="manifest.json">SHA-256</a></nav>']
css = """*{box-sizing:border-box}html{color-scheme:dark}body{margin:0;background:#0a0d0f;color:#e4eee8;font:16px/1.8 -apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif}main{max-width:1180px;margin:auto;padding:50px 34px 90px}h1{font-size:48px;line-height:1.3;letter-spacing:-.03em}h2{font-size:26px;margin-top:52px}h3{font-size:18px}.lead{font-size:18px;color:#cee5d8}.eyebrow,.muted{font-size:13px;color:#94ada2}a{color:#a4ddba;text-underline-offset:4px}nav{display:flex;gap:20px;flex-wrap:wrap;margin:26px 0;font-size:14px}.step{display:flex;gap:25px;border-top:1px solid #385347;padding:20px 0}.step-no{font:30px ui-monospace,monospace;color:#84bc98;padding-top:18px}.step h3{margin-top:10px}.notice{padding:20px 0;border-top:1px solid #47624e;border-bottom:1px solid #47624e;color:#c4d7c8}.cards{display:grid;grid-template-columns:1fr 1fr;gap:20px}.cards article,.fee{border-top:1px solid #293b31;padding:12px 0}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:14px}td,th{padding:12px 10px;vertical-align:top;text-align:left;border-bottom:1px solid #2b3d31;min-width:95px}td:first-child{min-width:145px}th{color:#9db9a7;font-weight:500}.chart{height:460px}select{font:inherit;padding:8px;max-width:100%;color:#dcecdf;border:1px solid #3c5646;background:#102016}details{margin-top:30px}summary{cursor:pointer;color:#b5d2be}@media(max-width:700px){main{padding:27px 19px 60px}h1{font-size:34px}h2{font-size:24px}.lead{font-size:16px}.cards{grid-template-columns:1fr}.step{gap:15px}.step-no{font-size:23px}td,th{font-size:12px}.chart{height:460px}}"""
js = """
const charts=[],axis={nameTextStyle:{color:'#a7c2b0'},axisLabel:{color:'#adc5b7'},axisLine:{lineStyle:{color:'#486051'}},splitLine:{lineStyle:{color:'#20352a'}}};
const palette=['#829cb0','#accba0','#d6c997','#ab9bbe'],stages=['hold','first','second','wanjia'],labels=['保持原结构','第一批','两批完成','另减万家1/4'];
const shortNames={'022714':'万家新兴蓝筹','022415':'前海国企','021180':'产业机遇','002244':'低碳科技','011370':'华商均衡','010390':'科益','022184':'富国全球科技','021662':'国富亚洲','027170':'交银环球','021277':'广发全球','021902':'广发主题','006075':'博时标普500'};
for(const id of ['risk-chart','scenario-chart','timing-chart'])charts.push(echarts.init(document.getElementById(id)));
function render(){
const inventory=document.getElementById('inventory').value,plan=X.plans.find(p=>p.id===inventory+'_hold'),risk=X.statistics[plan.id].risk20,codes=X.codes.filter(c=>plan.weights[c]>0);
charts[0].setOption({animation:false,tooltip:{trigger:'axis'},legend:{textStyle:{color:'#bdccbf'}},grid:{left:110,right:20,top:45,bottom:45},xAxis:{...axis,type:'value',name:'%',nameLocation:'middle',nameGap:27},yAxis:{...axis,type:'category',inverse:true,data:codes.map(c=>shortNames[c])},series:[{name:'旧金额归一权重',type:'bar',itemStyle:{color:'#678778'},data:codes.map(c=>+(100*plan.weights[c]).toFixed(1))},{name:'近期方差贡献',type:'bar',itemStyle:{color:'#c7dba1'},data:codes.map(c=>+(100*risk[c]).toFixed(1))}]},true);
const b=X.model.branches.find(b=>b.id===document.getElementById('branch').value);
charts[1].setOption({animation:false,tooltip:{trigger:'axis'},grid:{left:125,right:30,top:25,bottom:60},xAxis:{...axis,type:'value',name:'条件均值 %',nameLocation:'middle',nameGap:30},yAxis:{...axis,type:'category',inverse:true,data:labels},series:[{type:'bar',data:stages.map((k,i)=>({value:+(b.response[inventory+'_'+k].mean*100).toFixed(2),itemStyle:{color:palette[i]}}))}]},true);
const a=b.response[inventory+'_hold'],s=b.response[inventory+'_second'];document.getElementById('scenario-detail').textContent='最弱10%模拟路径平均：维持原结构 '+(a.es10*100).toFixed(2)+'%，两批完成 '+(s.es10*100).toFixed(2)+'%。不是损失上限。';
const profile=document.getElementById('timing-profile').value,rows=X.model.timing.filter(r=>r.profile===profile);
charts[2].setOption({animation:false,tooltip:{trigger:'axis'},grid:{left:125,right:30,top:25,bottom:65},xAxis:{...axis,type:'value',name:'收益差 / 百分点',nameLocation:'middle',nameGap:35},yAxis:{...axis,type:'category',inverse:true,data:rows.map(r=>({base:'震荡分化',bull:'科技盈利修复',bear:'增长担忧',rates:'实际利率上行'})[r.branch])},series:[{type:'bar',data:rows.map(r=>({value:+(r.two_batches_minus_wait5.mean*100).toFixed(2),itemStyle:{color:r.two_batches_minus_wait5.mean>=0?'#a8cda1':'#b896a2'}}))}]},true);
}
for(const id of ['inventory','branch','timing-profile'])document.getElementById(id).addEventListener('change',render);
render();addEventListener('resize',()=>charts.forEach(c=>c.resize()));window.TRANSITION_READY=true;
"""
html = f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>短期调仓计划 · {DATE}</title><style>{css}</style></head><body><main>{"".join(parts)}</main><script>{(ROOT/"report/vendor/echarts.min.js").read_text()}</script><script>const X={json.dumps(x,ensure_ascii=False).replace("<",chr(92)+"u003c")};{js}</script></body></html>'
(TARGET / "index.html").write_text(html)
(TARGET / "report.md").write_text("\n".join(md))
for source, name in [(BASE / "analysis.json", "analysis.json"), (BASE / "verification.json", "verification.json"),
                     (ROOT / f"research/transition_notes_{DATE}.json", "notes.json")]:
    shutil.copyfile(source, TARGET / name)
inputs = [ROOT / key for key in x["inputs"]]
inputs += [p for p in (BASE / "sources").iterdir() if p.is_file()]
inputs += [BASE / "verification.json", BASE / "analysis.json", BASE / "paths.npz", BASE / "nav/manifest.json",
           BASE / "market-quotes.txt", ROOT / f"research/transition_notes_{DATE}.json",
           ROOT / "tools/collect_transition.py", ROOT / "tools/verify_transition.py", Path(__file__),
           ROOT / "tools/check_transition_site.py",
           ROOT / "tools/collect_history.py", ROOT / "tools/archive_deep_sources.py",
           ROOT / "report/vendor/echarts.min.js", ROOT / "report/vendor/ECHARTS-LICENSE.txt"]
inputs += [ROOT / "data/quarter_review/2026-10-29" / c / "Q3.txt" for c in x["codes"]]
with zipfile.ZipFile(TARGET / "dataset.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in dict.fromkeys(inputs):
        z.write(p, str(p.relative_to(ROOT)))
manifest = {"date": DATE, "type": "transition_plan_not_trades", "files": {
    p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in TARGET.iterdir() if p.is_file() and p.name != "manifest.json"}}
(TARGET / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
registry = PUBLIC / "proposals/index.json"
rows = json.loads(registry.read_text())
rows = [r for r in rows if r["date"] != DATE] + [{"date": DATE, "path": f"proposals/{DATE}/",
        "title": "仍持有华商、低碳 · 一周分批调仓计划", "status": "reviewed_not_executed"}]
rows.sort(key=lambda r: r["date"], reverse=True)
registry.write_text(json.dumps(rows, ensure_ascii=False, indent=2))
print("https://arnebear.github.io/fund-research/proposals/" + DATE + "/")
