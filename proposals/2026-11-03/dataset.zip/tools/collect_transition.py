"""Freeze fresh data for a transition review; keep reported positions and proposals distinct."""
import hashlib
import json
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
from urllib.request import Request, urlopen
from collect_history import collect_nav, collect_product
from archive_deep_sources import archive

ROOT = Path(__file__).resolve().parents[1]
DATE = "2026-11-03"
BASE = ROOT / "data/transition_review" / DATE
raw = BASE / "nav/raw"
raw.mkdir(parents=True, exist_ok=True)
positions = json.loads((ROOT / "data/positions_2026-09-17.json").read_text())
daily = json.loads((ROOT / "research/daily_config.json").read_text())
factors = daily["forward_factor_model"]["factor_codes"] + ["513100", "513180"]
codes = list(dict.fromkeys([p["code"] for p in positions["positions"]] + factors))
navs = []
for code in codes:
    frame, row = collect_nav(code, "2021-01-01", DATE, raw, code in set(factors) - {"002611", "006075"})
    product = collect_product(code, raw, frame)
    assert not product["same_vendor_mismatches"] and product["history_row_count_matches_api"], code
    row.update(product=product, sha256=hashlib.sha256((raw.parent / f"{code}.csv").read_bytes()).hexdigest())
    navs.append(row)
    (BASE / "nav/manifest.json").write_text(json.dumps(navs, ensure_ascii=False, indent=2))
    print(code, product["name"], row["last_date"], row["latest_nav"], flush=True)

folder = BASE / "sources"
folder.mkdir(exist_ok=True)
sources = [
    {"id": "market_xinhua", "url": "http://www.chinaview.cn/20261103/9d26b4ffc9d84a9e931f375d61a8a2da/c.html"},
    {"id": "market_sina", "url": "https://finance.sina.com.cn/stock/zqgd/2026-11-03/doc-inixmxcw6668568.shtml"},
    {"id": "cpo_sina", "url": "https://finance.sina.com.cn/jjxw/2026-11-03/doc-inixmxcy2249772.shtml"},
    {"id": "huashang_official", "url": "https://www.hsfund.com/osoa/views/fund/detail/011370.html?fund_code=011370"},
    {"id": "lowcarbon_official", "url": "https://www.igwfmc.com/main/jjcp/product/002244/detail.html"},
]
sources += [{"id": "fee_" + c, "url": f"https://fundf10.eastmoney.com/jjfl_{c}.html"} for c in ["011370", "002244", "021902", "022714"]]
sources += [{"id": "sina_" + p["code"], "url": f'https://finance.sina.com.cn/fund/quotes/{p["code"]}/bc.shtml'} for p in positions["positions"]]
rows = []
for item in sources:
    try:
        rows.append(archive(item, folder))
    except Exception as exc:
        rows.append({**item, "status": "failed", "error": str(exc)})
    print(item["id"], rows[-1]["status"], flush=True)
    (folder / "manifest.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2))

# Record the last announcements for the funds being reduced and the proposed recipient.
for code in ["011370", "002244", "022714", "021902"]:
    url = f"https://api.fund.eastmoney.com/f10/JJGG?fundcode={code}&pageIndex=1&pageSize=20&type=0"
    try:
        with urlopen(Request(url, headers={"User-Agent": "Mozilla/5.0", "Referer": "https://fund.eastmoney.com/"}), timeout=30) as r:
            data = r.read()
        parsed = json.loads(data)
        assert all(row["FUNDCODE"] == code for row in parsed["Data"])
        (folder / f"announcements-{code}.json").write_bytes(data)
        (folder / f"announcements-{code}.meta.json").write_text(json.dumps({
            "url": url, "retrieved_at": datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(),
            "sha256": hashlib.sha256(data).hexdigest()
        }, ensure_ascii=False))
    except Exception as exc:
        print("announcement", code, str(exc), flush=True)
