"""Build the November 9 review with explicit execution states and dated evidence."""
import hashlib
import json
import shutil
import zipfile
from html import escape
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DATE="2026-11-09"; BASE=ROOT/"data/transition_review"/DATE; PUBLIC=ROOT/"publish/github-pages"; TARGET=PUBLIC/"proposals"/DATE
x=json.loads((BASE/"analysis.json").read_text()); f=json.loads((BASE/"followup.json").read_text())
n=json.loads((ROOT/f"research/transition_notes_{DATE}.json").read_text())
assert json.loads((BASE/"verification.json").read_text())["passed"]
assert json.loads((BASE/"followup-verification.json").read_text())["passed"]
TARGET.mkdir(parents=True,exist_ok=True)
e=escape
def pct(v):return f"{v*100:+.2f}%"
def table(headers,rows):
    return '<div class="scroll"><table><thead><tr>'+''.join(f'<th>{e(h)}</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join(f'<td>{e(str(v))}</td>' for v in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def mt(headers,rows):
    return ['| '+' | '.join(headers)+' |','|'+'|'.join(['---']*len(headers))+'|']+['| '+' | '.join(str(v).replace('|','/') for v in row)+' |' for row in rows]
dates="行情截至11月9日收盘；境内正式净值至11月6日，QDII至11月5日；共同日频终点11月5日，完整周截止11月6日。11月9日基金正式净值尚未纳入。"
parts=[f'<div class="eyebrow">PORTFOLIO REVIEW · {DATE}</div><h1>{e(n["headline"])}</h1><p class="lead">{e(n["verdict"])}</p><p class="muted">{e(dates)}</p><p class="muted">{e(n["status"])}</p>',
       '<nav><a href="../../">每日研究</a><a href="../../archive.html">日期档案</a><a href="../2026-11-03/">11月3日原计划</a><a href="report.md">下载正文</a><a href="dataset.zip">证据与计算</a></nav>',
       '<h2>现在如何处理</h2><label>执行状态 <select id="execution"><option value="all">尚未确认 · 查看全部分支</option><option value="0">完全未执行</option><option value="1">已完成第一批</option><option value="2">两批已完成</option></select></label>']
md=[f'# 组合续评 · {DATE}',"",n["headline"],"",n["verdict"],"",dates,"",n["status"],"","## 按执行状态处理",""]
for i,a in enumerate(n["actions"]):
    parts.append(f'<article class="action" data-state="{i}"><h3>{e(a["state"])}</h3><p>{e(a["decision"])}</p><p class="muted">{e(a["next"])}</p></article>')
    md += ['### '+a["state"],"",a["decision"],"",a["next"],""]
parts += [f'<p class="notice">{e(n["guardrails"])}</p>','<h2>最新行情与基金恢复能力</h2>',f'<p>{e(n["market"])}</p>']
md += [n["guardrails"],"","## 最新行情","",n["market"],""]
domestic_codes=["011370","002244","022714","010390","021180","022415","021902"]
rows=[[p["name"],p["end"],str(p["intervals"]),pct(p["return"])] for p in f["fund_changes"] if p["code"] in domestic_codes]
parts += [table(["基金","净值终点","11月3日后区间数","区间收益"],rows),
          f'<p class="muted">{e(n["manager"])}</p>','<label>对照口径 <select id="fund-window"><option value="since">11月3日以后</option><option value="20">最近20个净值日</option></select></label><div class="chart" id="fund-chart"></div>']
md += mt(["基金","净值终点","区间数","11月3日后收益"],rows)+["",n["manager"],""]
overseas=[[p["name"],p["end"],pct(p["return"])] for p in f["fund_changes"] if p["code"] not in domestic_codes]
parts += ['<details><summary>海外持仓与共同风险</summary>',table(["海外基金","实际净值终点","11月3日起收益"],overseas)]
corr=[[x["names"][r["a"]]+' / '+x["names"][r["b"]],f'{r["20"]:.2f}',f'{r["60"]:.2f}',f'{r["26w"]:.2f}'] for r in x["correlations"]]
parts += [table(["基金对","20日","60日","26周"],corr),'<p>华商与低碳20日相关约0.96，低碳与万家约0.95；机械考虑旧金额漂移后，这三只仍贡献约65%的近期方差（科益若已买入约61%）。这不是未来损失比例，也不是已读取账户的权重。</p></details>']
md += mt(["海外基金","净值终点","11月3日起收益"],overseas)+[""]+mt(["基金对","20日","60日","26周"],corr)+[""]
parts += ['<h2>哪些新闻真正改变了判断</h2>']
md += ["## 新增证据",""]
for row in n["news"]:
    parts.append(f'<article class="news"><div class="eyebrow">{e(row["date"])}</div><h3>{e(row["title"])}</h3><p>{e(row["fact"])}</p><p class="reading">{e(row["meaning"])}</p><p class="muted"><a href="{e(row["url"])}">来源 ↗</a> · {e(row["archive"])}</p></article>')
    md += ["### "+row["title"],"",row["date"],"",row["fact"],"",row["meaning"],"",f'[来源]({row["url"]}) · {row["archive"]}',""]
parts += ['<h2>未来20日：降低多少损失，放弃多少弹性</h2>',
          '<p>原人工冲击与随机种子保持一致，更新正式净值估计暴露。模型变化不能全归因为消息面；以下是额外冲击响应，不含已发生损失。</p>',
          '<label>科益 <select id="inventory"><option value="reported">尚未确认买入 · 旧229万结构</option><option value="keyi_confirmed">若已买入 · 旧244万结构</option></select></label>',
          '<div class="chart" id="scenario-chart"></div><p id="scenario-detail" class="muted"></p>']
scenario_rows=[[b["name"],pct(b["response"]["reported_hold"]["mean"]),pct(b["response"]["reported_second"]["mean"])] for b in x["model"]["branches"]]
md += ["## 同条件20日推演",""]+mt(["条件","保持原结构","完成两批"],scenario_rows)+[""]
special_rows=[[s["name"],pct(s["responses"]["reported_hold"]["min"])+" ～ "+pct(s["responses"]["reported_hold"]["max"]),
               pct(s["responses"]["reported_second"]["min"])+" ～ "+pct(s["responses"]["reported_second"]["max"])] for s in f["special"]]
parts += ['<details><summary>新增事件冲击与模型限制</summary>',table(["人工额外条件","原结构窗口范围","两批完成窗口范围"],special_rows),f'<p class="muted">{e(f["special_note"])}</p>']
parts += [f'<p class="muted">{e(t)}</p>' for t in x["limits"]]+['</details>']
md += mt(["条件","原结构范围","两批完成范围"],special_rows)+["",f["special_note"],""]+x["limits"]+[""]
parts += ['<h2>对照11月3日建议：不宣称验证成功</h2>',f'<p>{e(n["verification_note"])}</p>',
          '<div class="chart" id="paper-chart"></div><p class="muted">11月4日收盘才进行首批调整，之后才计入效果；图为旧229万元归一、无个人费用的纸面跟踪。第二批不提前计入。</p>']
audit_rows=[[f'{a["lowcarbon_fee"]*100:.2f}%',str(a["recipient_delay_business_days"])+"个交易日",
             pct(a["hold_return"]),pct(a["schedule_return"]),f'{a["difference"]*100:+.3f}个百分点'] for a in f["post_report"]["variants"]]
parts += [table(["低碳费率假设","转入延迟","保持原结构","执行冻结计划","差值"],audit_rows),
          '<p>计入费用与一天转入时差后，差值仅约+0.002至+0.031个百分点，几乎持平。不能把两天样本当作择时有效，也不能用事后价格挑一个更好的卖出日。</p>']
md += ["## 冻结计划前瞻跟踪","",n["verification_note"],""]+mt(["低碳费率","转入延迟","保持","冻结计划","差值"],audit_rows)+[""]
parts += ['<h2>本周复核节点</h2>']
for event in n["events"]:
    parts.append(f'<article class="news"><h3>{e(event["time"])} · {e(event["event"])}</h3><p>{e(event["if_good"])}</p><p>{e(event["if_bad"])}</p></article>')
    md += ["### "+event["time"]+" · "+event["event"],"",event["if_good"],"",event["if_bad"],""]
parts += [f'<p class="muted"><a href="{e(n["event_source"])}">BLS官方日历 ↗</a> · 已核时间为北京时间，未将未来数据写成已公布结果。</p>',
          f'<p>{e(n["fees"])}</p><p>{e(n["availability"])}</p><details><summary>估值公告与数据口径</summary><p>{e(n["valuation_note"])}</p><p>{e(x["drift_note"])}</p></details>',
          '<nav><a href="analysis.json">模型计算</a><a href="followup.json">冻结计划跟踪</a><a href="followup-verification.json">复算与原文核验</a><a href="dataset.zip">完整证据包</a><a href="manifest.json">哈希</a></nav>']
md += [f'[BLS日历]({n["event_source"]})',"",n["fees"],"",n["availability"],"",n["valuation_note"],""]
css="""*{box-sizing:border-box}html{color-scheme:dark}body{margin:0;background:#0a0d0f;color:#e4eee8;font:16px/1.8 -apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif}main{max-width:1180px;margin:auto;padding:48px 34px 90px}h1{font-size:48px;line-height:1.3;letter-spacing:-.03em}h2{font-size:26px;margin-top:52px}h3{font-size:19px}.lead{font-size:19px;color:#d0e6d8}.eyebrow,.muted{font-size:13px;color:#9bb0a5}a{color:#a5dcb8;text-underline-offset:4px}nav{display:flex;gap:20px;flex-wrap:wrap;margin:26px 0;font-size:14px}.action,.news{border-top:1px solid #344d3e;padding:22px 0}.reading{color:#c5dcbf}.notice{border-block:1px solid #425b49;padding:20px 0}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:14px}th,td{padding:12px 10px;min-width:95px;border-bottom:1px solid #27392e;text-align:left;vertical-align:top}td:first-child{min-width:150px}th{color:#a4beaa}.chart{height:410px}select{max-width:100%;padding:9px;background:#102016;border:1px solid #3c5646;font:inherit;color:#dcecdf}summary{cursor:pointer;color:#b5d2be}details{margin-top:25px}article[hidden]{display:none}@media(max-width:700px){main{padding:27px 19px 60px}h1{font-size:34px}h2{font-size:23px}.lead{font-size:17px}th,td{font-size:12px}.chart{height:420px}}"""
js="""
const charts=[],axis={nameTextStyle:{color:'#abc2b1'},axisLabel:{color:'#adc5b7'},axisLine:{lineStyle:{color:'#486051'}},splitLine:{lineStyle:{color:'#24382c'}}};
for(const id of ['fund-chart','scenario-chart','paper-chart'])charts.push(echarts.init(document.getElementById(id)));
const shortNames={'011370':'华商均衡','002244':'低碳科技','022714':'万家新兴蓝筹','010390':'科益','021180':'产业机遇','022415':'前海国企','021902':'广发主题'};
function render(){
const mode=document.getElementById('fund-window').value,rows=X.funds.filter(p=>shortNames[p.code]);
charts[0].setOption({animation:false,tooltip:{trigger:'axis'},grid:{left:110,right:28,top:25,bottom:50},xAxis:{...axis,type:'value',name:'收益 %',nameLocation:'middle',nameGap:28},yAxis:{...axis,type:'category',inverse:true,data:rows.map(p=>shortNames[p.code])},series:[{type:'bar',data:rows.map(p=>{let v=mode==='since'?F.fund_changes.find(q=>q.code===p.code).return:p.return20;return {value:+(v*100).toFixed(2),itemStyle:{color:v>=0?'#a8cda1':'#b595a3'}}})}]},true);
const inv=document.getElementById('inventory').value;
charts[1].setOption({animation:false,tooltip:{trigger:'axis'},legend:{textStyle:{color:'#b6cbbd'}},grid:{left:110,right:30,top:45,bottom:55},xAxis:{...axis,type:'value',name:'条件均值 %',nameLocation:'middle',nameGap:30},yAxis:{...axis,type:'category',inverse:true,data:['震荡分化','科技盈利修复','增长担忧','实际利率上行']},series:['hold','second'].map((s,i)=>({name:i?'两批完成':'保持原结构',type:'bar',itemStyle:{color:i?'#cdd19f':'#819dae'},data:X.model.branches.map(b=>+(b.response[inv+'_'+s].mean*100).toFixed(2))}))},true);
const rate=X.model.branches.find(b=>b.id==='rates');document.getElementById('scenario-detail').textContent='利率压力分支最弱10%路径均值：保持 '+(rate.response[inv+'_hold'].es10*100).toFixed(1)+'%，两批完成 '+(rate.response[inv+'_second'].es10*100).toFixed(1)+'%。不是损失上限。原冲击与人工权重未校准为概率。';
const base=X.plans.find(p=>p.id==='reported_hold'),dates=F.post_report.dates,hold=F.paper_hold_path;
charts[2].setOption({animation:false,tooltip:{trigger:'axis',valueFormatter:v=>v.toFixed(3)+'%'},legend:{textStyle:{color:'#b6cbbd'}},grid:{left:48,right:22,top:45,bottom:45},xAxis:{...axis,type:'category',data:dates},yAxis:{...axis,type:'value',name:'累计 %'},series:[{name:'保持原结构',type:'line',data:hold.map(v=>v*100),itemStyle:{color:'#819dae'}},{name:'冻结分批计划',type:'line',data:F.post_report.variants[0].schedule.path.map(v=>v*100),itemStyle:{color:'#cdd19f'}}]},true);
}
document.getElementById('execution').addEventListener('change',ev=>document.querySelectorAll('[data-state]').forEach(el=>el.hidden=ev.target.value!=='all'&&el.dataset.state!==ev.target.value));
for(const id of ['inventory','fund-window'])document.getElementById(id).addEventListener('change',render);
render();addEventListener('resize',()=>charts.forEach(c=>c.resize()));window.FOLLOWUP_READY=true;
"""
# Include the independently tracked unchanged path for the chart.
import pandas as pd
path=[]
w=next(p for p in x["plans"] if p["id"]=="reported_hold")["weights"]
frames={c:pd.read_csv(BASE/"nav"/f"{c}.csv",index_col="date").wealth for c in x["codes"]}
for date in f["post_report"]["dates"]:
    path.append(sum(w[c]*frames[c].loc[date]/frames[c].loc["2026-11-03"] for c in w)-1)
f["paper_hold_path"]=path
payload=json.dumps({"X":x,"F":f},ensure_ascii=False).replace("<","\\u003c")
(TARGET/"index.html").write_text(f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>组合续评 · {DATE}</title><style>{css}</style></head><body><main>{"".join(parts)}</main><script>{(ROOT/"report/vendor/echarts.min.js").read_text()}</script><script>const payload={payload};const X=payload.X,F=payload.F;{js}</script></body></html>')
(TARGET/"report.md").write_text("\n".join(md))
for name in ["analysis.json","verification.json","followup.json","followup-verification.json"]:
    shutil.copyfile(BASE/name,TARGET/name)
shutil.copyfile(ROOT/f"research/transition_notes_{DATE}.json",TARGET/"notes.json")
inputs=[p for p in BASE.rglob("*") if p.is_file()]
inputs += [ROOT/name for name in x["inputs"]]+[ROOT/name for name in f["inputs"]]
inputs += [ROOT/f"research/transition_notes_{DATE}.json",ROOT/f"research/transition_sources_{DATE}.json",ROOT/f"research/transition_extra_sources_{DATE}.json"]
inputs += [ROOT/"tools"/name for name in ["collect_transition.py","analyze_transition.py","verify_transition.py","analyze_transition_followup.py","verify_transition_followup.py","build_transition_followup.py","check_transition_followup.py","collect_history.py","archive_deep_sources.py"]]
inputs += [ROOT/"report/vendor/echarts.min.js",ROOT/"report/vendor/ECHARTS-LICENSE.txt"]
with zipfile.ZipFile(TARGET/"dataset.zip","w",zipfile.ZIP_DEFLATED) as z:
    for p in dict.fromkeys(inputs):z.write(p,str(p.relative_to(ROOT)))
manifest={"date":DATE,"status":"execution_unconfirmed","files":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in TARGET.iterdir() if p.is_file() and p.name!="manifest.json"}}
(TARGET/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
registry=PUBLIC/"proposals/index.json"; rows=[r for r in json.loads(registry.read_text()) if r["date"]!=DATE]
rows.append({"date":DATE,"path":f"proposals/{DATE}/","title":"最新行情、回购与通胀 · 分批计划续评","status":"execution_unconfirmed"})
registry.write_text(json.dumps(sorted(rows,key=lambda r:r["date"],reverse=True),ensure_ascii=False,indent=2))
print("https://arnebear.github.io/fund-research/proposals/"+DATE+"/")
