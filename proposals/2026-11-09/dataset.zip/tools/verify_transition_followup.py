"""Independent checks of prospective tracking and new primary-source claims."""
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/"data/transition_review/2026-11-09"
f=json.loads((BASE/"followup.json").read_text())
x=json.loads((BASE/"analysis.json").read_text())
old=json.loads((ROOT/"data/transition_review/2026-11-03/analysis.json").read_text())
for name,digest in f["inputs"].items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
w=next(p for p in old["plans"] if p["id"]=="reported_hold")["weights"]
frames={c:pd.read_csv(BASE/"nav"/f"{c}.csv",index_col="date",parse_dates=True).wealth for c in x["codes"]}
end=pd.Timestamp(f["post_report"]["end"]); start=pd.Timestamp("2026-11-03")
hold=sum(w[c]*(s.loc[end]/s.loc[start]-1) for c,s in frames.items())
assert f["post_report"]["intervals"]==2
for variant in f["post_report"]["variants"]:
    delta=0
    for when in pd.to_datetime(["2026-11-04","2026-11-06"]):
        if when>end:continue
        entry=when+pd.offsets.BDay(variant["recipient_delay_business_days"])
        for c,fraction in [("011370",.5),("002244",1/3)]:
            sold=w[c]*fraction*frames[c].loc[when]/frames[c].loc[start]
            charge=variant["lowcarbon_fee"] if c=="002244" else 0
            recipient=frames["021902"].loc[end]/frames["021902"].loc[entry] if entry<=end else 1
            source=frames[c].loc[end]/frames[c].loc[when]
            delta+=sold*((1-charge)*recipient-source)
    assert np.isclose(hold,variant["hold_return"])
    assert np.isclose(delta,variant["difference"])
for p in f["fund_changes"]:
    s=frames[p["code"]]
    assert np.isclose(s.loc[p["end"]]/s.loc[p["start"]]-1,p["return"])
sources=BASE/"sources"
checks={
    "buyback_zjxc.text.json":["5,653,063","499,724.68","2026年9月1日","2027"],
    "buyback_xys.text.json":["799,863,809.47","0.3023%","股权激励"],
    "buyback_tf.text.json":["1亿元至1.5亿元","尚需提交","11月9日"]
}
for filename,terms in checks.items():
    text="".join("".join(p["text"].split()) for p in json.loads((sources/filename).read_text()))
    for term in terms:assert term in text,(filename,term)
text=(sources/"china_prices.txt").read_text()
assert all(term in text for term in ["0.7%","0.8%","5.7%","0.61"])
text=(sources/"marvell_closing.txt").read_text()
assert "2028" in text and "independent companies" in text
result={"passed":True,"date":x["date"],"checks":["冻结计划输入哈希","独立现金流公式复算两日跟踪","费用与转入时差","逐只净值区间","三家公司回购阶段和金额","国内物价原文","并购尚未交割"],"not_verified":"短样本不构成预测验证；BLS官方网页读取但未本地归档；外贸及就业公布后的实际利率缺口不填充。"}
(BASE/"followup-verification.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
