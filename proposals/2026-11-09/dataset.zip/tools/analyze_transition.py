"""Evaluate staged risk reduction against unchanged holdings, with explicit inventory uncertainty."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import linprog

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--date", default="2026-11-03")
args = parser.parse_args()
DATE = args.date
BASE = ROOT / "data/transition_review" / DATE
pos = json.loads((ROOT / "data/positions_2026-09-17.json").read_text())
quarter = json.loads((ROOT / "data/quarter_review/2026-10-29/analysis.json").read_text())
daily = json.loads((ROOT / "research/daily_config.json").read_text())
previous = json.loads((ROOT / "data/proposal_review/2026-11-02/analysis.json").read_text())
codes = [p["code"] for p in pos["positions"]]
names = {p["code"]: p["name"] for p in pos["positions"]}
factor_codes = daily["forward_factor_model"]["factor_codes"] + ["513100", "513180"]
frames = {c: pd.read_csv(BASE / "nav" / f"{c}.csv", parse_dates=["date"]).set_index("date")
          for c in set(codes + factor_codes)}
levels = pd.DataFrame({c: frames[c].wealth for c in codes}).dropna().loc["2026-04-16":]
native = pd.DataFrame({c: frames[c]["return"] for c in codes}).dropna().loc["2026-04-17":]
plan_defs = [
    ("hold", "保持原结构", {}),
    ("first", "第一批", {"011370": .5, "002244": 1 / 3}),
    ("second", "两批完成", {"011370": 1, "002244": 2 / 3}),
    ("wanjia", "另降万家四分之一", {"011370": 1, "002244": 2 / 3, "022714": .25}),
]
plans = []
for inventory in ["reported", "keyi_confirmed"]:
    amounts = {p["code"]: p["amount_cny"] for p in pos["positions"]
               if inventory == "keyi_confirmed" or p["code"] != "010390"}
    total = sum(amounts.values())
    for key, name, sold in plan_defs:
        adjusted = {c: float(amounts.get(c, 0)) for c in codes}
        transfer = {c: adjusted[c] * fraction for c, fraction in sold.items()}
        for c, amount in transfer.items():
            adjusted[c] -= amount
            adjusted["021902"] += amount
        plans.append({"id": inventory + "_" + key, "inventory": inventory, "stage": key, "name": name,
                      "reference_total": total, "reference_amounts": adjusted, "transfer": transfer,
                      "weights": {c: v / total for c, v in adjusted.items()}})
weights = {p["id"]: np.array([p["weights"][c] for c in codes]) for p in plans}
assert all(np.isclose(w.sum(), 1) and (w >= 0).all() for w in weights.values())

def stats(r, frequency):
    r = np.array(r)
    path = np.r_[1, np.cumprod(1 + r)]
    return {"return": float(path[-1] - 1), "vol": float(r.std(ddof=1) * np.sqrt(frequency)),
            "mdd": float((path / np.maximum.accumulate(path) - 1).min())}

def contributions(frame, w):
    cov = frame.cov().to_numpy()
    return dict(zip(codes, (w * (cov @ w) / (w @ cov @ w)).tolist()))

grid = pd.date_range(levels.index[0], DATE, freq="W-FRI")
week = pd.DataFrame(index=grid)
for c in codes:
    s = frames[c].wealth
    week[c] = [s.iloc[j] if (j := s.index.searchsorted(t, side="right") - 1) >= 0 and (t - s.index[j]).days <= 7
               else np.nan for t in grid]
wr = week.pct_change(fill_method=None).dropna().tail(26)
statistics = {}
for key, w in weights.items():
    d = levels.loc["2026-09-30":]
    recent = native.tail(20)
    statistics[key] = {
        "weekly": stats(wr.to_numpy() @ w, 52),
        "since_sep30": {**stats(d.pct_change(fill_method=None).dropna().to_numpy() @ w, 252),
                        "buyhold": float((d.iloc[-1] / d.iloc[0] - 1).to_numpy() @ w)},
        "risk20": contributions(recent, w),
        "risk60": contributions(native.tail(60), w),
        "risk26w": contributions(wr, w),
        "equity_proxy": sum(w[i] * (quarter["funds"][c]["3"]["stock_pct_net"]
                             + {"027170": 9.69, "022184": 2.07, "021277": 1.65, "006075": 92.35}.get(c, 0)) / 100
                            for i, c in enumerate(codes)),
    }

funds = []
for c in codes:
    f = frames[c]; s = f.wealth
    row = {"code": c, "name": names[c], "date": str(s.index[-1].date()), "nav": float(f.unit_nav.iloc[-1]),
           "return1": float(f["return"].iloc[-1]),
           "return5": float(s.iloc[-1] / s.iloc[-6] - 1),
           "return20": float(s.iloc[-1] / s.iloc[-21] - 1),
           "return_since_sep30": float(s.iloc[-1] / s.loc["2026-09-30"] - 1),
           "Q2_pct": quarter["funds"][c].get("2", {}).get("quarter_return_pct"),
           "Q3_pct": quarter["funds"][c]["3"]["quarter_return_pct"],
           "equity_Q3": quarter["funds"][c]["3"]["stock_pct_net"]}
    if c == "011370":
        row["since_reported_subscription"] = float(s.iloc[-1] / s.loc["2026-09-14"] - 1)
    funds.append(row)
pairs = [("011370", "002244"), ("011370", "022714"), ("002244", "022714"),
         ("011370", "010390"), ("002244", "021902"), ("022714", "021902"), ("021902", "022415")]
correlations = [{"a": a, "b": b, **{str(n): float(native.tail(n)[a].corr(native.tail(n)[b])) for n in [20, 60]},
                 "26w": float(wr[a].corr(wr[b]))} for a, b in pairs]

# Keep shocks fixed from the previous review; news is not turned into calibrated probabilities.
branches = [{k: b[k] for k in ["id", "name", "shock"]} for b in previous["model"]["branches"]]
selectors = {**daily["forward_factor_model"]["selectors"], "002244": [0, 1, 5, 9],
             "021277": [3, 5, 10, 11], "027170": [3, 10, 11], "022184": [3, 5, 10, 11],
             "021662": [5, 10, 11]}
log = pd.DataFrame({c: np.log1p(frames[c]["return"]) for c in set(codes + factor_codes)}).dropna().loc["2026-05-30":]
bounds = [daily["branch_weight_bounds"][b["id"]] for b in branches]
vertices = []
for free in range(4):
    rest = [i for i in range(4) if i != free]
    for flags in itertools.product([0, 1], repeat=3):
        w = np.zeros(4)
        for i, flag in zip(rest, flags):
            w[i] = bounds[i][flag]
        w[free] = 1 - w.sum()
        if bounds[free][0] - 1e-9 <= w[free] <= bounds[free][1] + 1e-9:
            vertices.append(w)
vertices = np.unique(np.round(vertices, 10), axis=0)

def fit(X, Y, indices, ridge):
    B = np.zeros((len(codes), len(factor_codes))); intercept = np.zeros(len(codes))
    for i, c in enumerate(codes):
        if c == "006075":
            B[i, 3] = 1
            continue
        ix = selectors[c]; x = X[indices][:, ix]; y = Y[indices, i]
        mean = x.mean(0); sd = x.std(0); z = (x - mean) / sd
        coef = np.linalg.solve(z.T @ z + ridge * np.eye(len(ix)), z.T @ (y - y.mean())) / sd
        B[i, ix] = coef; intercept[i] = y.mean() - mean @ coef
    return B, intercept

def model(window, ridge, simulate=False):
    r = log.tail(window); X = r[factor_codes].to_numpy(); Y = r[codes].to_numpy(); n = len(r)
    B, intercept = fit(X, Y, np.arange(n), ridge)
    result = {"window": window, "n": n, "ridge": ridge, "start": str(r.index[0].date()), "end": str(r.index[-1].date()),
              "coefficients": dict(zip(codes, B.tolist()))}
    result["deterministic"] = {b["id"]: {k: float(np.expm1(B @ np.log1p(b["shock"])) @ w) for k, w in weights.items()}
                               for b in branches}
    if not simulate:
        return result
    rng = np.random.default_rng(20261103); horizon = 20; count = 2400
    def block(length, repetitions):
        starts = rng.integers(0, n - 4, size=(repetitions, int(np.ceil(length / 5))))
        return (starts[:, :, None] + np.arange(5)).reshape(repetitions, -1)[:, :length]
    residual = Y - X @ B.T - intercept
    innovations = np.column_stack([X - X.mean(0), residual - residual.mean(0)])[block(horizon, count)]
    draws = np.array([fit(X, Y, ix, ridge)[0] for ix in block(n, 300)])[np.arange(count) % 300]
    terminal = {k: [] for k in weights}; details = []; timing = []
    for b in branches:
        scale = 1.35 if b["id"] in ["bear", "rates"] else 1
        factor_path = np.log1p(b["shock"])[None, None, :] / horizon + innovations[:, :, :12] * .5 * scale
        fund_returns = np.expm1(np.einsum("sdf,skf->sdk", factor_path, draws) + innovations[:, :, 12:] * scale)
        response = {}
        for k, w in weights.items():
            values = np.prod(1 + fund_returns @ w, axis=1) - 1
            terminal[k].append(values); quantiles = np.quantile(values, [.1, .5, .9])
            response[k] = {"mean": float(values.mean()), "q10": float(quantiles[0]), "median": float(quantiles[1]),
                           "q90": float(quantiles[2]), "es10": float(values[values <= quantiles[0]].mean())}
        details.append({**b, "response": response})
        # Same shocks, parameters and innovations, with early/late arrival as a sensitivity.
        for profile in ["even", "early5", "late5"]:
            drift = np.ones(horizon) / horizon if profile == "even" else np.r_[np.ones(5) / 5, np.zeros(15)]
            if profile == "late5":
                drift = drift[::-1]
            path = np.log1p(b["shock"])[None, None, :] * drift[None, :, None] + innovations[:, :, :12] * .5 * scale
            fr = np.expm1(np.einsum("sdf,skf->sdk", path, draws) + innovations[:, :, 12:] * scale)
            samples = {}
            for schedule, day_weights in {
                "keep": np.tile(weights["reported_hold"], (20, 1)),
                "two_batches": np.vstack([np.tile(weights["reported_first"], (2, 1)), np.tile(weights["reported_second"], (18, 1))]),
                "wait5": np.vstack([np.tile(weights["reported_hold"], (5, 1)), np.tile(weights["reported_second"], (15, 1))]),
            }.items():
                samples[schedule] = np.prod(1 + np.einsum("sdc,dc->sd", fr, day_weights), axis=1) - 1
            difference = samples["two_batches"] - samples["wait5"]
            timing.append({"branch": b["id"], "profile": profile,
                           "means": {k: float(v.mean()) for k, v in samples.items()},
                           "two_batches_minus_wait5": {"mean": float(difference.mean()),
                               "q10": float(np.quantile(difference, .1)), "q90": float(np.quantile(difference, .9))}})
    robust = {}
    for k, values in terminal.items():
        values = np.array(values); means = values.mean(1)
        low = linprog(means, A_eq=[[1] * 4], b_eq=[1], bounds=bounds, method="highs")
        high = linprog(-means, A_eq=[[1] * 4], b_eq=[1], bounds=bounds, method="highs")
        assert low.success and high.success
        ratios = (vertices @ np.maximum(values, 0).mean(1)) / (vertices @ np.maximum(-values, 0).mean(1))
        robust[k] = {"mean_range": [float(low.fun), float(-high.fun)],
                     "ratio_range": [float(ratios.min()), float(ratios.max())]}
    result.update(branches=details, robust=robust, bounds=bounds, simulations=count, timing=timing)
    np.savez_compressed(BASE / "paths.npz", **{k: np.array(v) for k, v in terminal.items()})
    return result

primary = model(60, 5, True)
sensitivity = [model(n, ridge) for n, ridge in [(40, 5), (100, 5), (60, 0), (60, 10)]]
drift = []
for inventory in ["reported", "keyi_confirmed"]:
    marked = {}
    for p in pos["positions"]:
        c = p["code"]
        if c == "010390" and inventory == "reported":
            marked[c] = 0.0
            continue
        start = {"011370": "2026-09-14", "010390": "2026-09-18"}.get(c, "2026-09-17")
        marked[c] = p["amount_cny"] * frames[c].wealth.loc[levels.index[-1]] / frames[c].wealth.loc[start]
    for stage, label, sold in plan_defs:
        amount = marked.copy()
        for c, fraction in sold.items():
            transfer = marked[c] * fraction
            amount[c] -= transfer
            amount["021902"] += transfer
        w = np.array([amount[c] for c in codes]); w = w / w.sum()
        B = np.array([primary["coefficients"][c] for c in codes])
        drift.append({"inventory": inventory, "stage": stage, "weights": dict(zip(codes, w.tolist())),
                      "risk20": contributions(native.tail(20), w),
                      "conditional": {b["id"]: float(np.expm1(B @ np.log1p(b["shock"])) @ w) for b in branches}})
today = json.loads((BASE / "market.json").read_text())
market = {q["symbol"][-6:]: q["pct"] / 100 for q in today["quotes"]}
visible = {}
for c in ["011370", "002244", "022714"]:
    rows = [h for h in quarter["funds"][c]["3"]["top10"] if h["code"] in ["300308", "300502", "300394"]]
    visible[c] = {"covered_weight": sum(h["weight_pct"] for h in rows) / 100,
                  "constant_q3_weight_response": sum(h["weight_pct"] / 100 * market[h["code"]] for h in rows)}
replay = levels.pct_change(fill_method=None).dropna()
chart = {"dates": [str(d.date()) for d in levels.index],
         "plans": {k: np.r_[0, np.cumprod(1 + replay.to_numpy() @ w) - 1].tolist() for k, w in weights.items()}}
inputs = list((BASE / "nav").glob("*.csv")) + [BASE / "market.json", ROOT / "data/positions_2026-09-17.json",
    ROOT / "research/daily_config.json", ROOT / "data/quarter_review/2026-10-29/analysis.json",
    ROOT / "data/proposal_review/2026-11-02/analysis.json", Path(__file__)]
result = {"date": DATE, "user_feedback": "用户11月3日明确尚未调仓、仍持有华商与低碳；未提供最新逐只市值或科益成交确认。",
          "amount_note": "229/244万元为9月17日旧金额的两套归一参照，均不是11月3日账户市值。所有动作以执行前实际持有份额为准。",
          "codes": codes, "names": names, "plans": plans, "statistics": statistics, "funds": funds, "correlations": correlations,
          "market": today, "visible_holdings": visible, "common_end": str(levels.index[-1].date()),
          "weekly_end": str(wr.index[-1].date()), "risk20_start": str(native.tail(20).index[0].date()),
          "model": primary, "sensitivity": sensitivity, "factor_codes": factor_codes, "chart": chart,
          "drift_sensitivity": drift,
          "drift_note": "仅检验旧金额因跌幅差异而改变权重的敏感性：其他基金假设9月17日金额为当日市值，华商从9月14日申购额、科益若成交从9月18日起，按复权净值机械滚动至10月30日共同日。起点金额本为约数，忽略个人费用及份额差异，这不是当前账户市值重建。",
          "limits": [
              "收盘市场价格截至11月3日；境内正式基金净值截至11月2日，QDII截至10月30日，未把盘中估值当今日正式基金损失。",
              "风险贡献及模拟依据旧金额归一，科益分别按未确认和已买入比较；不能据此断言今日账户损失或精准下单金额。",
              "股数、行业与资产仓位来自9月30日披露。所列三只股票响应是固定季末权重局部映射，未覆盖其他持仓、调仓或估值，不是基金今日估算净值。",
              "历史回放在共同估值日恢复权重，另外列不再平衡；26周保持周网格并限制净值陈旧不超过7天。均为事后比较，不是前瞻交易成绩。",
              "模型用截至共同终点的原生日收益：12因子、60日岭回归λ=5，40/100日及λ=0/10敏感性；5日共同块300组参数、每分支2400条路径。不外推截距。",
              "未来20日冲击沿用11月2日人工条件，不根据今天下跌机械提高跌势概率。今天冲击尚未进入全部正式净值；表内响应只作从下一执行估值点起额外冲击的压力近似，不包含已发生损失。",
              "人工分支权重和盈亏比未经样本外校准，分位数不是未来置信区间或损失上限；遗漏台韩/存储专属因子和流动性极端变化。",
              "方案比较为扣费用前全额承接静态目标，实际申赎费、跨公司转换及到账空档另列，不模拟为同一天无摩擦交易。",
          ],
          "inputs": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}}
if DATE != "2026-11-03":
    domestic_end = min(f["date"] for f in funds if f["code"] in ["011370", "002244", "022714", "021902"])
    overseas_end = min(f["date"] for f in funds if f["code"] in ["022184", "021662", "027170", "021277", "006075"])
    result["limits"][0] = f"收盘市场价格截至{DATE}；境内正式基金净值截至{domestic_end}，QDII截至{overseas_end}；逐只日期另列，不把估值当今日正式基金损失。"
    result["drift_note"] = result["drift_note"].replace("10月30日", result["common_end"])
    result["limits"][5] = "未来20日冲击沿用11月2日条件，随机种子固定；新增消息不机械转换为市场概率。今天冲击尚未进入全部正式净值，表内是从下一执行估值点起额外冲击的压力近似，不含已发生损失。"
(BASE / "analysis.json").write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
print(json.dumps({"funds": funds, "correlations": correlations, "statistics": statistics,
                  "branches": primary["branches"], "robust": primary["robust"]}, ensure_ascii=False, indent=2))
