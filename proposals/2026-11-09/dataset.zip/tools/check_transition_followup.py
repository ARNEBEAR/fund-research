"""Browser and artifact checks for the dated follow-up."""
import argparse
import hashlib
import json
import threading
import zipfile
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]; PUBLIC=ROOT/"publish/github-pages"; DATE="2026-11-09"
parser=argparse.ArgumentParser(); parser.add_argument("--url"); args=parser.parse_args()
manifest=json.loads((PUBLIC/f"proposals/{DATE}/manifest.json").read_text())
for row in json.loads((PUBLIC/"reports/index.json").read_text()):
    folder=PUBLIC/row["path"]
    for name,digest in json.loads((folder/"manifest.json").read_text())["files"].items():
        assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
for day in ["2026-11-02","2026-11-03"]:
    folder=PUBLIC/"proposals"/day
    for name,digest in json.loads((folder/"manifest.json").read_text())["files"].items():
        assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
server=None
if args.url:url=args.url.rstrip("/")+"/"
else:
    class Quiet(SimpleHTTPRequestHandler):
        def log_message(self,*args):pass
    server=ThreadingHTTPServer(("127.0.0.1",0),partial(Quiet,directory=str(PUBLIC)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    url=f"http://127.0.0.1:{server.server_address[1]}/"
folder=ROOT/f"report/followup-check-{DATE}";folder.mkdir(parents=True,exist_ok=True)
errors=[]
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True)
    for width in [1440,390]:
        page=browser.new_page(viewport={"width":width,"height":950 if width==1440 else 844})
        page.on("pageerror",lambda error:errors.append(str(error)))
        page.on("console",lambda m:errors.append(m.text) if m.type=="error" else None)
        page.goto(url+"archive.html",wait_until="networkidle")
        page.wait_for_function("window.PROPOSAL_ARCHIVE_READY")
        page.locator(f'#proposals a[href="proposals/{DATE}/"]').click()
        page.wait_for_function("window.FOLLOWUP_READY")
        assert page.locator("canvas").count()==3
        assert page.locator(".action:visible").count()==3
        page.screenshot(path=str(folder/f"overview-{width}.png"))
        for status in ["0","1","2"]:
            page.select_option("#execution",status)
            assert page.locator(".action:visible").count()==1
            assert page.locator(f'.action[data-state="{status}"]').is_visible()
        page.select_option("#execution","all")
        for selector,value in [("#fund-window","20"),("#inventory","keyi_confirmed")]:
            chart="#fund-chart" if selector=="#fund-window" else "#scenario-chart"
            before=page.locator(chart).evaluate("(el)=>JSON.stringify(echarts.getInstanceByDom(el).getOption().series)")
            page.select_option(selector,value)
            after=page.locator(chart).evaluate("(el)=>JSON.stringify(echarts.getInstanceByDom(el).getOption().series)")
            assert before!=after
        page.select_option("#fund-window","since");page.select_option("#inventory","reported")
        for chart in ["fund-chart","scenario-chart","paper-chart"]:
            page.locator("#"+chart).scroll_into_view_if_needed()
            page.screenshot(path=str(folder/f"{chart}-{width}.png"))
        for summary in page.locator("details > summary").all():
            summary.click()
        assert page.evaluate("document.documentElement.scrollWidth <= innerWidth+1")
        with page.expect_download() as dl:page.locator('a[href="dataset.zip"]').first.click()
        archive=folder/f"dataset-{width}.zip";dl.value.save_as(str(archive))
        with zipfile.ZipFile(archive) as z:assert z.testzip() is None and "tools/verify_transition_followup.py" in z.namelist()
        for name,digest in manifest["files"].items():
            response=page.request.get(url+f"proposals/{DATE}/"+name)
            assert response.ok and hashlib.sha256(response.body()).hexdigest()==digest,name
        page.goto(url,wait_until="networkidle")
        latest=json.loads((PUBLIC/"reports/index.json").read_text())[0]["date"]
        assert f"/reports/{latest}/" in page.url
        page.close()
    browser.close()
if server:server.shutdown()
assert not errors,errors
result={"passed":True,"site":args.url or "local","viewports":[1440,390],"checks":["三种执行状态分支","基金窗口和科益状态切换","三图渲染","下载包及文件哈希","旧报告与提案完整","默认最新日报入口"],"manifest_sha256":hashlib.sha256((PUBLIC/f"proposals/{DATE}/manifest.json").read_bytes()).hexdigest()}
(folder/("live.json" if args.url else "local.json")).write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
