"""Prospective audit of the previously frozen plan; no retrospective plan selection."""
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "data/transition_review/2026-11-09"
x = json.loads((BASE / "analysis.json").read_text())
oldfile = ROOT / "data/transition_review/2026-11-03/analysis.json"
old = json.loads(oldfile.read_text())
oldnotes = ROOT / "research/transition_notes_2026-11-03.json"
frames = {c: pd.read_csv(BASE / "nav" / f"{c}.csv", index_col="date", parse_dates=True) for c in x["codes"]}
report_date = pd.Timestamp("2026-11-03")
common = pd.DataFrame({c: f.wealth for c, f in frames.items()}).dropna().loc[report_date:]
frozen = next(p for p in old["plans"] if p["id"] == "reported_hold")
initial = frozen["weights"]
fund_changes = []
for c in x["codes"]:
    f = frames[c]
    start = f.loc[report_date, "wealth"]
    latest = f.index[-1]
    fund_changes.append({"code": c, "name": x["names"][c], "start": "2026-11-03", "end": str(latest.date()),
                         "intervals": len(f.loc[report_date:])-1,
                         "return": float(f.loc[latest, "wealth"] / start - 1)})

def track(frame, execute, fee=0, delay=0):
    """Buy-and-hold unit ledger. Orders alter exposure only after their execution closing NAV."""
    shares = {c: initial[c] / frame[c].iloc[0] for c in frame}
    original = shares.copy(); cash = 0.0; queue = []; path = []; orders = []
    for date, row in frame.iterrows():
        for due, amount in queue[:]:
            if date >= due:
                shares["021902"] += amount / row["021902"]
                cash -= amount; queue.remove((due, amount))
        if execute and date in [pd.Timestamp("2026-11-04"), pd.Timestamp("2026-11-06")]:
            for c, ratio in [("011370", .5), ("002244", 1/3)]:
                quantity = original[c] * ratio; shares[c] -= quantity
                gross = quantity * row[c]; net = gross * (1-fee if c == "002244" else 1)
                if delay:
                    cash += net; queue.append((date + pd.offsets.BDay(delay), net))
                else:
                    shares["021902"] += net / row["021902"]
                orders.append({"date": str(date.date()), "code": c, "original_share_fraction": ratio,
                               "gross_fraction_start_capital": float(gross), "net_fraction_start_capital": float(net)})
        path.append(sum(shares[c] * row[c] for c in shares) + cash)
    return {"return": float(path[-1]-1), "path": [float(v-1) for v in path], "orders": orders, "ending_transit_fraction": float(cash)}

audits = []
for fee in [0, .005]:
    for delay in [0, 1]:
        hold = track(common, False); changed = track(common, True, fee, delay)
        audits.append({"lowcarbon_fee": fee, "recipient_delay_business_days": delay,
                       "hold_return": hold["return"], "schedule_return": changed["return"],
                       "difference": changed["return"]-hold["return"], "schedule": changed})
# Expose the marginal domestic transfer effect through Nov 6 without inventing a full QDII return.
domestic = pd.DataFrame({c: frames[c].wealth for c in ["011370", "002244", "021902"]}).dropna().loc[report_date:]
relative = domestic / domestic.iloc[0]
marginal = []
for date in relative.index:
    effect = 0.0
    for execution in [pd.Timestamp("2026-11-04"), pd.Timestamp("2026-11-06")]:
        if execution > date:
            continue
        for c, ratio in [("011370", .5), ("002244", 1/3)]:
            source_units = initial[c] * ratio
            effect += source_units * (relative.loc[execution, c] *
                      relative.loc[date, "021902"] / relative.loc[execution, "021902"] - relative.loc[date, c])
    marginal.append({"date": str(date.date()), "difference_fraction_initial_reference": float(effect)})

# Separately test new news channels, keeping probability weights unset.
special = [
    {"id":"cost_pressure","name":"能源上涨、需求偏弱","shock":[-.04,-.07,-.01,-.04,-.02,-.08,.03,.06,-.04,-.05,-.06,-.05]},
    {"id":"inflation_relief","name":"通胀缓和、利率回落","shock":[.03,.10,.01,.05,.04,.09,.01,-.02,.06,.04,.08,.06]},
    {"id":"supply_execution","name":"光通信交付受阻、其余科技温和","shock":[-.01,-.15,0,.01,.01,.01,0,0,0,0,.01,0]},
]
special_results = []
for s in special:
    results = {}
    for plan in x["plans"]:
        w = np.array([plan["weights"][c] for c in x["codes"]])
        responses = []
        for fit in [x["model"]] + x["sensitivity"]:
            B = np.array([fit["coefficients"][c] for c in x["codes"]])
            responses.append(float(np.expm1(B @ np.log1p(s["shock"])) @ w))
        results[plan["id"]] = {"min": min(responses), "max": max(responses), "values": responses}
    special_results.append({**s, "responses": results})

market_before = json.loads((ROOT / "data/transition_review/2026-11-03/market.json").read_text())
by_symbol = {r["symbol"]: r for r in market_before["quotes"]}
market_since = [{**r, "since_nov3": r["close"]/by_symbol[r["symbol"]]["close"]-1} for r in x["market"]["quotes"]]
inputs = [oldfile, oldnotes, BASE/"analysis.json", Path(__file__), ROOT/"data/transition_review/2026-11-03/market.json"]
result = {
    "date": x["date"], "prior_report": "2026-11-03", "fund_changes": fund_changes, "market_since": market_since,
    "post_report": {"start":"2026-11-03","end":str(common.index[-1].date()),"intervals":len(common)-1,
                    "dates":[str(d.date()) for d in common.index], "variants":audits,
                    "note":"严格使用11月3日冻结原权重，11月4日/6日收盘才执行原份额比例；收益从下一净值区间生效。持仓未确认，结果为前瞻纸面跟踪，不是用户交易成绩。已公布共同区间极短，不构成验证成功。"},
    "domestic_marginal": marginal,
    "domestic_note":"只有华商、低碳转广发的边际差值，以11月3日假定起始组合资本为分母；不能与缺失QDII部分拼成全组合收益。扣费前、同日承接只作理想执行对照。",
    "special": special_results,
    "special_note":"人工附加因子冲击，不分配发生概率、不加入原盈亏比；范围来自40/60/100日及正则强度敏感性，不是未来收益置信区间。",
    "inputs": {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
}
assert len(common)-1 < 6
assert not any(o["date"] > str(common.index[-1].date()) for v in audits for o in v["schedule"]["orders"])
(BASE/"followup.json").write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
print(json.dumps({"fund_changes":fund_changes, "post_report":result["post_report"],"domestic_marginal":marginal},ensure_ascii=False,indent=2))
