"""Validate frozen inputs, source dates, allocation arithmetic and paired scenario outputs."""
import argparse
import hashlib
import json
import re
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import linprog

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--date", default="2026-11-03")
args = parser.parse_args()
BASE = ROOT / "data/transition_review" / args.date
x = json.loads((BASE / "analysis.json").read_text())
for name, digest in x["inputs"].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
navs = {}
for row in x["funds"]:
    c = row["code"]; navs[c] = pd.read_csv(BASE / "nav" / f"{c}.csv", index_col="date", parse_dates=True)
    source = (BASE / "sources" / f"sina_{c}.txt").read_text()
    date = re.search(r"数据日期[：:]\s*(\d{4}-\d{1,2}-\d{1,2})", source)
    value = re.search(r"单位净值[：:\s]+(\d+\.\d+)", source)
    assert date and value, c
    when = pd.Timestamp(date.group(1))
    assert when in navs[c].index, (c, date.group(1))
    assert abs(float(value.group(1)) - navs[c].loc[when, "unit_nav"]) < .00011, c
lowcarbon = (BASE / "sources/lowcarbon_official.txt").read_text()
if args.date == "2026-11-03":
    assert "2.314" in lowcarbon and "2026-11-02" in lowcarbon
else:
    latest_low = next(f for f in x["funds"] if f["code"] == "002244")
    assert latest_low["date"] in lowcarbon and f'{latest_low["nav"]:.4f}' in lowcarbon
benchmark = "".join(p["text"] for p in json.loads((BASE / "sources/lowcarbon_benchmark_update.text.json").read_text()))
compact = "".join(benchmark.split())
assert "2026年11月30日" in compact and "沪深300碳中和指数收益率*80%" in compact
common = pd.DataFrame({c: f.wealth for c, f in navs.items()}).dropna().loc["2026-04-16":]
for p in x["plans"]:
    w = p["weights"]; assert np.isclose(sum(w.values()), 1) and min(w.values()) >= 0
    assert np.isclose(sum(p["reference_amounts"].values()), p["reference_total"])
    d = common.loc["2026-09-30":]
    step = [sum(w[c] * (d[c].iloc[i] / d[c].iloc[i-1]) for c in w) for i in range(1, len(d))]
    path = np.r_[1, np.cumprod(step)]
    s = x["statistics"][p["id"]]
    assert np.isclose(path[-1]-1, s["since_sep30"]["return"])
    assert np.isclose((path / np.maximum.accumulate(path)-1).min(), s["since_sep30"]["mdd"])
    assert np.isclose(sum(w[c] * (d[c].iloc[-1] / d[c].iloc[0]-1) for c in w), s["since_sep30"]["buyhold"])
    for key in ["risk20", "risk60", "risk26w"]:
        assert np.isclose(sum(s[key].values()), 1)
    assert len(x["chart"]["plans"][p["id"]]) == len(x["chart"]["dates"])
    assert x["chart"]["plans"][p["id"]][0] == 0
paths = np.load(BASE / "paths.npz")
for k, result in x["model"]["robust"].items():
    data = paths[k]; assert data.shape == (4, 2400) and np.isfinite(data).all()
    means = data.mean(1)
    low = linprog(means, A_eq=[[1]*4], b_eq=[1], bounds=x["model"]["bounds"], method="highs")
    high = linprog(-means, A_eq=[[1]*4], b_eq=[1], bounds=x["model"]["bounds"], method="highs")
    assert low.success and high.success
    assert np.allclose([low.fun, -high.fun], result["mean_range"])
    for i, b in enumerate(x["model"]["branches"]):
        quant = np.quantile(data[i], [.1, .5, .9]); r = b["response"][k]
        assert np.allclose(quant, [r["q10"], r["median"], r["q90"]])
        assert np.isclose(data[i][data[i] <= quant[0]].mean(), r["es10"])
for row in x["market"]["quotes"]:
    assert row["time"].startswith(args.date.replace("-", ""))
    assert abs((row["close"] / row["previous"] - 1) * 100 - row["pct"]) < .011
for row in x["model"]["timing"]:
    assert np.isclose(row["means"]["two_batches"] - row["means"]["wait5"], row["two_batches_minus_wait5"]["mean"])
for row in x["drift_sensitivity"]:
    assert np.isclose(sum(row["weights"].values()), 1)
    assert np.isclose(sum(row["risk20"].values()), 1)
result = {"passed": True, "date": x["date"], "nav_crosscheck_count": len(navs), "plan_count": len(x["plans"]),
          "checks": ["12只新浪净值同日核对", "低碳官网与基准生效日期", "预算闭合", "共同端点收益和回撤独立复算",
                     "风险贡献加总", "配对情景分位与尾部", "线性规划期望界限", "行情日期及涨跌幅", "输入哈希"],
          "limitations": "统计验证不构成预测验证。未读取实际账户市值、平台交易资格或当日全部正式基金净值。"}
(BASE / "verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2))
print(json.dumps(result, ensure_ascii=False))
