"""Archive timestamped market quotes without labeling intraday prices as the close."""
import argparse
import hashlib
import json
import re
from datetime import datetime
from pathlib import Path
from urllib.request import Request,urlopen
from zoneinfo import ZoneInfo

parser=argparse.ArgumentParser()
parser.add_argument("--date",required=True)
args=parser.parse_args()
base=Path(__file__).resolve().parents[1]/"data/transition_review"/args.date
assert base.is_dir()
url="https://qt.gtimg.cn/q=sh000001,sz399006,sz300308,sz300502,sz300394,sh515880,sh512480"
raw=urlopen(Request(url,headers={"User-Agent":"Mozilla/5.0"}),timeout=25).read()
quotes=[]
for symbol,value in re.findall(r'v_(\w+)="([^"]+)"',raw.decode("gbk")):
    p=value.split("~")
    quotes.append({"symbol":symbol,"name":p[1],"close":float(p[3]),"previous":float(p[4]),"time":p[30],"pct":float(p[32])})
assert len(quotes)==7 and all(r["time"].startswith(args.date.replace("-","")) for r in quotes)
closed=all(r["time"][8:12]>="1500" for r in quotes)
(base/"market-quotes.txt").write_bytes(raw)
result={"source":url,"retrieved_at":datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(),
        "raw_sha256":hashlib.sha256(raw).hexdigest(),"status":"close" if closed else "intraday",
        "price_field_note":"close字段为现价；status为intraday时不得称收盘价。","quotes":quotes}
(base/"market.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
