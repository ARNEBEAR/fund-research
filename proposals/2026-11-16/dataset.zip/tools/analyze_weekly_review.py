"""Review current signals and both frozen recommendation dates without assuming execution."""
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1];DATE="2026-11-16";BASE=ROOT/"data/transition_review"/DATE
x=json.loads((BASE/"analysis.json").read_text())
frames={c:pd.read_csv(BASE/"nav"/f"{c}.csv",index_col="date",parse_dates=True).wealth for c in x["codes"]}
common=pd.DataFrame(frames).dropna()
def ledger(start, weights, orders, fee, delay):
    d=common.loc[start:];units={c:weights[c]/d[c].iloc[0] for c in weights}; original=units.copy()
    cash=0.;pending=[];history=[];transactions=[]
    for when,row in d.iterrows():
        for due,amount in pending[:]:
            if when>=due:
                units["021902"]+=amount/row["021902"];cash-=amount;pending.remove((due,amount))
        if str(when.date()) in orders:
            for c,fraction in [("011370",.5),("002244",1/3)]:
                count=original[c]*fraction;units[c]-=count;gross=count*row[c]
                net=gross*(1-fee if c=="002244" else 1)
                due=when+pd.offsets.BDay(delay)
                if delay:cash+=net;pending.append((due,net))
                else:units["021902"]+=net/row["021902"]
                transactions.append({"date":str(when.date()),"code":c,"fraction":fraction,"gross":float(gross),"net":float(net)})
        history.append(sum(units[c]*row[c] for c in units)+cash-1)
    return {"return":float(history[-1]),"path":[float(v) for v in history],"orders":transactions,"transit":float(cash)}

audits=[]
for start,order_dates in [("2026-11-03",["2026-11-04","2026-11-06"]),("2026-11-09",["2026-11-10","2026-11-12"])]:
    frozen=json.loads((ROOT/f"data/transition_review/{start}/analysis.json").read_text())
    w=next(p for p in frozen["plans"] if p["id"]=="reported_hold")["weights"]
    hold=ledger(start,w,[],0,0)
    rows=[]
    for execution,days in [("first_only",order_dates[:1]),("both",order_dates)]:
        for fee in [0,.005]:
            for delay in [0,1]:
                result=ledger(start,w,days,fee,delay)
                rows.append({"execution":execution,"fee":fee,"delay":delay,**result,"difference":result["return"]-hold["return"]})
    d=common.loc[start:]
    audits.append({"start":start,"end":str(d.index[-1].date()),"intervals":len(d)-1,
        "dates":[str(t.date()) for t in d.index],"hold":hold,"variants":rows,
        "status":"11月3日原冻结分批计划" if start=="2026-11-03" else "11月9日建议的条件比较；第二批当时需复核，不冒充已确定交易"})
funds=[]
for p in x["funds"]:
    c=p["code"];s=frames[c]
    last=s.index[-1]
    row={**p,"last_week":float(s.iloc[-1]/s.loc["2026-11-06" if c in ["011370","002244","022714","021902","022415","021180","010390"] else "2026-11-05"]-1)}
    row["since_last_review"]=float(s.iloc[-1]/s.loc["2026-11-09"]-1)
    row["since_nov3"]=float(s.iloc[-1]/s.loc["2026-11-03"]-1)
    funds.append(row)

# The former fit window now ends before this week's event. Freeze old shocks for comparability.
prior=json.loads((ROOT/"data/transition_review/2026-11-09/analysis.json").read_text())
comparisons=[]
for b in x["model"]["branches"]:
    before=next(v for v in prior["model"]["branches"] if v["id"]==b["id"])
    comparisons.append({"branch":b["id"],"name":b["name"],
        "prior_hold":before["response"]["reported_hold"]["mean"],"current_hold":b["response"]["reported_hold"]["mean"],
        "prior_second":before["response"]["reported_second"]["mean"],"current_second":b["response"]["reported_second"]["mean"]})
events=[
    {"id":"ai_disappointment","name":"财报指引或管理交接低于预期","shock":[-.04,-.18,-.01,-.06,.02,-.12,-.04,-.03,-.05,-.05,-.10,-.08]},
    {"id":"ai_relief","name":"订单与交付兑现、风险偏好修复","shock":[.03,.12,.00,.05,.01,.10,.01,-.01,.04,.03,.08,.06]},
    {"id":"domestic_weak","name":"内需与资源价格同时走弱","shock":[-.05,-.02,-.04,0,.02,-.02,-.12,-.10,-.04,-.05,.00,-.04]}
]
special=[]
for ev in events:
    rows={}
    for p in x["plans"]:
        w=np.array([p["weights"][c] for c in x["codes"]]); values=[]
        for fit in [x["model"]]+x["sensitivity"]:
            B=np.array([fit["coefficients"][c] for c in x["codes"]])
            values.append(float(np.expm1(B@np.log1p(ev["shock"]))@w))
        rows[p["id"]]={"min":min(values),"max":max(values),"values":values}
    special.append({**ev,"responses":rows})
inputs=[BASE/"analysis.json",ROOT/"data/transition_review/2026-11-03/analysis.json",ROOT/"data/transition_review/2026-11-09/analysis.json",
        ROOT/"research/transition_notes_2026-11-03.json",ROOT/"research/transition_notes_2026-11-09.json",Path(__file__)]
result={"date":DATE,"funds":funds,"audits":audits,"model_change":comparisons,"special":special,
    "tracking_note":"两个起点各自沿用当期冻结旧金额归一权重，固定份额回放；不比较两个起点的绝对收益，不称用户业绩。共同终点滞后、费用和转入延迟分别列出；结果未验证完整周期。",
    "event_note":"额外冲击为人工设定的未来条件，非校准概率；窗口范围不是置信区间。今天盘中变化和未来冲击不混加。",
    "inputs":{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}}
(BASE/"weekly.json").write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
print(json.dumps({"funds":funds,"audits":[{"start":a["start"],"end":a["end"],"hold":a["hold"]["return"],"variants":[{k:v for k,v in r.items() if k not in ["path","orders"]} for r in a["variants"]]} for a in audits],
                  "branches":comparisons},ensure_ascii=False,indent=2))
