"""Build an offline-capable weekly report and its auditable evidence package."""
import hashlib,json,shutil,zipfile
from html import escape
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];DATE="2026-11-16";BASE=ROOT/"data/transition_review"/DATE
PUBLIC=ROOT/"publish/github-pages";OUT=PUBLIC/"proposals"/DATE
SKILL=Path("/Users/bytedance/.trae-cn/plugins/trae-remote-official/html-report-presentation/0.1.0/skills/html-report")
x=json.loads((BASE/"analysis.json").read_text());w=json.loads((BASE/"weekly.json").read_text())
n=json.loads((ROOT/f"research/weekly_notes_{DATE}.json").read_text())
assert json.loads((BASE/"verification.json").read_text())["passed"]
assert json.loads((BASE/"weekly-verification.json").read_text())["passed"]
for sub in ["assets","_shared/js","_shared/fonts"]:(OUT/sub).mkdir(parents=True,exist_ok=True)
shutil.copyfile(ROOT/"report/vendor/echarts.min.js",OUT/"_shared/js/echarts.min.js")
shutil.copyfile(ROOT/"report/vendor/ECHARTS-LICENSE.txt",OUT/"_shared/js/ECHARTS-LICENSE.txt")
for name in ["InstrumentSans-Regular.ttf","InstrumentSans-Bold.ttf","InstrumentSans-OFL.txt"]:
    if name.endswith(".txt"):
        (OUT/"_shared/fonts"/name).write_text("\n".join(line.rstrip() for line in (SKILL/"canvas-fonts"/name).read_text().splitlines())+"\n")
    else:
        shutil.copyfile(SKILL/"canvas-fonts"/name,OUT/"_shared/fonts"/name)
e=escape
def pct(v):return f"{v*100:+.2f}%"
def table(headers,rows):
    return '<div class="table-wrap"><table><thead><tr>'+''.join(f'<th>{e(str(v))}</th>' for v in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join(f'<td>{e(str(v))}</td>' for v in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def mt(headers,rows):return ['| '+' | '.join(headers)+' |','|'+'|'.join(['---']*len(headers))+'|']+['| '+' | '.join(str(v).replace('|','/') for v in row)+' |' for row in rows]
sources={p["id"]:i+1 for i,p in enumerate(n["sources"])}
def cite(ids):return ''.join(f'<sup><a href="#cite-{sources[i]}">[{sources[i]}]</a></sup>' for i in ids)
def figure(id,title):
    return f'<figure><figcaption>{e(title)}</figcaption><div class="chart" id="{id}"></div></figure>'
quote=x["market"]; snapshot=quote["retrieved_at"][:19].replace("T"," ")
dates=f"研究与行情快照：{snapshot}（北京时间，盘中）；境内正式净值至11月13日，QDII至11月12日。共同日频终点11月12日，完整周截止11月13日。"
parts=[f'<div class="eyebrow">组合研究 · {DATE}</div><h1>{e(n["headline"])}</h1><p class="lead">{e(n["verdict"])}</p><p class="muted">{e(dates)}</p><p class="muted">{e(n["status"])}</p>',
 '<nav><a href="../../">每日研究</a><a href="../../archive.html">日期档案</a><a href="../2026-11-09/">上期续评</a><a href="report.md" download>正文</a><a href="dataset.zip" download>数据与证据</a></nav>',
 '<h2>本周按执行状态处理</h2><label>执行状态 <select id="execution"><option value="all">未确认 · 查看全部分支</option><option value="0">完全未执行</option><option value="1">只做首批</option><option value="2">两批已完成</option></select></label>']
md=[f'# 组合研究 · {DATE}',"",n["headline"],"",n["verdict"],"",dates,"",n["status"],"","## 执行状态",""]
for i,row in enumerate(n["actions"]):
    parts.append(f'<article class="action" data-state="{i}"><h3>{e(row["state"])}</h3><p>{e(row["action"])}</p><p class="muted">{e(row["next"])}</p></article>')
    md+=['### '+row["state"],"",row["action"],"",row["next"],""]
parts.append(f'<p class="notice">{e(n["guardrails"])}</p>')
md += [n["guardrails"],"","## 最新表现",""]
parts += ['<h2>上周有反弹，今天仍有共同下跌压力</h2>',
          '<p>截至已公布净值，上周华商与低碳均上涨，广发主题小幅下跌。保留这些反证，才能衡量降低风险所付出的机会成本。今天的盘中价格是另一观察层，不计入下表基金收益。'+cite(["nav"])+'</p>']
market_rows=[[r["name"],f'{r["pct"]:+.2f}%',r["time"][8:10]+":"+r["time"][10:12]+":"+r["time"][12:14]] for r in quote["quotes"]]
parts += [table(["盘中标的","相对前收盘","报价时间"],market_rows),'<p class="muted">来自腾讯行情接口；盘中价会继续变化，ETF市价不是主动基金净值。</p>']
md+=mt(["盘中标的","相对前收盘","报价时间"],market_rows)+[""]
rows=[[p["name"],p["date"],pct(p["last_week"]),pct(p["since_last_review"]),pct(p["return20"])] for p in w["funds"]]
parts += [table(["基金","正式净值日","较上周对应终点","11月9日起","近20净值日"],rows),
 '<p class="muted">“较上周对应终点”：境内11月6日→13日、QDII11月5日→12日；这些列的窗口不相同，不作横向同日收益排名。</p>',
 '<label>收益窗口 <select id="window"><option value="since_last_review">11月9日以后</option><option value="return20">最近20净值日</option></select></label>',
 figure("fund-chart","基金收益与恢复能力"),f'<p>{e(n["manager"])}</p>']
md+=mt(["基金","净值日","较上期终点","11月9日起","近20日"],rows)+["",n["manager"],""]
parts += ['<h2>先核对此前建议的代价</h2>',
 '<p><strong>11月3日的两批方案截至11月12日落后于持有约1.1个百分点。</strong>11月9日的新首批方案截至同日也落后约0.44—0.48个百分点。以下逐笔按原定日期收盘执行，未把卖出当天的跌幅算成已规避；没有事后挑选卖点。'+cite(["nav"])+'</p>',
 '<label>冻结起点 <select id="audit"><option value="0">11月3日计划</option><option value="1">11月9日条件建议</option></select></label>',
 figure("audit-chart","原权重纸面跟踪：持有、首批、两批"),
 '<p id="audit-detail" class="muted"></p>']
audit_rows=[]
for audit in w["audits"]:
    for key,label in [("first_only","首批"),("both","两批")]:
        before=[r for r in audit["variants"] if r["execution"]==key]
        costs=[r for r in before if r["fee"]==.005]
        audit_rows.append([audit["start"],str(audit["intervals"]),label,pct(audit["hold"]["return"]),
              pct(min(r["return"] for r in costs))+" ～ "+pct(max(r["return"] for r in costs)),
              f'{min(r["difference"] for r in costs)*100:+.2f} ～ {max(r["difference"] for r in costs)*100:+.2f}个百分点'])
parts += [table(["起点","区间数","执行假设","保持原结构","扣费后方案","相对持有"],audit_rows),
          f'<p class="muted">{e(w["tracking_note"])} 低碳赎回费按0.5%，转入延迟0或1个交易日；实际持有超过一年等费率可能不同。11月9日第二批当时需复核，仅作条件比较。</p>']
md+=["## 原建议纸面跟踪",""]+mt(["起点","区间数","方案","持有","扣费后方案","差值"],audit_rows)+["",w["tracking_note"],""]
parts += ['<h2>本轮新增证据</h2>'];md+=["## 新增证据",""]
for row in n["news"]:
    parts.append(f'<article class="news"><h3>{e(row["title"])}</h3><p>{e(row["fact"])}{cite(row["sources"])}</p><p class="reading">{e(row["reading"])}</p></article>')
    md+=["### "+row["title"],"",row["fact"],"",row["reading"],""]+[f'[{n["sources"][sources[i]-1]["label"]}]({n["sources"][sources[i]-1]["url"]})' for i in row["sources"]]+[""]
parts+=['<h2>额外20日冲击：减损与少赚同时看</h2>',f'<p>{e(n["model_note"])}</p>',
 '<label>科益成交假设 <select id="inventory"><option value="reported">未确认买入 · 旧229万结构</option><option value="keyi_confirmed">若已买入 · 旧244万结构</option></select></label>',
 figure("scenario-chart","同条件响应：原结构与完成两批"),'<p id="scenario-detail" class="muted"></p>']
br=[[b["name"],pct(b["response"]["reported_hold"]["mean"]),pct(b["response"]["reported_first"]["mean"]),pct(b["response"]["reported_second"]["mean"])] for b in x["model"]["branches"]]
parts.append(table(["人工分支","保持原结构","完成首批","完成两批"],br))
md+=["## 条件推演","",n["model_note"],""]+mt(["分支","原结构","首批","两批"],br)+[""]
special=[[v["name"],pct(v["responses"]["reported_hold"]["min"])+" ～ "+pct(v["responses"]["reported_hold"]["max"]),pct(v["responses"]["reported_second"]["min"])+" ～ "+pct(v["responses"]["reported_second"]["max"])] for v in w["special"]]
parts+=['<details><summary>英伟达事件、国内需求与模型敏感性</summary>',table(["附加条件","原结构窗口范围","两批完成窗口范围"],special),f'<p>{e(w["event_note"])}</p>']
parts += [f'<p class="muted">{e(t)}</p>' for t in x["limits"]]+['</details>']
md+=mt(["条件","原结构","两批"],special)+["",w["event_note"],""]+x["limits"]+[""]
parts+=['<h2>本周观察节点</h2>'];md+=["## 下一观察节点",""]
for row in n["events"]:
    parts.append(f'<article class="news"><h3>{e(row["time"])} · {e(row["name"])}</h3><p>{e(row["positive"])}</p><p>{e(row["negative"])}{cite(row["sources"])}</p></article>')
    md+=["### "+row["time"]+" · "+row["name"],"",row["positive"],"",row["negative"],""]
parts += [f'<p>{e(n["fees"])}</p><p>{e(n["availability"])}</p>','<nav><a href="analysis.json">完整模型</a><a href="weekly.json">原计划跟踪</a><a href="weekly-verification.json">证据核验</a><a href="dataset.zip" download>证据与脚本</a><a href="manifest.json">文件哈希</a></nav>']
md += [n["fees"],"",n["availability"],"","## 来源",""]
parts.append('<footer><div class="sources"><h2>数据与来源</h2><ol>')
for i,s in enumerate(n["sources"],1):
    parts.append(f'<li id="cite-{i}"><span class="src-title">{e(s["label"])} · {e(s["status"])}</span><a class="src-url" href="{e(s["url"])}" target="_blank" rel="noopener">{e(s["url"])}</a></li>')
    md.append(f'{i}. [{s["label"]}]({s["url"]}) — {s["status"]}')
parts.append('</ol></div></footer>')
css="""@font-face{font-family:ReportSans;src:url('./_shared/fonts/InstrumentSans-Regular.ttf');font-weight:400}@font-face{font-family:ReportSans;src:url('./_shared/fonts/InstrumentSans-Bold.ttf');font-weight:700}:root{--bg:#0a0d0f;--bg2:#102016;--ink:#e4eee8;--muted:#a4b9ac;--rule:#334e3c;--accent:#aed7ae;--accent2:#a0bfd2;--down:#d0a3b5;--font:ReportSans,-apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif}*{box-sizing:border-box}html{color-scheme:dark}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.8 var(--font)}main{max-width:1180px;margin:auto;padding:44px 32px 80px}h1{font-size:48px;line-height:1.3;letter-spacing:-.035em}h2{margin-top:48px;font-size:25px}h3{font-size:19px}.lead{font-size:19px}.muted,.eyebrow{font-size:13px;color:var(--muted)}a{color:var(--accent);text-underline-offset:4px}nav{display:flex;flex-wrap:wrap;gap:20px;font-size:14px;margin:25px 0}.news,.action{border-top:1px solid var(--rule);padding:16px 0}.notice{border-block:1px solid var(--rule);padding:20px 0}.reading{color:var(--accent)}.table-wrap{overflow-x:auto;overflow-y:auto;max-height:600px}table{border-collapse:collapse;width:100%;font-size:14px}td,th{padding:12px 10px;border-bottom:1px solid var(--rule);text-align:left;vertical-align:top;min-width:105px}td:first-child{min-width:155px}th{color:var(--muted)}figure{margin:25px 0}figcaption{font-size:17px;font-weight:700;margin-bottom:10px}.chart{height:425px}select{max-width:100%;padding:9px;background:var(--bg2);color:var(--ink);border:1px solid var(--rule);font:inherit}details{margin-top:25px}summary{cursor:pointer;color:var(--accent)}sup a{font-size:.75em;text-decoration:none}footer .sources ol{padding-left:1.2rem;font-size:13px;color:var(--muted)}footer li{margin-bottom:14px;overflow-wrap:break-word}footer .src-title{color:var(--ink)}footer .src-url{display:block;word-break:break-all}.action[hidden]{display:none}@media(max-width:700px){main{padding:26px 19px 60px}h1{font-size:34px}h2{font-size:23px}.lead{font-size:17px}table{min-width:590px}td,th{font-size:13px}.chart{height:420px}}@media print{nav,select,label{display:none}.action[hidden]{display:block}.table-wrap{max-height:none;overflow:visible}.news,figure{break-inside:avoid}main{max-width:none;padding:0}}"""
html=f'<!-- Generated by Trae Work -->\n<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>组合研究 · {DATE}</title><style>{css}</style></head><body><main>{"".join(parts)}</main><script src="./_shared/js/echarts.min.js"></script><script src="./assets/data.js"></script><script src="./assets/charts.js"></script></body></html>'
for name in ["index.html",f"{DATE}.html"]:(OUT/name).write_text(html)
(OUT/"report.md").write_text("\n".join(md))
(OUT/"assets/data.js").write_text("window.REVIEW_DATA="+json.dumps({"analysis":x,"weekly":w},ensure_ascii=False).replace("<","\\u003c")+";")
shutil.copyfile(ROOT/"report/weekly-review-charts.js",OUT/"assets/charts.js")
for name in ["analysis.json","weekly.json","verification.json","weekly-verification.json","web-observations.json"]:
    shutil.copyfile(BASE/name,OUT/name)
shutil.copyfile(ROOT/f"research/weekly_notes_{DATE}.json",OUT/"notes.json")
files=list(BASE.rglob("*"));files=[p for p in files if p.is_file()]
files += [ROOT/key for key in x["inputs"]]+[ROOT/key for key in w["inputs"]]
files += [ROOT/f"research/weekly_notes_{DATE}.json",ROOT/f"research/transition_sources_{DATE}.json",ROOT/"report/weekly-review-charts.js"]
files += [ROOT/"tools"/name for name in ["collect_transition.py","collect_market_snapshot.py","analyze_transition.py","analyze_weekly_review.py","verify_transition.py","verify_weekly_review.py","build_weekly_review.py","check_weekly_review.py","collect_history.py","archive_deep_sources.py"]]
with zipfile.ZipFile(OUT/"dataset.zip","w",zipfile.ZIP_DEFLATED) as z:
    for p in dict.fromkeys(files):z.write(p,str(p.relative_to(ROOT)))
manifest={"date":DATE,"status":"execution_unconfirmed","market_status":quote["status"],"files":{str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.rglob("*") if p.is_file() and p.name!="manifest.json"}}
(OUT/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
registry=PUBLIC/"proposals/index.json";rows=[r for r in json.loads(registry.read_text()) if r["date"]!=DATE]
rows.append({"date":DATE,"path":f"proposals/{DATE}/","title":"英伟达事件、通胀与原调仓计划复核","status":"execution_unconfirmed"})
registry.write_text(json.dumps(sorted(rows,key=lambda r:r["date"],reverse=True),ensure_ascii=False,indent=2))
print(str(OUT/"index.html"))
