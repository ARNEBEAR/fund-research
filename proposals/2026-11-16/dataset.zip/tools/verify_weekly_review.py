"""Independently reconcile dated paper portfolios and primary-source facts."""
import hashlib,json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/"data/transition_review/2026-11-16"
w=json.loads((BASE/"weekly.json").read_text())
x=json.loads((BASE/"analysis.json").read_text())
for name,digest in w["inputs"].items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
frames={c:pd.read_csv(BASE/"nav"/f"{c}.csv",index_col="date",parse_dates=True).wealth for c in x["codes"]}
common=pd.DataFrame(frames).dropna()
for audit in w["audits"]:
    start=pd.Timestamp(audit["start"]);end=pd.Timestamp(audit["end"])
    frozen=json.loads((ROOT/f'data/transition_review/{audit["start"]}/analysis.json').read_text())
    weights=next(p for p in frozen["plans"] if p["id"]=="reported_hold")["weights"]
    hold=sum(weights[c]*(s.loc[end]/s.loc[start]-1) for c,s in frames.items())
    assert np.isclose(hold,audit["hold"]["return"])
    scheduled=["2026-11-04","2026-11-06"] if audit["start"]=="2026-11-03" else ["2026-11-10","2026-11-12"]
    for variant in audit["variants"]:
        dates=scheduled[:1] if variant["execution"]=="first_only" else scheduled
        delta=0.
        for textdate in dates:
            when=pd.Timestamp(textdate)
            if when>end:continue
            due=when+pd.offsets.BDay(variant["delay"])
            available=common.index[(common.index>=due)&(common.index<=end)]
            entry=available[0] if len(available) else None
            for c,fraction in [("011370",.5),("002244",1/3)]:
                amount=weights[c]*fraction*frames[c].loc[when]/frames[c].loc[start]
                recipient=frames["021902"].loc[end]/frames["021902"].loc[entry] if entry is not None else 1
                source=frames[c].loc[end]/frames[c].loc[when]
                fee=variant["fee"] if c=="002244" else 0
                delta+=amount*((1-fee)*recipient-source)
        assert np.isclose(delta,variant["difference"])
        assert np.isclose(hold+delta,variant["return"])
        assert variant["path"][0]==0 or abs(variant["path"][0])<1e-12
        assert len(variant["path"])==len(audit["dates"])
for p in w["funds"]:
    s=frames[p["code"]]
    assert np.isclose(s.iloc[-1]/s.loc["2026-11-09"]-1,p["since_last_review"])
source=BASE/"sources"
primary_checks={
    "nvidia_transition.txt":["November 12, 2026","has resigned","Interim Chief Executive Officer"],
    "nvidia_event.txt":["November 17","1:20 p.m. PT","2 p.m. PT"],
    "china_activity.txt":["4.8%","17.6%","下降8.1%","增长28.7%"],
    "china_retail.txt":["0.4%","1.0%"]
}
for filename,terms in primary_checks.items():
    text=" ".join((source/filename).read_text().split())
    assert all(t in text for t in terms),(filename,terms)
pdf="".join(p["text"] for p in json.loads((source/"buyback_tf_first.text.json").read_text()))
compact="".join(pdf.split())
assert "14,543,408.76" in compact and "0.0092%" in compact and "2026年11月12日" in compact
q=json.loads((BASE/"market.json").read_text())
assert q["status"]=="intraday" and all(r["time"].startswith("20261116") for r in q["quotes"])
for ev in w["special"]:
    assert len(ev["shock"])==12
    for p in x["plans"]:
        weights=np.array([p["weights"][c] for c in x["codes"]])
        expected=[]
        for fit in [x["model"]]+x["sensitivity"]:
            b=np.array([fit["coefficients"][c] for c in x["codes"]])
            expected.append(float(weights@np.expm1(b@np.log1p(ev["shock"]))))
        assert np.allclose(expected,ev["responses"][p["id"]]["values"])
result={"passed":True,"date":"2026-11-16","checks":["两套冻结权重及计划日期","逐笔现金流独立复算","费用与在途敏感性","最新逐只收益","英伟达原文和时间","国内经济原文","天孚实际回购","盘中与收盘口径","人工附加冲击复算"],
        "limits":"数据与计算核验不等于预测验证；未获用户成交或最新市值；BLS与FRED本地获取失败的全文未伪造，摘录另列。"}
(BASE/"weekly-verification.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
