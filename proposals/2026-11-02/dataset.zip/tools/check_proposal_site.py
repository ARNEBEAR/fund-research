"""Verify the allocation proposal through rendered controls and downloadable artifacts."""
import argparse
import hashlib
import json
import os
import threading
import zipfile
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / "publish/github-pages"
DATE = "2026-11-02"
parser = argparse.ArgumentParser()
parser.add_argument("--url", help="Site root, including fund-research when hosted on Pages")
args = parser.parse_args()
target = PUBLIC / "proposals" / DATE
manifest = json.loads((target / "manifest.json").read_text())
for filename, digest in manifest["files"].items():
    assert hashlib.sha256((target / filename).read_bytes()).hexdigest() == digest
registry = json.loads((PUBLIC / "reports/index.json").read_text())
for row in registry:
    folder = PUBLIC / row["path"]
    old = json.loads((folder / "manifest.json").read_text())
    for filename, digest in old["files"].items():
        assert hashlib.sha256((folder / filename).read_bytes()).hexdigest() == digest

server = None
if args.url:
    url = args.url.rstrip("/") + "/"
else:
    class Quiet(SimpleHTTPRequestHandler):
        def log_message(self, *args):
            pass
    server = ThreadingHTTPServer(("127.0.0.1", 0), partial(Quiet, directory=str(PUBLIC)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{server.server_address[1]}/"

screens = ROOT / "report/proposal-check"
screens.mkdir(parents=True, exist_ok=True)
errors = []
with sync_playwright() as pw:
    launch = {"headless": True}
    if os.environ.get("CHROMIUM_EXECUTABLE"):
        launch["executable_path"] = os.environ["CHROMIUM_EXECUTABLE"]
    browser = pw.chromium.launch(**launch)
    for width in [1440, 390]:
        page = browser.new_page(viewport={"width": width, "height": 950 if width == 1440 else 844})
        page.on("pageerror", lambda error: errors.append(str(error)))
        page.on("console", lambda message: errors.append(message.text) if message.type == "error" else None)
        page.goto(url + "archive.html", wait_until="networkidle")
        page.wait_for_function("window.PROPOSAL_ARCHIVE_READY")
        page.locator(f'#proposals a[href="proposals/{DATE}/"]').click()
        page.wait_for_function("window.PROPOSAL_READY && window.PROPOSAL_DATES_READY")
        assert page.locator("canvas").count() == 3
        assert page.locator("#date-picker").input_value() == f"reports/{DATE}/"
        assert "待评估" in page.locator("main").inner_text()
        assert "蔡铮单独管理" in page.locator("main").inner_text()
        assert "0.10 ～ 1.35" in page.locator("main").inner_text()
        assert page.evaluate("document.documentElement.scrollWidth <= innerWidth + 1")
        page.screenshot(path=str(screens / f"overview-{width}.png"))
        risk_before = page.locator("#risk-chart").evaluate("(el)=>echarts.getInstanceByDom(el).getOption().series[1].data")
        page.select_option("#risk-window", "weekly")
        risk_after = page.locator("#risk-chart").evaluate("(el)=>echarts.getInstanceByDom(el).getOption().series[1].data")
        assert risk_before != risk_after
        page.select_option("#risk-window", "recent")
        for plan in ["six_controlled", "gold6", "old"]:
            page.select_option("#path-plan", plan)
            chart = page.locator("#path-chart").evaluate("(el)=>echarts.getInstanceByDom(el).getOption()")
            assert chart["series"][0]["data"][0] == chart["series"][1]["data"][0] == 0
            assert chart["xAxis"][0]["data"][0] == "2026-04-16"
            assert len(chart["series"]) == 2
        for branch in ["bull", "bear", "rates", "base"]:
            before = page.locator("#scenario-detail").inner_text()
            page.select_option("#scenario-select", branch)
            after = page.locator("#scenario-detail").inner_text()
            assert after != before and "最弱10%" in after
        for selector in ["risk-chart", "path-chart", "scenario-chart"]:
            page.locator("#" + selector).scroll_into_view_if_needed()
            page.screenshot(path=str(screens / f"{selector}-{width}.png"))
        page.locator("details > summary").click()
        assert page.locator("details").get_attribute("open") is not None
        assert page.evaluate("document.documentElement.scrollWidth <= innerWidth + 1")
        # Use the rendered download link, and validate every public artifact over HTTP.
        datafile = screens / f"dataset-{width}.zip"
        with page.expect_download() as download:
            page.locator('a[href="dataset.zip"]').first.click()
        download.value.save_as(str(datafile))
        with zipfile.ZipFile(datafile) as z:
            assert z.testzip() is None
            assert "tools/verify_proposal.py" in z.namelist()
        for filename, digest in manifest["files"].items():
            response = page.request.get(url + f"proposals/{DATE}/" + filename)
            assert response.ok and hashlib.sha256(response.body()).hexdigest() == digest, filename
        previous = registry[1]
        page.select_option("#date-picker", previous["path"])
        page.wait_for_url("**/" + previous["path"])
        page.goto(url, wait_until="networkidle")
        assert f'/reports/{registry[0]["date"]}/' in page.url
        page.close()
    browser.close()
if server:
    server.shutdown()
assert not errors, errors
receipt = {
    "date": DATE, "passed": True, "site": args.url or "local",
    "viewports": [1440, 390],
    "checks": ["三图与真实选择器交互", "历史路径起点归零", "日期导航与默认最新",
               "档案提案入口", "无页面溢出及脚本错误", "下载包及逐文件哈希", "旧报告哈希不变"],
    "proposal_manifest_sha256": hashlib.sha256((target / "manifest.json").read_bytes()).hexdigest(),
}
(screens / ("live.json" if args.url else "local.json")).write_text(json.dumps(receipt, ensure_ascii=False, indent=2))
print(json.dumps(receipt, ensure_ascii=False))
