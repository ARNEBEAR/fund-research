"""Paired same-sample comparison of a proposed allocation; no portfolio or probability optimization."""
import hashlib,itertools,json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import linprog

ROOT=Path(__file__).resolve().parents[1]
DATE="2026-11-02";BASE=ROOT/"data/proposal_review"/DATE
config=json.loads((ROOT/f"research/proposal_{DATE}.json").read_text())
old=json.loads((ROOT/f"publish/github-pages/reports/{DATE}/analysis.json").read_text())
daily=json.loads((ROOT/"research/daily_config.json").read_text())
q=json.loads((ROOT/"data/quarter_review/2026-10-29/analysis.json").read_text())
plans=[{"id":"proposal","name":"用户新8只方案","weights":config["weights"]},
       {"id":"old","name":"10月19日原目标","weights":{p["code"]:p["amount_cny"]/old["policy"]["total_cny"] for p in old["policy"]["positions"]}}]+config["alternatives"]
codes=list(dict.fromkeys(c for plan in plans for c in plan["weights"]))
factors=daily["forward_factor_model"]["factor_codes"]+["513100","513180"]
frames={c:pd.read_csv(BASE/"nav"/f"{c}.csv",parse_dates=["date"]).set_index("date") for c in set(codes+factors)}
levels=pd.DataFrame({c:frames[c].wealth for c in codes}).dropna().loc["2026-04-16":]
native=pd.DataFrame({c:frames[c]["return"] for c in codes}).dropna()
# Exclude each fund's unobservable first daily return.
native=native.loc[native.index>levels.index[0]]
W={p["id"]:np.array([p["weights"].get(c,0) for c in codes]) for p in plans}
assert all(np.isclose(v.sum(),1) and (v>=0).all() for v in W.values())

def stats(returns,frequency):
    path=np.r_[1,np.cumprod(1+returns)]
    return {"return":float(path[-1]-1),"vol":float(np.std(returns,ddof=1)*np.sqrt(frequency)),
            "mdd":float(np.min(path/np.maximum.accumulate(path)-1))}

def risk(frame,w):
    cov=frame.cov().to_numpy()
    return dict(zip(codes,(w*(cov@w)/(w@cov@w)).tolist()))

def periods_stats(start,end):
    # Historical wealth uses common endpoint intervals so missing dates never erase P&L.
    d=levels.loc[start:end]
    r=d.pct_change(fill_method=None).dropna()
    return {"start":str(d.index[0].date()),"end":str(d.index[-1].date()),"n":len(r),
            "plans":{k:{**stats(r.to_numpy()@w,252),
                         "buyhold_return":float((d.iloc[-1]/d.iloc[0]-1).to_numpy()@w)}
                     for k,w in W.items()}}

periods={k:periods_stats(s,e) for k,s,e in [
    ("common","2026-04-16",DATE),("Q3","2026-06-30","2026-09-30"),
    ("October","2026-09-30",DATE),("after_last_review","2026-10-29",DATE)]
    if len(levels.loc[s:e])>1}
grid=pd.date_range(levels.index[0],pd.Timestamp(DATE)-pd.Timedelta(days=1),freq="W-FRI")
weekly=pd.DataFrame(index=grid)
for c in codes:
    s=frames[c].wealth
    weekly[c]=[s.iloc[j] if (j:=s.index.searchsorted(t,side="right")-1)>=0 and (t-s.index[j]).days<=7 else np.nan for t in grid]
wr=weekly.pct_change(fill_method=None).dropna().tail(26)
weekly_results={k:{**stats(wr.to_numpy()@w,52),"risk":risk(wr,w)} for k,w in W.items()}
recent=native.tail(20)
recent_risk={k:risk(recent,w) for k,w in W.items()}
pairs=[("010390","011370"),("022184","021662"),("021180","021902"),("022415","021902"),("027170","006075")]
correlations=[{"a":a,"b":b,"daily60":float(native.tail(60)[a].corr(native.tail(60)[b])),
               "daily20":float(recent[a].corr(recent[b])),"weekly26":float(wr[a].corr(wr[b]))}
              for a,b in pairs]

# Q3 accounting weights are a frozen structural diagnostic, never today's estimated portfolio.
fund_equity_extra={"027170":9.69,"022184":2.07,"021662":0,"006075":92.35}
structure={}
for plan in plans:
    w=plan["weights"]
    stock=sum(v*(q["funds"][c]["3"]["stock_pct_net"]+fund_equity_extra.get(c,0))/100 for c,v in w.items())
    cash=sum(v*q["funds"][c]["3"]["cash_pct_net"]/100 for c,v in w.items() if q["funds"][c]["3"]["cash_pct_net"] is not None)
    structure[plan["id"]]={"stock_and_equity_fund_proxy":stock,"cash_and_settlement_net":cash,
       "gold_fund_weight":w.get("002611",0),"largest_manager":max(w.values()),"hhi":sum(v*v for v in w.values())}
structure["proposal"]["top_three_equity_contribution"]=sum(config["weights"][c]*q["funds"][c]["3"]["stock_pct_net"]/100 for c in ["021180","022415","021902"])
structure["proposal"]["gf_cash_contribution"]=.25*q["funds"]["021902"]["3"]["cash_pct_net"]/100
# Exact disclosed industry components, not additive to the equity estimate above.
structure["proposal"]["mining_domestic_plus_hk_energy_materials"]=.18*(36.23+.38+1.67)/100+.25*(13.31+1.22+8.25)/100+.25*13.85/100
structure["proposal"]["fuguo_asia_top3_overlap_pct_fund"]=min(7.14,6.18+2.69)+min(8.40,6.85)+min(7.69,6.92)
structure["proposal"]["fuguo_asia_top3_target"]=.06*(7.14+8.40+7.69)/100+.03*(6.18+2.69+6.85+6.92)/100

# Same stress factors and paired block innovations for every plan.
returns=pd.DataFrame({c:np.log1p(frames[c]["return"]) for c in set(codes+factors)}).dropna()
returns=returns.loc[returns.index>levels.index[0]].loc["2026-05-30":]
selectors={**daily["forward_factor_model"]["selectors"],"027170":[3,10,11],
           "022184":[3,10,11,5],"021662":[10,11,5]}
branches=old["policy"]["scenarios"]
extra_global={"base":[.01,0],"bull":[.07,.08],"bear":[-.12,-.15],"rates":[-.15,-.18]}
shocks={s["id"]:np.array([s[k] for k in ["market","communication","dividend","sp500","gold"]]+
    daily["forward_factor_model"]["extra_shocks"][s["id"]]+extra_global[s["id"]]) for s in branches}
bounds=[daily["branch_weight_bounds"][s["id"]] for s in branches]
vertices=[]
for free in range(4):
    rest=[i for i in range(4) if i!=free]
    for choices in itertools.product([0,1],repeat=3):
        p=np.zeros(4)
        for i,k in zip(rest,choices):p[i]=bounds[i][k]
        p[free]=1-p.sum()
        if bounds[free][0]-1e-9<=p[free]<=bounds[free][1]+1e-9:vertices.append(p)
vertices=np.unique(np.round(vertices,10),axis=0)

def fit(X,Y,index,ridge):
    B=np.zeros((len(codes),len(factors)));intercept=np.zeros(len(codes))
    for i,c in enumerate(codes):
        if c in ["002611","006075"]:
            B[i,4 if c=="002611" else 3]=1;continue
        selected=selectors[c];x=X[index][:,selected];y=Y[index,i]
        mean=x.mean(0);sd=x.std(0);z=(x-mean)/sd
        coef=np.linalg.solve(z.T@z+ridge*np.eye(len(selected)),z.T@(y-y.mean()))/sd
        B[i,selected]=coef;intercept[i]=y.mean()-mean@coef
    return B,intercept

def run_model(window,ridge,simulate):
    r=returns.tail(window);X=r[factors].to_numpy();Y=r[codes].to_numpy();n=len(r)
    B,intercept=fit(X,Y,np.arange(n),ridge)
    result={"n":n,"window":window,"ridge":ridge,"start":str(r.index[0].date()),"end":str(r.index[-1].date()),
            "coefficients":dict(zip(codes,B.tolist())),"conditional":{}}
    for s in branches:
        fr=np.expm1(B@np.log1p(shocks[s["id"]]))
        result["conditional"][s["id"]]={k:float(fr@w) for k,w in W.items()}
    if not simulate:return result
    rng=np.random.default_rng(20261102);horizon=20;nsim=2400
    def block(length,reps):
        starts=rng.integers(0,n-4,size=(reps,int(np.ceil(length/5))))
        return (starts[:,:,None]+np.arange(5)).reshape(reps,-1)[:,:length]
    residual=Y-X@B.T-intercept
    innovations=np.column_stack([X-X.mean(0),residual-residual.mean(0)])[block(horizon,nsim)]
    draws=np.array([fit(X,Y,i,ridge)[0] for i in block(n,300)])[np.arange(nsim)%300]
    terminals={k:[] for k in W};detail=[]
    for s in branches:
        multiplier=1.35 if s["id"] in ["bear","rates"] else 1
        path=np.log1p(shocks[s["id"]])[None,None,:]/horizon+innovations[:,:,:len(factors)]*.5*multiplier
        fr=np.expm1(np.einsum("sdf,skf->sdk",path,draws)+innovations[:,:,len(factors):]*multiplier)
        responses={}
        for k,w in W.items():
            end=np.prod(1+fr@w,axis=1)-1;terminals[k].append(end)
            quant=np.quantile(end,[.1,.5,.9])
            responses[k]={"mean":float(end.mean()),"q10":float(quant[0]),"median":float(quant[1]),"q90":float(quant[2]),
                          "es10":float(end[end<=quant[0]].mean()),"loss5_fraction":float((end<=-.05).mean())}
        detail.append({"id":s["id"],"name":s["name"],"shock":shocks[s["id"]].tolist(),"responses":responses})
    robust=[]
    for k,values in terminals.items():
        values=np.array(values);means=values.mean(1)
        expected=vertices@means;pos=vertices@np.maximum(values,0).mean(1);neg=vertices@np.maximum(-values,0).mean(1)
        lo=linprog(means,A_eq=[[1]*4],b_eq=[1],bounds=bounds,method="highs")
        hi=linprog(-means,A_eq=[[1]*4],b_eq=[1],bounds=bounds,method="highs")
        assert lo.success and hi.success and np.allclose([lo.fun,-hi.fun],[expected.min(),expected.max()])
        ratio=pos/neg
        robust.append({"id":k,"mean_range":[float(expected.min()),float(expected.max())],
                       "gain_loss_ratio_range":[float(ratio.min()),float(ratio.max())]})
    np.savez_compressed(BASE/"paths.npz",**{k:np.array(v) for k,v in terminals.items()})
    result.update(branches=detail,robust=robust,vertices=vertices.tolist(),simulations=nsim)
    return result

model=run_model(60,5,True)
sensitivity=[run_model(n,ridge,False) for n,ridge in [(40,5),(100,5),(60,0),(60,10)]]
special_shocks=[
    {"id":"domestic_demand","name":"国内需求与资源走弱、海外科技未塌",
     "shock":[-.05,0,-.04,0,.03,0,-.15,-.10,-.05,-.08,.01,-.02]},
    {"id":"broadening","name":"国内修复扩散、科技温和修复",
     "shock":[.04,.03,.04,.02,0,.03,.08,.06,.06,.06,.03,.03]}
]
special=[]
for branch in special_shocks:
    responses={k:[] for k in W}
    for fit_result in [model]+sensitivity:
        B=np.array([fit_result["coefficients"][c] for c in codes])
        fund=np.expm1(B@np.log1p(branch["shock"]))
        for k,w in W.items():responses[k].append(float(fund@w))
    special.append({**branch,"responses":{k:{"min":min(v),"max":max(v),"values":v} for k,v in responses.items()}})
latest=[{"code":c,"date":str(frames[c].index[-1].date()),"nav":float(frames[c].unit_nav.iloc[-1]),
         "return20":float(frames[c].wealth.iloc[-1]/frames[c].wealth.iloc[-21]-1)} for c in codes]
replay=levels.pct_change(fill_method=None).dropna()
paths={k:np.r_[0,np.cumprod(1+replay.to_numpy()@w)-1].tolist() for k,w in W.items()}
result={"date":DATE,"config":config,"plans":plans,"codes":codes,"latest":latest,"periods":periods,
        "weekly":{"n":len(wr),"start":str(wr.index[0].date()),"end":str(wr.index[-1].date()),"results":weekly_results},
        "recent_risk":{"start":str(recent.index[0].date()),"end":str(recent.index[-1].date()),"n":len(recent),"results":recent_risk},
        "correlations":correlations,"structure":structure,"model":model,"model_sensitivity":sensitivity,
        "factors":factors,"special_stress":special,"historical_paths":{"dates":[str(levels.index[0].date())]+[str(d.date()) for d in replay.index],"plans":paths},
        "limits":["新组合只为待评估方案；无实际交易或总账户金额假设。",
                  "同样本回放不等于当时可获知的策略，未复原个人交易。回放在共同估值日恢复权重，跨缺失日按共同端点复合，另列不再平衡；缺值不填0。",
                  "持仓结构按9月30日法定披露，未用季度后价格重建实际持仓；QDII与股票ETF按净值日期对齐仍存在时区差异。",
                  "海外科技仅有宽基、纳指、港股科技与境内半导体代理，未独立解释台湾/韩国/存储因子；完整保留残差但不能消除模型遗漏。",
                  "前瞻60日岭回归λ=5，40/100日、λ=0/10作敏感性；共同5日块300次参数重采样、2400条路径。因子半倍扰动、压力残差1.35倍，均未样本外校准。",
                  "不外推截距；四分支是条件情景而非完备世界状态，人工权重范围未校准。盈亏比不是真实市场赔率。",
                  "股金同跌不一定最坏；不包含全部流动性与估值跳空，也未扣个人申赎费和在途。"],
        "inputs":{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in
          list((BASE/"nav").glob("*.csv"))+[ROOT/f"research/proposal_{DATE}.json",ROOT/"research/daily_config.json",ROOT/"data/quarter_review/2026-10-29/analysis.json",ROOT/f"publish/github-pages/reports/{DATE}/analysis.json",Path(__file__)]}}
(BASE/"analysis.json").write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
print(json.dumps({"structure":structure,"weekly":weekly_results,"October":periods["October"],"correlations":correlations,
                  "robust":model["robust"],"branches":[{"name":b["name"],"means":{k:r["mean"] for k,r in b["responses"].items()}} for b in model["branches"]]},ensure_ascii=False,indent=2))
