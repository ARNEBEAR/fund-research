"""Publish a separate allocation proposal without changing frozen daily reports or accepted weights."""
import hashlib,json,shutil,zipfile
from html import escape as e
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];DATE="2026-11-02";BASE=ROOT/"data/proposal_review"/DATE
PUBLIC=ROOT/"publish/github-pages";TARGET=PUBLIC/"proposals"/DATE
x=json.loads((BASE/"analysis.json").read_text());n=json.loads((ROOT/f"research/proposal_notes_{DATE}.json").read_text())
v=json.loads((BASE/"verification.json").read_text());assert v["passed"]
TARGET.mkdir(parents=True,exist_ok=True)
names=x["config"]["names"];codes=x["codes"];plan_names={p["id"]:p["name"] for p in x["plans"]}
def pct(x):return f"{x*100:+.2f}%"
def plain(x):return f"{x*100:.2f}%"
def table(headers,rows):return '<div class="scroll"><table><thead><tr>'+''.join(f"<th>{e(h)}</th>" for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join(f"<td>{e(str(c))}</td>" for c in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def mdtable(headers,rows):return ['| '+' | '.join(headers)+' |','|'+'|'.join(['---']*len(headers))+'|']+['| '+' | '.join(str(c).replace('|','/') for c in row)+' |' for row in rows]
latest={r["code"]:r for r in x["latest"]}
date_note=f'报告{DATE}；境内正式净值至{latest["021180"]["date"]}，QDII至{latest["027170"]["date"]}；持仓穿透仍为9月30日快照，经理公告另更新。'
risk=x["recent_risk"]["results"]["proposal"]
tech=["010390","011370","022184","021662"]
sumrisk=sum(risk[c] for c in tech)
parts=[f"<div class='eyebrow'>ALLOCATION REVIEW / {DATE}</div><h1>{e(n['headline'])}</h1><p class='lead'>{e(n['verdict'])}</p>",
       f"<p class='muted'>{e(n['scope'])}</p><p class='muted'>{e(date_note)}</p>",
       '<nav><a href="../../">最新每日研究</a><a href="../../reports/2026-10-29/quarterly.html">三季报经理重审</a><a href="report.md">下载正文</a><a href="dataset.zip">数据与证据</a><label>历史日期 <select id="date-picker" aria-label="切换报告日期"></select></label></nav>',
       "<div class='kpis'>"+''.join(f"<div><small>{a}</small><strong>{b}</strong><p>{c}</p></div>" for a,b,c in [
           ("前三只合计","68%","含资源、高仓位价值、低仓位平衡三种职责"),
           ("科技四只金额 / 近期方差贡献",f"26% / {sumrisk*100:.1f}%","最近20个共同净值日；不是未来损失比例"),
           ("穿透股票及股票基金",plain(x["structure"]["proposal"]["stock_and_equity_fund_proxy"]),"三季报静态近似；较旧目标约72.1%高")])+"</div>",
       "<section class='cards'>"+''.join(f"<article><h3>{e(j['title'])}</h3><p>{e(j['text'])}</p></article>" for j in n["judgments"])+"</section>",
       "<h2>你给的8只，逐一判断</h2>"]
rows=[[names[a["code"]],f'{a["weight"]}%',a["judgment"],a["reason"]] for a in n["actions"]]
parts.append(table(["基金","权重","判断","依据"],rows))
md=[f"# 8只组合审视 · {DATE}","",n["headline"],"",n["verdict"],"",n["scope"],"",date_note,"",
    "## 逐只判断",""]+mdtable(["基金","权重","判断","依据"],rows)
md += ["","## 结构判断",""]+[f'### {j["title"]}\n\n{j["text"]}\n' for j in n["judgments"]]
parts += ["<h2>风险由谁贡献</h2><label>窗口 <select id='risk-window'><option value='recent'>最近20个共同日</option><option value='weekly'>最近26周</option></select></label><div class='chart' id='risk-chart'></div>",
          "<p class='muted'>同一共同样本协方差的组合方差分解。贡献可负，不代表永久对冲；与权重差异反映波动和共同涨跌。周频与日频不直接混作同一种证据。</p>"]
corr_rows=[[names[c["a"]]+" / "+names[c["b"]],f'{c["daily20"]:.2f}',f'{c["daily60"]:.2f}',f'{c["weekly26"]:.2f}'] for c in x["correlations"]]
parts += [table(["基金对","20日相关","60日相关","26周相关"],corr_rows),
          "<p>产业与广发长窗口曾为负相关，但近期转正。前海与广发近期也共同波动；不能把过去科技与价值轮动带来的负相关永久化。</p>"]
md += ["","## 共同风险","",f'科技四只26%的资金，最近20个共同净值日方差贡献{sumrisk*100:.1f}%；最近26周约{sum(x["weekly"]["results"]["proposal"]["risk"][c] for c in tech)*100:.1f}%。不是未来损失比例。',""]+mdtable(["基金对","20日","60日","26周"],corr_rows)
parts.append("<h2>同额、同日期，比较旧目标与新方案</h2>")
comp=[]
for id in ["proposal","old","six_controlled","six","smaller_satellites","gold6"]:
    o=x["periods"]["October"]["plans"][id];w=x["weekly"]["results"][id]
    comp.append([plan_names[id],plain(w["vol"]),pct(w["mdd"]),pct(o["return"]),pct(o["buyhold_return"])])
parts += [table(["方案","26周年化波动","26周最大回撤","10月共同日恢复权重","10月不再平衡"],comp),
          f'<p class="muted">共同周截至{x["weekly"]["end"]}，最近{x["weekly"]["n"]}周；10月比较为{x["periods"]["October"]["start"]}—{x["periods"]["October"]["end"]}。正式净值的共同日恢复权重，非账户实盘。季末持仓变化使历史回放对未来参考能力有限。</p>',
          "<label>对照 <select id='path-plan'>"+''.join(f"<option value='{p['id']}'>{e(p['name'])}</option>" for p in x["plans"] if p["id"]!="proposal")+"</select></label><div class='chart' id='path-chart'></div>",
          "<p class='muted'>历史路径从2026年4月16日共同起点归零，跨缺失日采用共同端点复合；不是当时已发布的策略，也不是事后策略选择的验证。</p>"]
md += ["","## 同样本历史比较",""]+mdtable(["方案","26周年化波动","26周回撤","10月恢复权重","10月不再平衡"],comp)
md += ["",n["fair_comparison"],""]
parts.append("<h2>未来20日：收益与损失交换</h2><p class='muted'>手工分支及权重范围；模型路径比例没有校准为市场概率。全部方案用同一模型、同一参数与残差扰动比较。</p>")
robust_rows=[]
for r in x["model"]["robust"]:
    robust_rows.append([plan_names[r["id"]],pct(r["mean_range"][0])+" ～ "+pct(r["mean_range"][1]),f'{r["gain_loss_ratio_range"][0]:.2f} ～ {r["gain_loss_ratio_range"][1]:.2f}'])
parts += [table(["方案","人工权重下期望响应范围","条件盈亏比"],robust_rows),
          "<label>分支 <select id='scenario-select'>"+''.join(f"<option value='{b['id']}'>{e(b['name'])}</option>" for b in x["model"]["branches"])+"</select></label><div id='scenario-chart' class='chart'></div><div id='scenario-detail'></div>",
          "<p class='muted'>盈亏比=该权重假设下正收益期望/负收益绝对值期望；10/90分位与最弱10%均值不是未来置信区间或损失上限。2400条路径/分支；不外推回归截距。</p>"]
md += ["## 条件模型",""]+mdtable(["方案","期望响应范围","盈亏比"],robust_rows)
branch_rows=[[b["name"],pct(b["responses"]["proposal"]["mean"]),pct(b["responses"]["old"]["mean"]),pct(b["responses"]["six_controlled"]["mean"]),
              pct(b["responses"]["proposal"]["q10"]),pct(b["responses"]["proposal"]["es10"])] for b in x["model"]["branches"]]
md += [""]+mdtable(["分支","新8只均值","旧10只均值","控制卫星6只","新8只10分位","新8只最弱10%"],branch_rows)
special_rows=[[b["name"],pct(b["responses"]["proposal"]["min"])+" ～ "+pct(b["responses"]["proposal"]["max"]),
               pct(b["responses"]["old"]["min"])+" ～ "+pct(b["responses"]["old"]["max"]),
               pct(b["responses"]["six_controlled"]["min"])+" ～ "+pct(b["responses"]["six_controlled"]["max"])] for b in x["special_stress"]]
parts += ["<h3>单独检查：资源不是科技保险</h3>",table(["追加压力","新8只模型窗口范围","旧10只同模型范围","控制卫星6只"],special_rows),
          "<p class='muted'>额外两分支只比较40/60/100日与不同正则强度的响应，不纳入上方盈亏比权重，不是未来分位数。</p>"]
md += ["","### 追加情境",""]+mdtable(["压力","新8只","旧10只","控制卫星6只"],special_rows)
factor_names=["沪深300","通信","红利","人民币标普","黄金","半导体","有色","煤炭","创新药","医药","人民币纳指","恒生科技"]
shock_rows=[[b["name"]]+[pct(s) for s in b["shock"]] for b in x["model"]["branches"]+x["special_stress"]]
parts += ["<details><summary>全部冲击假设与模型限制</summary>",table(["分支"]+factor_names,shock_rows),
          ''.join(f"<p>{e(t)}</p>" for t in x["limits"])+"</details>"]
md += ["","### 冲击假设",""]+mdtable(["分支"]+factor_names,shock_rows)+[""]+x["limits"]
parts.append("<h2>最近新增证据，怎样改变判断</h2>")
for item in n["new_evidence"]:
    parts.append(f"<article class='evidence'><h3><a href='{e(item['url'])}'>{e(item['title'])} ↗</a></h3><small>{e(item['date'])} / {e(item['status'])}</small><p>{e(item['fact'])}</p><p class='muted'>{e(item['reading'])}</p></article>")
    md += ["",f'### [{item["title"]}]({item["url"]})',"",item["fact"],"",item["reading"],"",item["status"]]
parts.append("<div class='cards'>")
for event in n["next_events"]:
    parts.append(f"<article><small>{e(event['date'])}</small><h3><a href='{e(event['url'])}'>{e(event['name'])}</a></h3><p>{e(event['condition'])}</p></article>")
    md += ["",f'**{event["date"]} [{event["name"]}]({event["url"]})**：{event["condition"]}']
parts.append("</div><p class='muted'>BLS官方日历经网页工具核实，时间由美国东部标准时间换算；本地403，未归档全文。未到发布时间不预填结果。</p>")
altrows=[[names[c]]+[f'{p["weights"].get(c,0)*100:.0f}%' for p in x["plans"] if p["id"] not in ["old","six"]] for c in codes if c not in ["022714","519697","006075"]]
parts += ["<h2>如何调整，代价是什么</h2>",f"<p class='lead'>{e(n['recommendation'])}</p>",
          table(["基金"]+[plan_names[p["id"]] for p in x["plans"] if p["id"] not in ["old","six"]],altrows),
          "<p>更值得继续跟踪的精简研究版：产业18%、前海25%、广发30%、科益9%、交银环球12%、富国6%。它缩小了科技卫星和重复亚洲仓，但资源需求情景仍未改善，条件盈亏比也未呈现无条件优势。广发与交银的委托集中度上升；交银刚转单独管理，这一版本不能称已验证最优。</p>",
          f"<p>{e(n['monitoring'])}</p>",
          "<h2>资产穿透与证据</h2>"]
sr=[]
for id in ["proposal","old","six_controlled"]:
    s=x["structure"][id];sr.append([plan_names[id],plain(s["stock_and_equity_fund_proxy"]),plain(s["cash_and_settlement_net"]),plain(s["gold_fund_weight"])])
parts += [table(["方案","直接股票+权益基金代理","银行存款与结算备付金/净值","黄金基金权重"],sr),
          "<p class='muted'>来自9月30日资产负债表的近似。股票基金代理未穿透到底层每项资产；现金是基金内部资产，不是账户现金。净资产分母未扣各类应付款，资产项目相加可以超过100%，不能把这张表当无负债的完整资产饼图。</p>",
          f"<p class='muted'>{e(n['fair_comparison'])}</p><nav><a href='report.md'>Markdown</a><a href='analysis.json'>全部计算JSON</a><a href='dataset.zip'>CSV、原文页码与脚本</a><a href='manifest.json'>文件SHA-256</a></nav>"]
md += ["","## 研究方案权重",""]+mdtable(["基金"]+[plan_names[p["id"]] for p in x["plans"] if p["id"] not in ["old","six"]],altrows)
md += ["",n["recommendation"],"","六只控制卫星版本：产业18%、前海25%、广发30%、科益9%、交银环球12%、富国6%；不是已确认或已成交。",n["monitoring"],"",
       "## 三季报资产映射",""]+mdtable(["方案","权益近似","内部存款/净值","黄金基金"],sr)
md += ["","净资产分母未扣各类应付款，各类资产不能直接相加为100%；不是账户现金或实际当前仓位。",""]
css="""*{box-sizing:border-box}html{color-scheme:dark}body{margin:0;background:#0a0d0f;color:#e4eee8;font:15px/1.75 -apple-system,BlinkMacSystemFont,'PingFang SC',sans-serif}main{max-width:1250px;margin:auto;padding:50px 34px 90px}h1{font-size:48px;line-height:1.25;letter-spacing:-.03em;max-width:900px}h2{font-size:26px;margin-top:60px}h3{font-size:18px}.lead{font-size:18px;color:#cee5d8}.eyebrow,small,.muted{font-size:12px;color:#8faaa0}a{color:#9de1bd;text-underline-offset:4px}nav{display:flex;gap:20px;flex-wrap:wrap;margin:28px 0;font-size:13px}.kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:25px;margin:40px 0}.kpis strong{display:block;font-size:34px;color:#d9ecd9}.kpis p{font-size:12px;color:#8faaa0}.kpis>div{border-top:1px solid #527666;padding-top:15px}.cards{display:grid;grid-template-columns:1fr 1fr;gap:25px}.cards article{border-top:1px solid #304439}.scroll{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:13px}td,th{vertical-align:top;text-align:left;padding:13px 11px;border-bottom:1px solid #293a31;min-width:90px}th{font-weight:500;color:#90b79c}td:first-child{min-width:140px}.chart{height:480px}.evidence{border-top:1px solid #293a31;padding:13px 0}select{padding:8px 10px;border:1px solid #385344;background:#101e16;color:#dceadd;font:inherit;max-width:100%}details{margin:24px 0}summary{cursor:pointer;color:#b5c9b9}@media(max-width:760px){main{padding:26px 19px 60px}h1{font-size:34px}h2{font-size:23px}.lead{font-size:16px}.cards,.kpis{grid-template-columns:1fr;gap:12px}.kpis{margin:26px 0}.chart{height:470px}td,th{font-size:12px;padding:10px 8px}nav{gap:14px}}"""
payload=json.dumps(x,ensure_ascii=False,separators=(",",":")).replace("<","\\u003c")
js="""
const chartList=[],axis={nameTextStyle:{color:'#adc5b7'},axisLabel:{color:'#adc5b7'},axisLine:{lineStyle:{color:'#43594d'}},splitLine:{lineStyle:{color:'#21352a'}}};
const names=X.config.names,P=Object.fromEntries(X.plans.map(p=>[p.id,p.name])),palette=['#a5d7b1','#7398a8','#d8c78f','#9988ab','#b29675','#728983'];
function mount(id,opt){let c=echarts.init(document.getElementById(id));c.setOption(opt);chartList.push(c);return c}
const rc=mount('risk-chart',{}),pc=mount('path-chart',{}),sc=mount('scenario-chart',{});
function risk(){const codes=Object.keys(X.config.weights),r=document.getElementById('risk-window').value==='recent'?X.recent_risk.results.proposal:X.weekly.results.proposal.risk;rc.setOption({animation:false,tooltip:{trigger:'axis'},legend:{textStyle:{color:'#bacbbb'}},grid:{left:150,right:30,top:45,bottom:45},xAxis:{...axis,type:'value',name:'%',nameLocation:'middle',nameGap:28},yAxis:{...axis,type:'category',inverse:true,data:codes.map(c=>names[c])},series:[{name:'资金权重',type:'bar',itemStyle:{color:'#607d70'},data:codes.map(c=>+(X.config.weights[c]*100).toFixed(1))},{name:'方差贡献',type:'bar',itemStyle:{color:'#c9dba2'},data:codes.map(c=>+(r[c]*100).toFixed(1))}]},true)}
function paths(){const id=document.getElementById('path-plan').value;pc.setOption({animation:false,tooltip:{trigger:'axis'},legend:{textStyle:{color:'#bacbbb'}},grid:{left:50,right:25,top:50,bottom:45},xAxis:{...axis,type:'category',data:X.historical_paths.dates},yAxis:{...axis,type:'value',name:'累计 %'},series:['proposal',id].map((k,i)=>({name:P[k],type:'line',showSymbol:false,itemStyle:{color:palette[i]},data:X.historical_paths.plans[k].map(v=>+(v*100).toFixed(2))}))},true)}
function scenario(){const branch=X.model.branches.find(b=>b.id===document.getElementById('scenario-select').value),ids=X.plans.map(p=>p.id);sc.setOption({animation:false,tooltip:{trigger:'axis'},grid:{left:160,right:35,top:30,bottom:60},xAxis:{...axis,type:'value',name:'条件均值 %',nameLocation:'middle',nameGap:30},yAxis:{...axis,type:'category',inverse:true,data:ids.map(k=>P[k])},series:[{type:'bar',data:ids.map((k,i)=>({value:+(branch.responses[k].mean*100).toFixed(2),itemStyle:{color:palette[i]}}))}]},true);document.getElementById('scenario-detail').textContent='新8只：收益10/90分位 '+(branch.responses.proposal.q10*100).toFixed(2)+'% / '+(branch.responses.proposal.q90*100).toFixed(2)+'%；最弱10%路径平均 '+(branch.responses.proposal.es10*100).toFixed(2)+'%。';}
document.getElementById('risk-window').addEventListener('change',risk);document.getElementById('path-plan').addEventListener('change',paths);document.getElementById('scenario-select').addEventListener('change',scenario);risk();paths();scenario();
fetch('../../reports/index.json',{cache:'no-store'}).then(r=>r.json()).then(rows=>{let s=document.getElementById('date-picker');for(const r of rows){let o=document.createElement('option');o.value=r.path;o.textContent=r.date+(r.date===X.date?' · 当前方案':'');s.append(o)}s.value='reports/'+X.date+'/';s.addEventListener('change',()=>location.href='../../'+s.value);window.PROPOSAL_DATES_READY=true});
addEventListener('resize',()=>chartList.forEach(c=>c.resize()));window.PROPOSAL_READY=true;
"""
html=f'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>8只组合审视 · {DATE}</title><style>{css}</style><main>{"".join(parts)}</main><script>{(ROOT/"report/vendor/echarts.min.js").read_text()}</script><script>const X={payload};{js}</script></html>'
(TARGET/"index.html").write_text(html);(TARGET/"report.md").write_text("\n".join(md))
for src,dst in [(BASE/"analysis.json","analysis.json"),(BASE/"verification.json","verification.json"),(ROOT/f"research/proposal_notes_{DATE}.json","notes.json")]:shutil.copyfile(src,TARGET/dst)
with zipfile.ZipFile(TARGET/"dataset.zip","w",zipfile.ZIP_DEFLATED) as z:
    inputs=list((BASE/"nav").glob("*.csv"))+list((BASE/"primary").glob("*.text.json"))+list((BASE/"primary").glob("*manifest.json"))+list((BASE/"primary").glob("*.txt"))+list((BASE/"primary").glob("*.meta.json"))+list((BASE/"sources").glob("*.text.json"))+list((BASE/"secondary").glob("*.txt"))+list((BASE/"secondary").glob("*manifest.json"))
    inputs += [BASE/"analysis.json",BASE/"paths.npz",BASE/"verification.json",BASE/"nav/manifest.json",BASE/"sources/manifest.json",BASE/"primary/published-real-yield.json",ROOT/f"research/proposal_{DATE}.json",ROOT/f"research/proposal_notes_{DATE}.json",ROOT/"research/daily_config.json",ROOT/"data/quarter_review/2026-10-29/analysis.json",PUBLIC/f"reports/{DATE}/analysis.json",ROOT/"tools/analyze_proposal.py",ROOT/"tools/collect_proposal.py",ROOT/"tools/verify_proposal.py",ROOT/"tools/collect_history.py",ROOT/"tools/archive_deep_sources.py",Path(__file__)]
    inputs += [ROOT/"tools/check_proposal_site.py",ROOT/"report/vendor/echarts.min.js",ROOT/"report/vendor/ECHARTS-LICENSE.txt"]
    for p in inputs:z.write(p,str(p.relative_to(ROOT)))
manifest={"date":DATE,"type":"allocation_proposal_not_trades","status":"reviewed_not_accepted","files":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in TARGET.iterdir() if p.is_file() and p.name!="manifest.json"}}
(TARGET/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
registry_path=PUBLIC/"proposals/index.json"
registry=json.loads(registry_path.read_text()) if registry_path.exists() else []
entry={"date":DATE,"path":f"proposals/{DATE}/","title":"8只组合 · 最新净值与条件风险审视","status":"reviewed_not_accepted"}
registry=[r for r in registry if r["date"]!=DATE]+[entry];registry.sort(key=lambda r:r["date"],reverse=True)
registry_path.write_text(json.dumps(registry,ensure_ascii=False,indent=2))
(BASE/"report.md").write_text("\n".join(md))
print(json.dumps({"url":f"https://arnebear.github.io/fund-research/proposals/{DATE}/","files":list(manifest["files"])},ensure_ascii=False))
