"""Independent validation of budget closure, wealth paths, disclosures and conditional distributions."""
import hashlib,json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import linprog

ROOT=Path(__file__).resolve().parents[1];DATE="2026-11-02";BASE=ROOT/"data/proposal_review"/DATE
x=json.loads((BASE/"analysis.json").read_text());codes=x["codes"]
for path,h in x["inputs"].items():assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==h,path
secondary=json.loads((BASE/"secondary/manifest.json").read_text())
assert len(secondary)==8 and all(r["passed"] for r in secondary)
series={c:pd.read_csv(BASE/"nav"/f"{c}.csv",index_col="date",parse_dates=True).wealth for c in codes}
common=pd.DataFrame(series).dropna().loc["2026-04-16":]
assert x["historical_paths"]["dates"][0]==str(common.index[0].date())
for plan in x["plans"]:
    w=plan["weights"];assert np.isclose(sum(w.values()),1) and min(w.values())>=0
    for key,period in x["periods"].items():
        frame=common.loc[period["start"]:period["end"]]
        factors=[]
        for t in range(1,len(frame)):
            factors.append(sum(v*(frame[c].iloc[t]/frame[c].iloc[t-1]) for c,v in w.items()))
        value=np.r_[1,np.cumprod(factors)];result=period["plans"][plan["id"]]
        assert np.isclose(value[-1]-1,result["return"])
        assert np.isclose(np.min(value/np.maximum.accumulate(value)-1),result["mdd"])
        assert np.isclose(sum(v*(frame[c].iloc[-1]/frame[c].iloc[0]-1) for c,v in w.items()),result["buyhold_return"])
    risk=x["recent_risk"]["results"][plan["id"]]
    assert np.isclose(sum(risk.values()),1)
    chart=x["historical_paths"]["plans"][plan["id"]]
    assert len(chart)==len(x["historical_paths"]["dates"]) and chart[0]==0
    assert np.isclose(chart[-1],x["periods"]["common"]["plans"][plan["id"]]["return"])
paths=np.load(BASE/"paths.npz");bounds=[[.15,.55],[.1,.45],[.1,.4],[.05,.3]]
vertices=np.array(x["model"]["vertices"])
for r in x["model"]["robust"]:
    p=paths[r["id"]];assert p.shape==(4,2400) and np.isfinite(p).all()
    means=p.mean(1)
    lower=linprog(means,A_eq=[[1,1,1,1]],b_eq=[1],bounds=bounds,method="highs")
    upper=linprog(-means,A_eq=[[1,1,1,1]],b_eq=[1],bounds=bounds,method="highs")
    assert lower.success and upper.success and np.allclose([lower.fun,-upper.fun],r["mean_range"])
    ratio=(vertices@np.maximum(p,0).mean(1))/(vertices@np.maximum(-p,0).mean(1))
    assert np.allclose([ratio.min(),ratio.max()],r["gain_loss_ratio_range"])
    for i,b in enumerate(x["model"]["branches"]):
        d=b["responses"][r["id"]];quant=np.quantile(p[i],[.1,.5,.9])
        assert np.allclose(quant,[d["q10"],d["median"],d["q90"]])
        assert np.isclose(p[i][p[i]<=quant[0]].mean(),d["es10"])
# Company disclosures: compact whitespace only; figures must exist in source.
checks={"AN202610291831181859":["22,237,939,006.75","8,008,444,194.49"],
        "AN202610291831180453":["11,372,330,534.73","1,464,429,142.65","140.70%"],
        "AN202610281831116074":["2,083,459,571.46","1,461,851,321.62"],
        "AN202610291831147477":["蔡铮","陈舒薇","2026年10月29日"]}
for file,values in checks.items():
    text="".join("".join(p["text"].split()) for p in json.loads((BASE/"primary"/f"{file}.text.json").read_text()))
    for v in values:assert v in text,(file,v)
result={"date":DATE,"passed":True,"secondary_nav_points":len(secondary),"plans":len(x["plans"]),
        "checks":["金额与权重闭合","共同端点复合收益及不再平衡独立复算","风险贡献加总","线性规划独立核对盈亏区间","2400条配对路径/分支分位与尾部","新经理和公司财报关键数字原文匹配","输入SHA-256匹配"],
        "limits":"手工因子和分支不构成经过校准的市场概率，统计复算通过不等于模型预测得到验证。"}
(BASE/"verification.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
