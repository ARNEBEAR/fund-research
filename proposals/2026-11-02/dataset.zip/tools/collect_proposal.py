"""Fresh data for a proposed portfolio; never mutate the frozen daily report."""
import json, hashlib
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from urllib.request import Request, urlopen
from collect_history import collect_nav, collect_product
from archive_deep_sources import archive

ROOT=Path(__file__).resolve().parents[1]
DATE=datetime.now(ZoneInfo("Asia/Shanghai")).date().isoformat()
BASE=ROOT/"data/proposal_review"/DATE
config=json.loads((ROOT/f"research/proposal_{DATE}.json").read_text())
baseline=json.loads((ROOT/f"publish/github-pages/reports/{DATE}/analysis.json").read_text())
factors=json.loads((ROOT/"research/daily_config.json").read_text())["forward_factor_model"]["factor_codes"]+["513100","513180"]
codes=list(dict.fromkeys(list(config["weights"])+[p["code"] for p in baseline["policy"]["positions"]]+factors))
raw=BASE/"nav/raw";raw.mkdir(parents=True,exist_ok=True)
rows=[]
for code in codes:
    frame,row=collect_nav(code,"2021-01-01",DATE,raw,code in set(factors)-{"002611","006075"})
    product=collect_product(code,raw,frame)
    assert not product["same_vendor_mismatches"] and product["history_row_count_matches_api"],code
    row.update(product=product,sha256=hashlib.sha256((raw.parent/f"{code}.csv").read_bytes()).hexdigest())
    rows.append(row)
    (BASE/"nav/manifest.json").write_text(json.dumps(rows,ensure_ascii=False,indent=2))
    print(code,product["name"],row["last_date"],flush=True)
folder=BASE/"sources";folder.mkdir(exist_ok=True)
items=[]
for code in config["weights"]:
    url=f"https://api.fund.eastmoney.com/f10/JJGG?fundcode={code}&pageIndex=1&pageSize=20&type=0"
    with urlopen(Request(url,headers={"User-Agent":"Mozilla/5.0","Referer":"https://fund.eastmoney.com/"}),timeout=30) as r:raw=r.read()
    (folder/f"index-{code}.json").write_bytes(raw)
    for rec in json.loads(raw)["Data"]:
        if rec["FUNDCODE"]!=code or not "2026-10-27"<=rec["PUBLISHDATE"][:10]<=DATE:continue
        if "基金经理" not in rec["TITLE"] and "业绩比较基准" not in rec["TITLE"]:continue
        item={"id":rec["ID"],"code":code,"title":rec["TITLE"],"date":rec["PUBLISHDATE"][:10],"url":f'https://pdf.dfcfw.com/pdf/H2_{rec["ID"]}_1.pdf'}
        items.append(archive(item,folder,True))
        print(item["title"],flush=True)
(BASE/"sources/manifest.json").write_text(json.dumps(items,ensure_ascii=False,indent=2))
