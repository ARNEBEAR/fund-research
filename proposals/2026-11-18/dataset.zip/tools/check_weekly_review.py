"""Check responsive interaction, offline assets and immutable dated reports."""
import argparse,hashlib,json,tempfile,threading,zipfile
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1];PUBLIC=ROOT/"publish/github-pages"
parser=argparse.ArgumentParser();parser.add_argument("--url");parser.add_argument("--date",default="2026-11-16");args=parser.parse_args()
DATE=args.date;OUT=PUBLIC/"proposals"/DATE
screens=Path(tempfile.mkdtemp(prefix=f"fund-review-{DATE}-"))
manifest=json.loads((OUT/"manifest.json").read_text())
for row in json.loads((PUBLIC/"reports/index.json").read_text()):
    base=PUBLIC/row["path"]
    for name,digest in json.loads((base/"manifest.json").read_text())["files"].items():
        assert hashlib.sha256((base/name).read_bytes()).hexdigest()==digest
for date in [r["date"] for r in json.loads((PUBLIC/"proposals/index.json").read_text()) if r["date"]<DATE]:
    base=PUBLIC/"proposals"/date
    for name,digest in json.loads((base/"manifest.json").read_text())["files"].items():
        assert hashlib.sha256((base/name).read_bytes()).hexdigest()==digest
server=None
if args.url:url=args.url.rstrip("/")+"/"
else:
    class Quiet(SimpleHTTPRequestHandler):
        def log_message(self,*args):pass
    server=ThreadingHTTPServer(("127.0.0.1",0),partial(Quiet,directory=str(PUBLIC)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    url=f"http://127.0.0.1:{server.server_address[1]}/"
errors=[]
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True)
    for width in [1440,390]:
        page=browser.new_page(viewport={"width":width,"height":950 if width==1440 else 844})
        page.on("pageerror",lambda error:errors.append(str(error)))
        page.on("console",lambda m:errors.append(m.text) if m.type=="error" else None)
        page.goto(url+"archive.html",wait_until="networkidle")
        page.wait_for_function("window.PROPOSAL_ARCHIVE_READY")
        page.locator(f'#proposals a[href="proposals/{DATE}/"]').click()
        page.wait_for_function("window.WEEKLY_REVIEW_READY")
        assert page.locator(".chart svg").count()==3
        assert "盘中" in page.locator("main").inner_text()
        page.screenshot(path=str(screens/f"overview-{width}.png"))
        for value in ["0","1","2"]:
            page.select_option("#execution",value)
            assert page.locator(".action:visible").count()==1
            assert page.locator(f'.action[data-state="{value}"]').is_visible()
        page.select_option("#execution","all")
        for selector,value,chart in [("#window","return20","#fund-chart"),("#audit","1","#audit-chart"),("#inventory","keyi_confirmed","#scenario-chart")]:
            before=page.locator(chart).evaluate("(el)=>JSON.stringify(echarts.getInstanceByDom(el).getOption().series)")
            page.select_option(selector,value)
            after=page.locator(chart).evaluate("(el)=>JSON.stringify(echarts.getInstanceByDom(el).getOption().series)")
            assert before!=after
        page.select_option("#window","since_last_review")
        page.select_option("#audit","0")
        page.select_option("#inventory","reported")
        for chart in ["fund-chart","audit-chart","scenario-chart"]:
            page.locator("#"+chart).scroll_into_view_if_needed()
            page.screenshot(path=str(screens/f"{chart}-{width}.png"))
        page.locator("details > summary").click()
        assert page.evaluate("document.documentElement.scrollWidth<=innerWidth+1")
        assert page.evaluate("Array.from(document.querySelectorAll('sup a')).every(a=>document.querySelector(a.getAttribute('href')))")
        with page.expect_download() as dl:page.locator('a[href="dataset.zip"]').first.click()
        archive=screens/f"dataset-{width}.zip";dl.value.save_as(str(archive))
        with zipfile.ZipFile(archive) as z:assert z.testzip() is None and "tools/verify_weekly_review.py" in z.namelist()
        for name,digest in manifest["files"].items():
            response=page.request.get(url+f"proposals/{DATE}/"+name)
            assert response.ok and hashlib.sha256(response.body()).hexdigest()==digest,name
        page.goto(url,wait_until="networkidle")
        latest=json.loads((PUBLIC/"reports/index.json").read_text())[0]["date"]
        assert f"/reports/{latest}/" in page.url
        page.close()
    # The local deliverable must open without HTTP or an internet connection.
    if not args.url:
        page=browser.new_page()
        page.on("pageerror",lambda error:errors.append(str(error)))
        page.goto((OUT/"index.html").as_uri())
        page.wait_for_function("window.WEEKLY_REVIEW_READY")
        assert page.locator(".chart svg").count()==3
        page.close()
    browser.close()
if server:server.shutdown()
assert not errors,errors
result={"passed":True,"site":args.url or "local","screenshots":str(screens),"viewports":[1440,390],
        "checks":["执行状态与三个图表选择器","本地离线打开","下载包与逐文件哈希","引用锚点","旧日期不可变","默认最新日报"],
        "manifest_sha256":hashlib.sha256((OUT/"manifest.json").read_bytes()).hexdigest()}
(screens/"verification.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
