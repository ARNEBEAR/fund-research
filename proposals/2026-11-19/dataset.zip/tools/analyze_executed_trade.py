"""Assess a reported trade using information available before submission and unit amounts."""
import hashlib,json,re
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1];DATE="2026-11-19"
BASE=ROOT/"data/transition_review"/DATE
names={"002244":"低碳科技","002051":"诺安创新驱动C","021902":"广发主题C","011370":"华商均衡C",
       "022714":"万家新兴蓝筹C","010390":"科益C","022415":"前海国企C"}
codes=list(names);sources=["002244","002051"];recipient="021902"
factors=["510300","515880","510880","006075","002611","512480","512400","515220","159992","512010","513100","513180"]
frames={c:pd.read_csv(BASE/"nav"/f"{c}.csv",index_col="date",parse_dates=True) for c in set(codes+factors)}
Q=json.loads((ROOT/"data/quarter_review/2026-10-29/analysis.json").read_text())["funds"]
returns=pd.DataFrame({c:frames[c]["return"] for c in codes}).dropna()
pre=returns.loc[:"2026-11-16"];latest=returns
stats={}
for label,r in [("pre_submission",pre),("latest",latest)]:
    result={}
    for c in codes:
        s=frames[c].wealth.loc[:r.index[-1]]
        tail=r.tail(20)[c]
        result[c]={"end":str(r.index[-1].date()),"return20":float(s.iloc[-1]/s.iloc[-21]-1),
                   "return60":float(s.iloc[-1]/s.iloc[-61]-1),"vol20":float(tail.std()*np.sqrt(252)),
                   "vol60":float(r.tail(60)[c].std()*np.sqrt(252)),
                   "mdd60":float((s.tail(61)/s.tail(61).cummax()-1).min())}
    stats[label]=result
pairs=[("002244","011370"),("002244","022714"),("002051","011370"),("002051","002244"),("002051","010390"),
       ("002051","021902"),("002244","021902"),("021902","022415")]
corr={label:[{"a":a,"b":b,"r20":float(r.tail(20)[a].corr(r.tail(20)[b])),
             "r60":float(r.tail(60)[a].corr(r.tail(60)[b]))} for a,b in pairs]
      for label,r in [("pre_submission",pre),("latest",latest)]}

# Compare alternative receipts on actual source/recipient valuation dates; never assume cross-company same-day execution.
trade_date=pd.Timestamp("2026-11-17")
end=min(frames[c].index[-1] for c in sources+[recipient])
transfers=[]
for c in sources:
    rsource=float(frames[c].loc[end,"wealth"]/frames[c].loc[trade_date,"wealth"]-1)
    for entry in ["2026-11-17","2026-11-18","pending"]:
        for fee in ([0,.0025,.005,.0075,.015] if c=="002244" else [0,.005,.015]):
            rgf=0.0 if entry=="pending" else float(frames[recipient].loc[end,"wealth"]/frames[recipient].loc[entry,"wealth"]-1)
            after=(1-fee)*(1+rgf)-1
            transfers.append({"code":c,"source_nav_date":"2026-11-17","entry_date":entry,
                "end":str(end.date()),"intervals":len(frames[c].loc[trade_date:end])-1,
                "source_return":rsource,"recipient_return":None if entry=="pending" else rgf,"redemption_fee":fee,
                "after_return":after,"difference":after-rsource,"per_100k_difference":100000*(after-rsource)})
equities={c:Q[c]["3"]["stock_pct_net"]/100 for c in codes}
alloc={"equity_Q3":equities,"per_100k_equity_reduction":{c:100000*(equities[c]-equities[recipient]) for c in sources},
       "formula":"G_after ≈ G_before + 0.5×L_before + N_before − redemption_fees；全组合分母按实际市值和费用调整。",
       "nuoan_top10":[p["name"] for p in Q["002051"]["3"]["top10"]]}
grid=pd.date_range("2026-04-17",DATE,freq="W-FRI")
weekly={}
for c in codes:
    s=frames[c].wealth
    weekly[c]=[s.iloc[j] if (j:=s.index.searchsorted(t,side="right")-1)>=0 and (t-s.index[j]).days<=7 else np.nan for t in grid]
wr=pd.DataFrame(weekly,index=grid).pct_change(fill_method=None).tail(26)
assert wr.notna().all().all()
c26=[{"a":a,"b":b,"r26w":float(wr[a].corr(wr[b]))} for a,b in pairs]
covariances={"codes":sources+[recipient],
    "20":latest.tail(20)[sources+[recipient]].cov().to_numpy().tolist(),
    "60":latest.tail(60)[sources+[recipient]].cov().to_numpy().tolist(),
    "26w":wr[sources+[recipient]].cov().to_numpy().tolist()}

# Source-of-funds mix is unknown, so show one transferred unit per origin rather than fabricate total portfolio odds.
log=pd.DataFrame({c:np.log1p(frames[c]["return"]) for c in set(factors+sources+[recipient])}).dropna()
selectors={"002244":[0,1,5,9],"002051":[0,1,5],"021902":[0,2,7]}
branches=json.loads((ROOT/"data/proposal_review/2026-11-02/analysis.json").read_text())["model"]["branches"]
fits=[]
for label,cutoff in [("pre_submission","2026-11-16"),("latest",DATE)]:
    window=log.loc[:cutoff]
    for size,ridge in [(40,5),(60,0),(60,5),(60,10),(100,5)]:
        sample=window.tail(size);B={}
        for c,ix in selectors.items():
            X=sample[[factors[i] for i in ix]].to_numpy(); y=sample[c].to_numpy()
            mean=X.mean(0);sd=X.std(0);z=(X-mean)/sd
            coef=np.linalg.solve(z.T@z+ridge*np.eye(len(ix)),z.T@(y-y.mean()))/sd
            beta=np.zeros(len(factors));beta[ix]=coef;B[c]=beta
        fits.append({"label":label,"n":len(sample),"ridge":ridge,"start":str(sample.index[0].date()),
                    "end":str(sample.index[-1].date()),"beta":{c:v.tolist() for c,v in B.items()}})
scenario=[]
for b in branches:
    rows={}
    for c in sources+[recipient]:
        values=[float(np.expm1(np.array(fit["beta"][c])@np.log1p(b["shock"]))) for fit in fits if fit["label"]=="latest"]
        prefit=next(v for v in fits if v["label"]=="pre_submission" and v["n"]==60 and v["ridge"]==5)
        rows[c]={"base":values[2],"min":min(values),"max":max(values),
                 "pre_submission":float(np.expm1(np.array(prefit["beta"][c])@np.log1p(b["shock"])))}
    scenario.append({"id":b["id"],"name":b["name"],"shock":b["shock"],"funds":rows,
                     "per_100k_change":{c:100000*(rows[recipient]["base"]-rows[c]["base"]) for c in sources}})

paths={"dates":[str(t.date()) for t in frames[recipient].loc["2026-09-30":].index],"funds":{}}
for c in sources+[recipient]:
    s=frames[c].wealth.loc["2026-09-30":]
    paths["funds"][c]=(s/s.iloc[0]-1).tolist()
inputs=[BASE/"nav"/f"{c}.csv" for c in set(codes+factors)]
inputs += [ROOT/"data/trade_feedback_2026-11-19.json",ROOT/"data/quarter_review/2026-10-29/analysis.json",
           ROOT/"data/proposal_review/2026-11-02/analysis.json",Path(__file__)]
result={"date":DATE,"trade_date":"2026-11-17","pre_submission_cutoff":"2026-11-16","names":names,"stats":stats,
    "correlations":corr,"correlations26w":c26,"transfers":transfers,"allocation":alloc,"fit":fits,"scenarios":scenario,
    "covariances":covariances,"paths":paths,"valuation_end":str(end.date()),"factor_codes":factors,
    "limits":["未取得订单及完整当前金额，不报告实际账户盈亏或全组合波动改善幅度。",
              "决策质量使用11月16日及以前数据；11月17日收盘净值只作交易价格假设，18日表现只用于事后跟踪。",
              "跨公司转入日期分别17日、18日、在途比较；不能把17日下跌算成已避开，也不能从提交日推定转入日。",
              "三季末仓位是9月30日快照，非当前实时持仓；基金内部现金不等于用户账户现金。",
              "模型为最近40/60/100共同日岭回归、不外推截距，人工冲击不对应校准概率，区间非置信区间。",
              "诺安半导体/PCB/存储不能被三因子完整解释；未用当前权重优化换出次序，清诺安并非已证明最优。"],
    "inputs":{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}}
(BASE/"trade-analysis.json").write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
print(json.dumps({"stats":stats,"correlations":corr,"transfers":[r for r in transfers if r["redemption_fee"]==(.005 if r["code"]=="002244" else 0)],"scenarios":scenario},ensure_ascii=False,indent=2))
