"""Independent unit ledger, source matching and evidence checks for the reported trade."""
import hashlib,json,re
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];BASE=ROOT/"data/transition_review/2026-11-19"
x=json.loads((BASE/"trade-analysis.json").read_text())
for name,digest in x["inputs"].items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,name
frames={c:pd.read_csv(BASE/"nav"/f"{c}.csv",index_col="date",parse_dates=True) for c in x["names"]}
for c,f in frames.items():
    text=(BASE/"sources"/f"sina_{c}.txt").read_text()
    match=re.search(r"数据日期[：:]\s*(\d{4}-\d{1,2}-\d{1,2})",text)
    nav=re.search(r"单位净值[：:\s]+(\d+\.\d+)",text)
    assert match and nav,c
    assert abs(float(nav[1])-f.loc[match[1],"unit_nav"])<.00011,c
    for key,cut in [("pre_submission","2026-11-16"),("latest",x["valuation_end"])]:
        s=f.wealth.loc[:cut]
        assert np.isclose(s.iloc[-1]/s.iloc[-21]-1,x["stats"][key][c]["return20"])
        assert x["stats"]["pre_submission"][c]["end"]=="2026-11-16"
for row in x["transfers"]:
    source=frames[row["code"]].loc[row["source_nav_date"],"wealth"]
    unchanged=100000/source*frames[row["code"]].loc[row["end"],"wealth"]
    proceeds=100000*(1-row["redemption_fee"])
    if row["entry_date"]=="pending":value=proceeds
    else:
        units=proceeds/frames["021902"].loc[row["entry_date"],"wealth"]
        value=units*frames["021902"].loc[row["end"],"wealth"]
    assert np.isclose(value-unchanged,row["per_100k_difference"])
    assert row["intervals"]==1
for b in x["scenarios"]:
    for c,values in b["funds"].items():
        fit=next(f for f in x["fit"] if f["label"]=="latest" and f["n"]==60 and f["ridge"]==5)
        gross=np.prod([(1+shock)**beta for shock,beta in zip(b["shock"],fit["beta"][c])])
        assert np.isclose(gross-1,values["base"])
for fit in x["fit"]:
    if fit["label"]=="pre_submission":assert fit["end"]<"2026-11-17"
Q=json.loads((ROOT/"data/quarter_review/2026-10-29/analysis.json").read_text())["funds"]
for c in ["002244","002051","021902"]:
    p=ROOT/Q[c]["3"]["file"]
    assert hashlib.sha256(p.read_bytes()).hexdigest()==Q[c]["3"]["sha256"]
fees={c:"".join((BASE/"sources"/f"fee_{c}.txt").read_text().split()) for c in ["002051","002244","021902"]}
assert "大于等于30天0.00%" in fees["002051"]
assert "大于等于30天，小于365天0.50%" in fees["002244"]
assert "大于等于30天，小于180天0.30%" in fees["021902"]
fed=(BASE/"sources/fed_minutes.txt").read_text()
assert "October 27" in fed and "circular financing" in fed and "AI-related" in fed
result={"passed":True,"date":"2026-11-19","nav_points":len(frames),
        "checks":["截止提交前一日的数据边界","7只同日净值跨平台核对","每10万元份额法复算","转入时差与费用","原始三季报哈希","人工情景独立复算","赎回费率原文","会议日期与纪要正文"],
        "limits":"用户已报执行，但订单及金额未知；所有单位金额演示不是实际盈亏，单日不能验证择时。"}
(BASE/"trade-verification.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
