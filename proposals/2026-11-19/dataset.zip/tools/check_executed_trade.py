"""Exercise fee, receipt-date and allocation controls and verify all published artifacts."""
import argparse,hashlib,json,tempfile,threading,zipfile
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1];PUBLIC=ROOT/"publish/github-pages";DATE="2026-11-19";OUT=PUBLIC/"proposals"/DATE
parser=argparse.ArgumentParser();parser.add_argument("--url");args=parser.parse_args()
screens=Path(tempfile.mkdtemp(prefix="trade-review-2026-11-19-"))
manifest=json.loads((OUT/"manifest.json").read_text())
for listing in ["reports","proposals"]:
    for row in json.loads((PUBLIC/listing/"index.json").read_text()):
        if row["date"]>=DATE:continue
        base=PUBLIC/row["path"]
        for name,digest in json.loads((base/"manifest.json").read_text())["files"].items():
            assert hashlib.sha256((base/name).read_bytes()).hexdigest()==digest,(row["date"],name)
server=None
if args.url:url=args.url.rstrip("/")+"/"
else:
    class Quiet(SimpleHTTPRequestHandler):
        def log_message(self,*args):pass
    server=ThreadingHTTPServer(("127.0.0.1",0),partial(Quiet,directory=str(PUBLIC)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    url=f"http://127.0.0.1:{server.server_address[1]}/"
errors=[]
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True)
    for width in [1440,390]:
        page=browser.new_page(viewport={"width":width,"height":950 if width==1440 else 844})
        page.on("pageerror",lambda e:errors.append(str(e)))
        page.on("console",lambda m:errors.append(m.text) if m.type=="error" else None)
        page.goto(url+"archive.html",wait_until="networkidle")
        page.wait_for_function("window.PROPOSAL_ARCHIVE_READY")
        page.locator(f'#proposals a[href="proposals/{DATE}/"]').click()
        page.wait_for_function("window.EXECUTED_TRADE_READY")
        assert page.locator(".chart svg").count()==3
        page.screenshot(path=str(screens/f"overview-{width}.png"))
        for selector,value,chart in [("#entry","2026-11-18","#outcome-chart"),("#low-fee","0.0025","#outcome-chart"),("#nuo-fee","0.005","#outcome-chart"),("#origin","002051","#scenario-chart")]:
            before=page.locator(chart).evaluate("(el)=>JSON.stringify(echarts.getInstanceByDom(el).getOption().series)")
            page.select_option(selector,value)
            after=page.locator(chart).evaluate("(el)=>JSON.stringify(echarts.getInstanceByDom(el).getOption().series)")
            assert before!=after
        page.select_option("#entry","2026-11-17");page.select_option("#low-fee","0.005");page.select_option("#nuo-fee","0");page.select_option("#origin","002244")
        for name,value in [("low","20"),("nuo","10"),("gf","5"),("total","100")]:page.fill("#"+name,value)
        assert "24.95万元" in page.locator("#allocation-result").inner_text()
        assert "24.96%" in page.locator("#allocation-result").inner_text()
        page.fill("#gf","10")
        assert "超过25%" in page.locator("#allocation-result").inner_text()
        page.fill("#total","1");assert "请检查" in page.locator("#allocation-result").inner_text()
        for name in ["low","nuo","gf","total"]:page.fill("#"+name,"")
        for chart in ["path-chart","outcome-chart","scenario-chart"]:
            page.locator("#"+chart).scroll_into_view_if_needed()
            page.screenshot(path=str(screens/f"{chart}-{width}.png"))
        page.locator("details summary").click()
        assert page.evaluate("document.documentElement.scrollWidth<=innerWidth+1")
        with page.expect_download() as dl:page.locator('a[href="dataset.zip"]').first.click()
        package=screens/f"dataset-{width}.zip";dl.value.save_as(str(package))
        with zipfile.ZipFile(package) as z:assert z.testzip() is None and "tools/verify_executed_trade.py" in z.namelist()
        for name,digest in manifest["files"].items():
            r=page.request.get(url+f"proposals/{DATE}/"+name)
            assert r.ok and hashlib.sha256(r.body()).hexdigest()==digest,name
        page.goto(url,wait_until="networkidle")
        latest=json.loads((PUBLIC/"reports/index.json").read_text())[0]["date"]
        assert f"/reports/{latest}/" in page.url
        page.close()
    if not args.url:
        page=browser.new_page();page.goto((OUT/"index.html").as_uri());page.wait_for_function("window.EXECUTED_TRADE_READY")
        assert page.locator(".chart svg").count()==3
        page.close()
    browser.close()
if server:server.shutdown()
assert not errors,errors
result={"passed":True,"site":args.url or "local","screenshots":str(screens),"viewports":[1440,390],
        "checks":["三图与日期费率切换","集中度计算及输入校验","文件哈希与下载包","旧报告完整","默认最新日报","本地离线打开"],
        "manifest_sha256":hashlib.sha256((OUT/"manifest.json").read_bytes()).hexdigest()}
(screens/"verification.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False))
