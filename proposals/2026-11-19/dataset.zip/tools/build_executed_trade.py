"""Publish a trade-specific review without inventing unreported amounts."""
import hashlib,json,shutil,zipfile
from html import escape as e
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];DATE="2026-11-19";BASE=ROOT/"data/transition_review"/DATE
PUBLIC=ROOT/"publish/github-pages";OUT=PUBLIC/"proposals"/DATE
x=json.loads((BASE/"trade-analysis.json").read_text());n=json.loads((ROOT/f"research/executed_trade_notes_{DATE}.json").read_text())
assert json.loads((BASE/"trade-verification.json").read_text())["passed"]
for folder in ["assets","_shared/js","_shared/fonts"]:(OUT/folder).mkdir(parents=True,exist_ok=True)
for name in ["echarts.min.js","ECHARTS-LICENSE.txt"]:shutil.copyfile(ROOT/"report/vendor"/name,OUT/"_shared/js"/name)
for name in ["InstrumentSans-Regular.ttf","InstrumentSans-Bold.ttf","InstrumentSans-OFL.txt"]:
    shutil.copyfile(PUBLIC/"proposals/2026-11-18/_shared/fonts"/name,OUT/"_shared/fonts"/name)
def pct(v):return f"{v*100:+.2f}%"
def table(headers,rows):
    return '<div class="scroll"><table><thead><tr>'+''.join(f'<th>{e(str(v))}</th>' for v in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join(f'<td>{e(str(v))}</td>' for v in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def mt(headers,rows):return ['| '+' | '.join(headers)+' |','|'+'|'.join(['---']*len(headers))+'|']+['| '+' | '.join(str(v) for v in row)+' |' for row in rows]
def fig(id,title):return f'<figure><figcaption>{e(title)}</figcaption><div id="{id}" class="chart"></div></figure>'
header=f'<div class="eyebrow">已报操作复核 · {DATE}</div><h1>{e(n["headline"])}</h1><p class="lead">{e(n["verdict"])}</p><p class="muted">{e(n["status"])}</p><p class="muted">决策证据截止11月16日；交易假设净值日11月17日；正式净值与结果截止{x["valuation_end"]}。没有把11月18日新公布财报当作下单时已知信息。</p>'
parts=[header,'<nav><a href="../../">每日研究</a><a href="../../archive.html">日期档案</a><a href="../2026-11-18/">前次建议</a><a href="report.md" download>下载正文</a><a href="dataset.zip" download>完整数据与证据</a></nav>',
       '<h2>逐笔判断</h2>',table(["操作","判断","依据与代价"],[[r["action"],r["rating"],r["reason"]] for r in n["judgments"]])]
md=[f"# 11月17日两笔调仓复核 · {DATE}","",n["headline"],"",n["verdict"],"",n["status"],"","## 操作判断",""]+mt(["操作","判断","依据"],[[r["action"],r["rating"],r["reason"]] for r in n["judgments"]])
pre_rows=[[x["names"][c],f'{x["allocation"]["equity_Q3"][c]*100:.2f}%',pct(x["stats"]["pre_submission"][c]["return20"]),
           f'{x["stats"]["pre_submission"][c]["vol20"]*100:.1f}%',pct(x["stats"]["pre_submission"][c]["mdd60"])] for c in ["002244","002051","021902","011370"]]
parts+=['<h2>操作前已经存在的依据</h2>',table(["基金","三季末股票仓位","此前20日收益","20日波动年化","60日最大回撤"],pre_rows),
 '<p class="muted">截至11月16日，年化波动是短窗口日收益标准差折算，不是下一年预测。股票仓位为9月30日快照，不是实时仓位。</p>']
pairs=x["correlations"]["pre_submission"]
corr_rows=[[x["names"][r["a"]]+" / "+x["names"][r["b"]],f'{r["r20"]:.2f}',f'{r["r60"]:.2f}',
            f'{next(p["r26w"] for p in x["correlations26w"] if (p["a"],p["b"])==(r["a"],r["b"])):.2f}'] for r in pairs]
parts += [table(["基金对","操作前20日","操作前60日","最近26完整周"],corr_rows),
          '<p>诺安与低碳高度同步，为精简提供了行为证据；与广发的负相关支持缓冲作用。相关性会变，不是永久对冲。</p>',fig("path-chart","9月30日起净值路径：展示历史差异，不代表你的收益"),
          f'<p class="notice">{e(n["nuance"])}</p>']
md+=["","## 操作前证据",""]+mt(["基金","股票仓位","20日收益","20日波动年化","60日回撤"],pre_rows)+[""]+mt(["基金对","前20日","前60日","26周"],corr_rows)+["",n["nuance"],""]
parts+=['<h2>执行后一天：少赚多少，先分清净值日</h2>',f'<p>{e(n["trade_result_note"])}</p>',
 '<div class="controls"><label>广发转入净值日 <select id="entry"><option value="2026-11-17">11月17日</option><option value="2026-11-18">11月18日</option><option value="pending">仍在途</option></select></label><label>低碳赎回费 <select id="low-fee"><option value="0.005">0.5% · 30—364天</option><option value="0.0025">0.25% · 365—729天</option><option value="0">0% · 满730天</option><option value="0.0075">0.75% · 7—29天</option><option value="0.015">1.5% · 不足7天</option></select></label><label>诺安赎回费 <select id="nuo-fee"><option value="0">0% · 满30天</option><option value="0.005">0.5% · 7—29天</option><option value="0.015">1.5% · 不足7天</option></select></label></div>',
 fig("outcome-chart","每10万元转出额：相对继续持有的金额差"),'<p id="outcome-detail" class="muted"></p>']
outcomes=[[x["names"][r["code"]],r["entry_date"],pct(r["source_return"]),pct(r["after_return"]),f'{r["per_100k_difference"]:+,.0f}元'] for r in x["transfers"] if r["redemption_fee"]==(.005 if r["code"]=="002244" else 0)]
parts += [table(["转出基金","转入日期假设","原基金收益","转出净回款收益","每10万相对差额"],outcomes),
 '<p class="muted">相对少赚不是额外从账户扣掉同等金额。“在途”按转出已按17日净值生效、截至18日未取得新基金收益测算；确认日与净值归属日不同。实际金额须乘以实际转出额/10万元，不能用9月旧31万或未确认的诺安15万元。</p>']
md+=["## 执行后跟踪","",n["trade_result_note"],""]+mt(["基金","转入日","持有收益","回款收益","每10万差额"],outcomes)+[""]
parts += ['<h2>转入后广发是否过重</h2>',f'<p>{e(n["concentration"])}</p>',
 '<p class="muted">填入同一估值时点的操作前金额（万元），只在本页计算，不保存。需剔除其他现金流和同期价格变化；这不是读取账户。</p><div class="calculator">'
 '<label>原低碳市值 <input id="low" type="number" min="0" step=".01"></label><label>原诺安市值 <input id="nuo" type="number" min="0" step=".01"></label>'
 '<label>原广发市值 <input id="gf" type="number" min="0" step=".01"></label><label>组合总市值 <input id="total" type="number" min=".01" step=".01"></label></div>'
 '<p id="allocation-result" role="status">金额未填，暂不判断广发是否超过复核线。</p>',
 '<p>按三季报快照，每10万元由低碳转入广发，减少约4.76万元股票敞口；由诺安转入，减少约2.26万元。剩余股票仍有风险，内部现金也会随经理调仓而变化。</p>']
md+=["## 承接集中度","",n["concentration"],"","按三季末仓位：每10万低碳转入约减少4.76万股票敞口，诺安约减少2.26万；快照不能当实时。",""]
parts+=['<h2>未来条件：降低压力，也放弃反弹</h2>',
 '<p>对每10万元转出资金做同冲击比较，不制造未知总组合的胜率或盈亏比。下面为最近60共同日岭回归响应；不含费用、路径噪声和个人交易时差，不是收益预测。</p>',
 '<label>观察来源 <select id="origin"><option value="002244">低碳科技</option><option value="002051">诺安创新驱动C</option></select></label>',fig("scenario-chart","人工20日冲击：转出前基金与广发主题"),
 '<details><summary>窗口敏感性、模型限制与数据</summary>']
scenario_rows=[[b["name"],pct(b["funds"]["002244"]["base"]),pct(b["funds"]["002051"]["base"]),pct(b["funds"]["021902"]["base"])] for b in x["scenarios"]]
parts+=[table(["人工分支","低碳响应","诺安响应","广发响应"],scenario_rows)]
sens_rows=[[b["name"],x["names"][c],pct(b["funds"][c]["min"])+" ～ "+pct(b["funds"][c]["max"])] for b in x["scenarios"] for c in ["002244","002051","021902"]]
parts+=[table(["分支","基金","40/60/100日及正则强度范围"],sens_rows)]+[f'<p class="muted">{e(t)}</p>' for t in x["limits"]]+['</details>']
md+=["## 同冲击研究",""]+mt(["分支","低碳","诺安","广发"],scenario_rows)+[""]+x["limits"]+[""]
parts+=['<h2>现在如何处理</h2>',f'<p class="lead">{e(n["next"])}</p>']
for r in n["news"]:
    parts.append(f'<article><h3>{e(r["title"])}</h3><p>{e(r["body"])}</p></article>')
    md+=["### "+r["title"],"",r["body"],""]
parts += [f'<p>{e(n["fees"])}</p><p class="muted">{e(n["running_cost"])}</p><p class="notice">{e(n["request"])}</p>',
 '<nav><a href="trade-analysis.json">计算结果</a><a href="trade-verification.json">独立复算</a><a href="feedback.json">本次操作记录</a><a href="dataset.zip" download>原文与数据包</a><a href="manifest.json">文件哈希</a></nav>',
 '<footer><h2>来源</h2><ol>']
md+=["## 下一步","",n["next"],"",n["fees"],"",n["running_cost"],"",n["request"],"","## 来源",""]
for r in n["sources"]:
    parts.append(f'<li><a href="{e(r["url"])}" target="_blank" rel="noopener">{e(r["name"])}</a><p class="muted">{e(r["status"])}</p></li>')
    md.append(f'- [{r["name"]}]({r["url"]})：{r["status"]}')
parts.append('</ol></footer>')
css="""@font-face{font-family:Report;src:url('./_shared/fonts/InstrumentSans-Regular.ttf')}@font-face{font-family:Report;src:url('./_shared/fonts/InstrumentSans-Bold.ttf');font-weight:700}:root{--bg:#0a0d0f;--fg:#e5eee7;--muted:#a6b9ac;--green:#aed7ae;--blue:#a0bfd2;--red:#d0a3b5;--rule:#334e3c}*{box-sizing:border-box}html{color-scheme:dark}body{margin:0;background:var(--bg);color:var(--fg);font:16px/1.8 Report,-apple-system,'PingFang SC',sans-serif}main{max-width:1180px;margin:auto;padding:42px 32px 80px}h1{font-size:46px;line-height:1.32;letter-spacing:-.035em}h2{font-size:25px;margin-top:48px}h3{font-size:19px}.lead{font-size:19px}.muted,.eyebrow{font-size:13px;color:var(--muted)}a{color:var(--green);text-underline-offset:4px}nav,.controls{display:flex;gap:18px;flex-wrap:wrap;margin:24px 0}nav{font-size:14px}.notice,article{border-block:1px solid var(--rule);padding:18px 0}.scroll{overflow:auto;max-height:540px}table{border-collapse:collapse;width:100%;font-size:14px}th,td{text-align:left;padding:12px 10px;min-width:110px;border-bottom:1px solid var(--rule);vertical-align:top}th{color:var(--muted)}td:first-child{min-width:135px}figure{margin:24px 0}figcaption{font-weight:700;margin-bottom:10px}.chart{height:430px}select,input{max-width:100%;padding:8px;background:#102016;color:var(--fg);border:1px solid var(--rule);font:inherit}label{display:block;font-size:14px}input{display:block;width:100%;margin-top:7px}.calculator{display:grid;grid-template-columns:repeat(4,1fr);gap:16px}summary{cursor:pointer;color:var(--green)}footer li{margin-bottom:16px;overflow-wrap:anywhere}@media(max-width:700px){main{padding:26px 19px 60px}h1{font-size:34px}h2{font-size:23px}.lead{font-size:17px}.calculator{grid-template-columns:repeat(2,1fr)}table{min-width:590px}.chart{height:420px}.controls{display:block}.controls label{margin:12px 0}}"""
js="""const X=window.TRADE_DATA,cs=getComputedStyle(document.documentElement),col=k=>cs.getPropertyValue(k).trim(),green=col('--green'),blue=col('--blue'),red=col('--red'),muted=col('--muted'),rule=col('--rule');
const charts=['path-chart','outcome-chart','scenario-chart'].map(id=>echarts.init(document.getElementById(id),null,{renderer:'svg'}));
const axis={axisLabel:{color:muted},nameTextStyle:{color:muted},axisLine:{lineStyle:{color:rule}},splitLine:{lineStyle:{color:rule}}},tooltip={trigger:'axis',appendToBody:true};
function draw(){
charts[0].setOption({animation:false,tooltip,legend:{textStyle:{color:muted}},grid:{left:50,right:18,top:45,bottom:45},xAxis:{...axis,type:'category',data:X.paths.dates},yAxis:{...axis,type:'value',name:'累计 %'},series:['002244','002051','021902'].map((c,i)=>({name:X.names[c],type:'line',showSymbol:false,data:X.paths.funds[c].map(v=>+(v*100).toFixed(2)),itemStyle:{color:[red,blue,green][i]}}))},true);
const entry=document.getElementById('entry').value,fees=[+document.getElementById('low-fee').value,+document.getElementById('nuo-fee').value],rows=['002244','002051'].map((c,i)=>X.transfers.find(r=>r.code===c&&r.entry_date===entry&&r.redemption_fee===fees[i]));
charts[1].setOption({animation:false,tooltip,grid:{left:108,right:22,top:25,bottom:55},xAxis:{...axis,type:'value',name:'相对持有差额 / 元',nameLocation:'middle',nameGap:30},yAxis:{...axis,type:'category',inverse:true,data:rows.map(r=>X.names[r.code])},series:[{type:'bar',data:rows.map(r=>({value:Math.round(r.per_100k_difference),itemStyle:{color:r.per_100k_difference<0?red:green}}))}]},true);
document.getElementById('outcome-detail').textContent=`每项各转出10万元、仅观察17日至18日一个区间。低碳相对持有${rows[0].per_100k_difference.toFixed(0)}元，诺安${rows[1].per_100k_difference.toFixed(0)}元；这是示例，非实际账户收益。`;
const origin=document.getElementById('origin').value;
charts[2].setOption({animation:false,tooltip,legend:{textStyle:{color:muted}},grid:{left:105,right:20,top:45,bottom:50},xAxis:{...axis,type:'value',name:'条件响应 %',nameLocation:'middle',nameGap:30},yAxis:{...axis,type:'category',inverse:true,data:['震荡分化','科技盈利修复','增长担忧','实际利率上行']},series:[origin,'021902'].map((c,i)=>({name:X.names[c],type:'bar',itemStyle:{color:i?green:blue},data:X.scenarios.map(s=>+(s.funds[c].base*100).toFixed(2))}))},true);calc();}
function calc(){const ids=['low','nuo','gf','total'],fields=ids.map(id=>document.getElementById(id));const el=document.getElementById('allocation-result');if(fields.some(e=>e.value==='')){el.textContent='金额未填，暂不判断广发是否超过复核线。';return;}const [l,n,g,t]=fields.map(e=>+e.value);if([l,n,g,t].some(v=>!Number.isFinite(v)||v<0)||t<=0||l+n+g>t+.00001){el.textContent='请检查同一时点金额，三只之和不能超过总市值。';return;}
const fee=.5*l*(+document.getElementById('low-fee').value)+n*(+document.getElementById('nuo-fee').value),after=g+.5*l+n-fee,total=t-fee,p=after/total*100;
el.textContent=`忽略同时市场涨跌，扣费后广发约${after.toFixed(2)}万元，占${p.toFixed(2)}%；低碳剩余${(.5*l).toFixed(2)}万元，诺安0。${p>25?'超过25%人工复核线：暂停继续追加并重查集中度，不等于必须立刻卖出。':'未超过25%人工复核线，但仍需看全组合风险。'}`;}
['entry','low-fee','nuo-fee','origin'].forEach(id=>document.getElementById(id).addEventListener('change',draw));['low','nuo','gf','total'].forEach(id=>document.getElementById(id).addEventListener('input',calc));
draw();addEventListener('resize',()=>charts.forEach(c=>c.resize()));window.EXECUTED_TRADE_READY=true;"""
html=f'<!-- Generated by Trae Work -->\n<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>已报调仓复核 · {DATE}</title><style>{css}</style></head><body><main>{"".join(parts)}</main><script src="./_shared/js/echarts.min.js"></script><script src="./assets/data.js"></script><script src="./assets/trade.js"></script></body></html>'
for name in ["index.html",f"{DATE}.html"]:(OUT/name).write_text(html)
(OUT/"assets/trade.js").write_text(js)
(OUT/"assets/data.js").write_text("window.TRADE_DATA="+json.dumps(x,ensure_ascii=False).replace("<","\\u003c")+";")
(OUT/"report.md").write_text("\n".join(md))
for name in ["trade-analysis.json","trade-verification.json"]:shutil.copyfile(BASE/name,OUT/name)
shutil.copyfile(ROOT/f"research/executed_trade_notes_{DATE}.json",OUT/"notes.json")
shutil.copyfile(ROOT/"data/trade_feedback_2026-11-19.json",OUT/"feedback.json")
files=[p for p in BASE.rglob("*") if p.is_file()]+[ROOT/k for k in x["inputs"]]
Q=json.loads((ROOT/"data/quarter_review/2026-10-29/analysis.json").read_text())["funds"]
for c in ["002244","002051","021902"]:
    files += [ROOT/Q[c]["3"]["file"],ROOT/Q[c]["3"]["text_file"]]
files += [ROOT/f"research/executed_trade_notes_{DATE}.json",ROOT/f"research/transition_sources_{DATE}.json"]
files += [ROOT/"tools"/name for name in ["analyze_executed_trade.py","verify_executed_trade.py","build_executed_trade.py","check_executed_trade.py","collect_transition.py","collect_history.py","archive_deep_sources.py"]]
with zipfile.ZipFile(OUT/"dataset.zip","w",zipfile.ZIP_DEFLATED) as z:
    for p in dict.fromkeys(files):z.write(p,str(p.relative_to(ROOT)))
manifest={"date":DATE,"status":"user_reported_executed_not_broker_verified","files":{str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.rglob("*") if p.is_file() and p.name!="manifest.json"}}
(OUT/"manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
registry=PUBLIC/"proposals/index.json";r=[v for v in json.loads(registry.read_text()) if v["date"]!=DATE]
r.append({"date":DATE,"path":f"proposals/{DATE}/","title":"已报调仓复核：低碳减半、诺安清仓转广发","status":"user_reported_executed_not_broker_verified"})
registry.write_text(json.dumps(sorted(r,key=lambda v:v["date"],reverse=True),ensure_ascii=False,indent=2))
print(str(OUT/"index.html"))
