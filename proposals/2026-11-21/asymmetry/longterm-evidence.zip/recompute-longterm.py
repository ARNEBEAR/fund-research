"""Dated static portfolio comparisons. No probability, optimization or account access."""
from pathlib import Path
import json,hashlib,sys
import pandas as pd
import numpy as np

BASE=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parent
EVIDENCE=BASE/"evidence"
OUT=Path(sys.argv[2]) if len(sys.argv)>2 else BASE/"longterm-comparison.json"
baseline=json.loads((EVIDENCE/"baseline-v13.json").read_text())
funds={
 "CASH":{"name":"外部现金","equity_pct":0},
 "021902":{"name":"广发主题领先C","equity_pct":45.93,"manager":"冯汉杰","role":"估值纪律与灵活权益强度","failure":"持续低仓错过盈利修复，煤炭/内需现金流失效；不是现金"},
 "011066":{"name":"大成高鑫C","equity_pct":80.50,"manager":"刘旭","role":"企业质量与买价，长期核心","failure":"制造/出口利润下修、好企业买贵或方法迟钝"},
 "022415":{"name":"前海开源国企精选C","equity_pct":89.92,"manager":"田维","role":"高权益价值参与","failure":"金融/资源/公用事业共跌；独立产品周期短"},
 "021180":{"name":"易方达产业机遇C","equity_pct":86.36,"manager":"杨宗昌","role":"跨行业机会与估值迁移","failure":"资源/CXO共同需求冲击，规模骤增和换仓判断失误"},
 "027170":{"name":"交银环球精选C","equity_pct":87.82,"manager":"蔡铮","role":"有限海外经济敞口；独管观察席","failure":"美国大盘/科技/利率与汇率共振，独管任期短"},
 "011437":{"name":"中泰开阳价值优选C","equity_pct":93.49,"manager":"田瑀","role":"质量席位竞争者","failure":"更高权益，金融/周期重叠；估值迁移不兑现"},
 "010390":{"name":"易方达科益C","equity_pct":94.13,"manager":"黄蕴藉","role":"明确需要成长时的小卫星","failure":"AI需求共同风险、新独管与容量；不承担稳定核心"},
 "022714":{"name":"万家新兴蓝筹C","equity_pct":91.77},
 "519697":{"name":"交银优势行业","equity_pct":31.22},
 "012817":{"name":"国泰致和C","equity_pct":69.59},
 "510300":{"name":"沪深300ETF参照","equity_pct":100},
 "006075":{"name":"人民币标普联接研究参照","equity_pct":100}
}
plans={
 "L5":{"title":"L5 · 长期五席候选","scope":"longterm_candidate","weights_pct":{"021902":30,"011066":25,"022415":20,"021180":15,"027170":10},
       "reason":"减少旧A的成长与多重择时委托，提高质量和估值纪律；海外仅10%观察席。比例是职责研究预算，未按历史收益优化。",
       "trigger":"愿意按至少3年、最好5年以上的委托期限审视；允许阶段亏损与相对落后，且必要现金需求、费用和额度另核。",
       "cost":"可能错过单一科技强行情；价值/制造/资源仍可共跌，海外独管能力未证明。",
       "invalidation":"经理方法、容量或持仓机制失效；扣费长窗口没有同风险增益；个人期限或损失能力不适配。"},
 "L4":{"title":"L4 · 四席国内候选","scope":"longterm_candidate","weights_pct":{"021902":30,"011066":30,"022415":25,"021180":15},
       "reason":"不愿承担新海外独管阶段或渠道条件不满足时，去掉全球10%，高鑫和前海各加5%。",
       "trigger":"不需要常驻海外经济敞口，接受境内集中且按长期委托观察。",
       "cost":"失去跨币种和海外经济敞口，国内价值/制造/资源更集中；四只不自动更平滑。",
       "invalidation":"国内共同需求风险难补偿，或海外低成本替代的成本与可用性条件更清楚。"},
 "L90":{"title":"L90 · 五席＋10%现金","scope":"deployment_candidate","weights_pct":{"CASH":10,"021902":27,"011066":22.5,"022415":18,"021180":13.5,"027170":9},
       "reason":"保持L5内部结构，暂留10%可控资金。用于部署或流动性需求，不宣称提高同一风险篮子的纯盈亏比。",
       "trigger":"有分期投入、必要支出或额度未满足；具体比例由真实期限和损失预算决定。",
       "cost":"市场上行参与略低，现金实际工具及收益另核；10%不是统计最优。",
       "invalidation":"资金需要和执行障碍消失，风险资产买价有补偿时重新评估；风险扩大则提高外部现金，不硬守10%。"},
 "K5":{"title":"K5 · 开阳挑战高鑫","scope":"challenger","weights_pct":{"021902":30,"011437":25,"022415":20,"021180":15,"027170":10},
       "reason":"质量席位同权重竞争，检验田瑀的价格迁移；不因过去跑赢自动替换。",
       "trigger":"高鑫长期扣费同风险增益不足，开阳买卖解释、容量和跨期结果获得更强证据。",
       "cost":"Q3权益强度提高约3.25个百分点，与价值/金融可能更重合；不是同风险经理单纯互换。",
       "invalidation":"金融/周期集中或估值迁移失效，同风险改善不能覆盖更高权益与成本。"},
 "G6":{"title":"G6 · 加10%成长卫星","scope":"satellite_candidate","weights_pct":{"021902":25,"011066":20,"022415":20,"021180":15,"027170":10,"010390":10},
       "reason":"从广发和高鑫各减5%，科益占10%；仅当明确要提高成长参与时使用，不作为平滑核心默认。",
       "trigger":"科技相对估值和盈利预期具补偿，且独管和容量证据改善；接受更大共同成长冲击。",
       "cost":"股权强度和AI风险增加，可能加深回撤与延长修复。",
       "invalidation":"新任期和规模下风险调整证据不足，或AI投入到利润/现金流链条失效。"}
}
for k,p in baseline["currentDecision"]["plans"].items():
    plans[k]={"title":p["title"].replace("当前首选","旧阶段提案"),"scope":"previous_stage_proposal","weights_pct":p["weights_pct"],"reason":p["thesis"]}
for k in ["A","B"]:
    p=baseline["plans"][k]
    plans["OLD_"+k]={"title":"旧"+k+" · 原全额基金提案","scope":"previous_longterm_proposal","weights_pct":{c:w*100 for c,w in p["weights"].items()},"reason":"2026.11.21原提案；非用户当前实际持仓"}
plans["J5"]={"title":"J5 · 另一网站人工五只","scope":"external_reference","weights_pct":{"022415":30,"021902":30,"021180":15,"011066":15,"012817":10},"reason":"另一网站11月20日提案；只作同额参考"}
eq=lambda p:sum(w*funds[c]["equity_pct"]/100 for c,w in p["weights_pct"].items())
total_eq=eq(plans["L5"]);global_eq=10*.8782
plans["B74"]={"title":"B74 · 约同股权市场参照","scope":"market_reference","weights_pct":{"510300":total_eq-global_eq,"006075":global_eq,"CASH":100-total_eq},
             "reason":"按L5的Q3国内/海外股权映射搭建的市场代理＋现金；按100%股权近似参照，不是完整同风险或可执行产品方案"}
assert all(abs(sum(p["weights_pct"].values())-100)<1e-8 for p in plans.values())
allcodes=set(c for p in plans.values() for c in p["weights_pct"] if c!="CASH")
levels={}
hashes={}
for c in sorted(allcodes):
    file=EVIDENCE/f"{c}.csv"
    raw=pd.read_csv(file,parse_dates=["date"]).set_index("date").sort_index()
    if raw.index.has_duplicates or raw.wealth.isna().any() or (raw.wealth<=0).any():raise ValueError("Invalid wealth input "+c)
    if c=="011066":
        # Official report starts C-class performance on 2021-01-11; exclude disputed pre-start observations.
        raw=raw.loc["2021-01-11":]
    levels[c]=raw.wealth
    hashes[c]=hashlib.sha256(file.read_bytes()).hexdigest()
frame=pd.DataFrame(levels).dropna()
domestic_ids=["L4","J5"]
domestic_codes=list(set(c for k in domestic_ids for c in plans[k]["weights_pct"]))
domestic=pd.DataFrame({c:levels[c] for c in domestic_codes}).dropna()

def metric(path,dates):
    values=np.asarray(path,dtype=float);returns=values[1:]/values[:-1]-1
    high=np.maximum.accumulate(values);dd=values/high-1
    trough=int(np.argmin(dd));peak=int(np.argmax(values[:trough+1]))
    recover_indexes=np.flatnonzero(values[trough+1:]>=values[peak]-1e-12)
    recovery=int(trough+1+recover_indexes[0]) if len(recover_indexes) else None
    lastpeak=int(np.flatnonzero(values>=high-1e-12)[-1])
    underwater=dd<-1e-10;longest=run=0
    for item in underwater:
        run=run+1 if item else 0;longest=max(longest,run)
    return {
      "return":float(values[-1]-1),"mdd":float(dd.min()),"vol":float(returns.std(ddof=1)*np.sqrt(252)),
      "ulcer":float(np.sqrt(np.mean(dd**2))),"current_drawdown":float(dd[-1]),
      "underwater_fraction":float(underwater[1:].mean()),"longest_underwater_intervals":longest,
      "current_underwater_calendar_days":int((dates[-1]-dates[lastpeak]).days),
      "worst_episode":{"peak":str(dates[peak].date()),"trough":str(dates[trough].date()),
                       "recovered":str(dates[recovery].date()) if recovery is not None else None,
                       "days_peak_to_recovery":int((dates[recovery]-dates[peak]).days) if recovery is not None else None},
      "start":str(dates[0].date()),"end":str(dates[-1].date()),"intervals":len(values)-1
    }

def calculate(grid,p,mode):
    w=p["weights_pct"]
    if mode=="fixed":
        normalized=grid/grid.iloc[0]
        path=np.full(len(grid),w.get("CASH",0)/100)
        for c,amount in w.items():
            if c!="CASH":path+=normalized[c].to_numpy()*amount/100
    else:
        r=grid.pct_change(fill_method=None).iloc[1:]
        returns=sum((r[c]*amount/100 for c,amount in w.items() if c!="CASH"),start=pd.Series(0.0,index=r.index))
        path=np.r_[1,np.cumprod(1+returns)]
    return metric(path,grid.index),path

def window_sets(grid):
    windows={"full":grid,"120":grid.tail(121),"60":grid.tail(61),"20":grid.tail(21)}
    after=grid.loc[grid.index>=pd.Timestamp("2025-12-31")]
    windows["YTD"]=after if grid.index[0]<=pd.Timestamp("2025-12-31") else None
    return windows
comparisons={}
for group,grid,ids in [("global",frame,list(plans)),("domestic",domestic,domestic_ids)]:
    result={"start":str(grid.index[0].date()),"end":str(grid.index[-1].date()),"windows":{}}
    for window,sample in window_sets(grid).items():
        if sample is None:
            result["windows"][window]=None;continue
        item={"start":str(sample.index[0].date()),"end":str(sample.index[-1].date()),"intervals":len(sample)-1,
              "dates":[str(x.date()) for x in sample.index],"modes":{}}
        for mode in ["fixed","daily"]:
            item["modes"][mode]={}
            for k in ids:
                metrics,path=calculate(sample,plans[k],mode)
                item["modes"][mode][k]={"metrics":metrics,"wealth":[float(x) for x in path]}
        result["windows"][window]=item
    comparisons[group]=result

for k,p in plans.items():
    p["equity_q3_pct"]=eq(p)
    p["amounts_wan"]={c:w*230/100 for c,w in p["weights_pct"].items()}
    if k in comparisons["global"]["windows"]["60"]["modes"]["fixed"]:
        g=frame.tail(61)
        r=g.pct_change(fill_method=None).iloc[1:]
        w=pd.Series({c:amount/100 for c,amount in p["weights_pct"].items() if c!="CASH"})
        cov=r.loc[:,w.index].cov()
        variance=float(w@cov@w)
        p["risk_contribution_60"]={c:float(v) for c,v in (w*(cov@w)/variance).items()} if variance>0 else {}
        p["stress20_wan"]=230*p["equity_q3_pct"]/100*.2
manager_records={}
for c in ["021902","011066","022415","021180","027170","011437","008270","010390"]:
    s=levels.get(c)
    if s is None:
        f=EVIDENCE/f"{c}.csv";s=pd.read_csv(f,parse_dates=["date"]).set_index("date").wealth
    entries={}
    for year in ["2021","2022","2023","2024","2025","2026"]:
        before=s.loc[:f"{int(year)-1}-12-31"]
        yearvalues=s.loc[f"{year}-01-01":f"{year}-12-31"]
        if len(before) and len(yearvalues)>2:
            hist=pd.concat([before.tail(1),yearvalues])
            entries[year]=metric(hist/hist.iloc[0],hist.index)
    start=s.index[-1]-pd.DateOffset(years=3)
    prior=s.loc[:start]
    if len(prior):
        hist=s.loc[prior.index[-1]:]
        entries["3Y"]=metric(hist/hist.iloc[0],hist.index)
    manager_records[c]=entries
limits=[
 "本轮比例先按长期职责确定，未运行历史收益优化、最高夏普搜索或拟合未来。",
 "所有比较方案按230万元同额预算重算，非用户实盘；旧A/B、D60/D70/R40与另一站J5均为提案，不合并认作现仓。",
 "全球共同网格由原生C份额及所有参照共同可得日期决定；仅2026.04.15—11.19，不能证明牛熊穿越。国内L4/J5可延至2024.12.06—2026.11.20，仍不足完整多周期。",
 "主表期初恢复目标权重后自然漂移；每日恢复权重另列。短窗口重新配置起点，不是同一账户从全样本持续截取。",
 "基金净值已含日常运作费，未计持有人申购、赎回、转换、额度、在途或实际定价摩擦；现金收益设0，实际工具另核。",
 "年化波动是普通共同区间标准差×sqrt(252)，节假日和稀疏早期区间会影响解释；不把不规则区间称严格日频。回撤/修复只限已观察路径。",
 "ETF参照使用基金净值，不用场内价格；人民币标普联接按全股权近似基准，股票快照匹配不代表完整风险匹配。",
 "三季股权为9月30日快照，非实时仓位；027170直接股权78.13%＋股权ETF9.69%=87.82%。未来经理仓位和汇率可能改变。",
 "个别经理年度记录按原生C份额全产品计算，不等于现任独管成绩；新产品无足够历史时返回缺项，不拼接A/C或别的产品。",
 "高鑫C官方业绩起算为2021.01.11；本轮排除CSV中更早的争议记录，2021年度缺少年初锚时不输出完整年度回报；本轮2024/2026共同窗口不受影响。",
 "更平滑同时可能少赚；高收益、浅回撤、短修复需要共同比较，不以单一平滑分数认定经理或组合最优。"
]
result={"version":"V1.4","date":"2026-11-22","capital_cny":2300000,
        "definition":"长期权益增值为主，通过估值纪律、企业质量和不同委托机制，争取收益、回撤与修复时间的平衡；不预设长期高现金或永久满仓。",
        "horizon":"用于至少3年、最好5年以上的研究框架；实际资金期限尚未确认",
        "primary":"L5","plans":plans,"funds":funds,"comparisons":comparisons,
        "manager_product_records":manager_records,"nav_hashes":hashes,"limits":limits,
        "account_status":"未核用户当前完整账户；已定义存量组合按历史提案对照",
        "frozen_research":"所有当前权重回放都在2026-11-22事后定义；非前瞻战绩",
        "cash_note":"L5的0%外部现金只是纯基金结构比较，不是要求把必要现金投入或即时全仓下单；部署、支出和风险压力另决。"}
OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({"global":[comparisons["global"]["start"],comparisons["global"]["end"]],
                 "domestic":[comparisons["domestic"]["start"],comparisons["domestic"]["end"]],
                 "full_fixed":{k:v["metrics"] for k,v in comparisons["global"]["windows"]["full"]["modes"]["fixed"].items()},
                 "equity":{k:p["equity_q3_pct"] for k,p in plans.items()}},ensure_ascii=False,indent=2))
