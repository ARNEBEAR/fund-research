本包可独立复算，不联网、不下单。
使用Python3及numpy/pandas，运行：python3 recompute-longterm.py . recomputed.json
全部权重在2026-11-22事后定义。原生C份额全球窗口2026.04.15—11.19，国内L4/J5窗口2024.12.06—2026.11.20。旧提案不是实际用户账户；预算统一230万元。
