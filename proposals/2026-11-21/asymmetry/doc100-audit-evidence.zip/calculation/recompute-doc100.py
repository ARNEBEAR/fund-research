"""From the extracted audit evidence folder, run: python3 calculation/recompute-doc100.py."""
import json,math
from pathlib import Path
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/'data/calculations.json').read_text())
cs=list(D['plans']['A']['amounts'])
r=pd.concat({c:pd.read_csv(ROOT/f'nav/clean-{c}.csv',dtype={'date':str}).set_index('date')['return'].astype(float) for c in cs},axis=1)
r=r.loc[D['dates']]
assert not r.isna().any().any()
def metrics(s):
 w=np.r_[1,(1+s).cumprod().values]
 return {'return':float(w[-1]-1),'mdd':float((w/np.maximum.accumulate(w)-1).min()),'vol':float(s.std(ddof=1)*np.sqrt(252))}
results={}
for k,p in D['plans'].items():
 assert math.isclose(sum(p['amounts'].values()),230,abs_tol=1e-9)
 rp=sum(p['weights'][c]*r[c] for c in cs)
 m=metrics(rp)
 for x,v in m.items():assert math.isclose(v,p['metrics'][x],abs_tol=1e-9),(k,x,v,p['metrics'][x])
 for x,v in p['visible_cny_wan'].items():
  check=sum(p['amounts'].get(c,0)*(vals[x] or 0) for c,vals in D['visible_holdings'].items())
  assert math.isclose(check,v,abs_tol=1e-9)
 results[k]=m
assert math.isclose(D['plans']['C15']['metrics']['vol'],.85*D['plans']['A']['metrics']['vol'],abs_tol=1e-9)
assert math.isclose(D['plans']['C60']['metrics']['vol'],.4*D['plans']['A']['metrics']['vol'],abs_tol=1e-9)
print(json.dumps(results,ensure_ascii=False,indent=2))
print('All four budgets, historical metrics and disclosed exposure calculations reproduce within 1e-9.')
