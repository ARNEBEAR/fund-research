import json,math
from pathlib import Path
import numpy as np,pandas as pd

P=Path('/tmp/fund-doc100-audit')
OLD=Path('/Users/bytedance/Documents/Trae-CN/default/asymmetry-report/research-data.json')
D=json.loads(OLD.read_text())
V=Path('/tmp/fund-research-20261121/verified')
cs=list(D['plans']['A']['weights'])
rr=pd.concat({c:pd.read_csv(V/f'clean-{c}.csv',dtype={'date':str}).set_index('date')['return'].astype(float) for c in cs},axis=1)
rr=rr.loc[D['plans']['A']['dates']]
assert not rr.isna().any().any()
equity={x['code']:x['equity']/100 for x in D['managerCards']}
eq_actual={'022415':.8992471794516695,'021902':.4592668559265903,'011066':.8049915085203676,
           '021180':.8636181210913482,'010390':.9413476338669591,'022714':.9177493753981717,
           '027170':.8782,'519697':.31220998021717122}
# Both exposure scopes use NAV weights; this visible-stock subset is NOT full sector exposure.
visible={
 '022415':{'bank_top':.1962,'wx_top':0,'optics_top':0,'mining_cn':.1331,'alphabet_top':0},
 '021902':{'bank_top':0,'wx_top':0,'optics_top':0,'mining_cn':.1385,'alphabet_top':0},
 '011066':{'bank_top':0,'wx_top':0,'optics_top':0,'mining_cn':.0013,'alphabet_top':0},
 '021180':{'bank_top':0,'wx_top':.0983,'optics_top':0,'mining_cn':.3623,'alphabet_top':0},
 '010390':{'bank_top':0,'wx_top':0,'optics_top':.0504,'mining_cn':0,'alphabet_top':0},
 '022714':{'bank_top':0,'wx_top':0,'optics_top':.2196,'mining_cn':.1528,'alphabet_top':0},
 '027170':{'bank_top':0,'wx_top':0,'optics_top':0,'mining_cn':None,'alphabet_top':.0377},
 '519697':{'bank_top':.0993,'wx_top':.0988,'optics_top':.0065,'mining_cn':0,'alphabet_top':0},
}
def metrics(r):
    w=np.r_[1,(1+r).cumprod().values]
    return {'n':len(r),'start':r.index[0],'end':r.index[-1],'return':float(w[-1]-1),
            'mdd':float((w/np.maximum.accumulate(w)-1).min()),'vol':float(r.std(ddof=1)*np.sqrt(252))}
plans={
 'A':D['plans']['A']['amounts'],
 'R':{'022415':40,'021902':55,'011066':30,'021180':15,'010390':20,'022714':25,'027170':25,'519697':20},
 'C15':{**{c:v*.85 for c,v in D['plans']['A']['amounts'].items()},'CASH':34.5},
 'C60':{**{c:v*.4 for c,v in D['plans']['A']['amounts'].items()},'CASH':138},
}
keys=['market','communication_excess','dividend_excess','metal_excess','medical_excess','semi_excess']
shocks={'信用与利润共振':[-.08,-.15,-.10,-.12,-.12,-.10],
        '银行价格回吐、成长修复':[.02,.07,-.08,-.03,.03,.04],
        '技术需求增长、硬件利润折价':[-.03,-.12,-.02,0,0,-.06]}
out={}
for k,amounts in plans.items():
    assert math.isclose(sum(amounts.values()),230,abs_tol=1e-10)
    weights={c:v/230 for c,v in amounts.items()}
    r=pd.Series(sum(weights.get(c,0)*rr[c] for c in cs),index=rr.index)
    cash=weights.get('CASH',0)
    cov=rr.tail(60).cov().values;ww=np.array([weights[c] for c in cs])
    rc=ww*(cov@ww)/(ww@cov@ww)
    exposures={cat:sum(amounts.get(c,0)*(v[cat] or 0) for c,v in visible.items()) for cat in ['bank_top','wx_top','optics_top','mining_cn','alphabet_top']}
    out[k]={'amounts':amounts,'weights':weights,'metrics':metrics(r),'curve':list(map(float,(1+r).cumprod()-1)),
            'cash_assumed':cash,'equity_q3':sum(weights[c]*eq_actual[c] for c in cs),
            'risk_contributions':dict(zip(cs,map(float,rc))),'visible_cny_wan':exposures,
            'extra_scenarios':{},'existing_scenarios':{}}
    for name,s in D['scenarios'].items():
        x=sum(weights[c]*s['fund_response'][c] for c in cs)
        out[k]['existing_scenarios'][name]=float(x)
    for name,shock in shocks.items():
        responses=[]
        for n in ['60','120']:
            total=0
            for c in cs:
                if c=='027170':
                    val={'信用与利润共振':-.06,'银行价格回吐、成长修复':.04,'技术需求增长、硬件利润折价':-.06}[name]
                else:
                    f=D['fits'][c][n]['coef']
                    val=f['market']*shock[0]+sum(f[x]*(shock[i]-shock[0]) for i,x in enumerate(keys[1:],1))
                total+=weights[c]*val
            responses.append(float(total))
        out[k]['extra_scenarios'][name]={'low':min(responses),'high':max(responses),'center':responses[0]}
    out[k]['equity_common_shock']=-.2*out[k]['equity_q3']
    out[k]['equity_loss_wan']=230*out[k]['equity_common_shock']
outdata={'asof':D['asof'],'dates':list(rr.index),'plans':out,'shocks':shocks,
         'visible_holdings':visible,'source_scope':'基金Q3前十大及境内采矿业；未披露部分不填成已知0；Q3未知当前交易',
         'basis_sha256':'86d5eb9beb5a3b86467534680d52d5ddfa4205a495a505c6ff6bbee68a8ea96f',
         'cash_method':'未指定产品、现金收益设0，仅是假设；净值缺失未填0；每日恢复目标权重',
         'account_arithmetic':{'securities_fraction':188592/435555.68,'unclassified_assets':435555.68-188592,
                               'visible_weights_sum':.101+.099+.09+.083+.045+.011,
                               'pbc_unlisted_department_residual_wan_yuan':114200-(123900-14600-2395)}}
(P/'calculations.json').write_text(json.dumps(outdata,ensure_ascii=False,indent=2,allow_nan=False))
print(json.dumps({k:{z:v for z,v in p.items() if z in ['metrics','equity_q3','visible_cny_wan','extra_scenarios','equity_loss_wan']} for k,p in out.items()},ensure_ascii=False,indent=2))
