# Doc100 Credit And Bond Claim Audit

Research date: 2026-11-21. Archive under review: November 13-16, 2026. Research only; no recommendations, scoring, portfolio changes, or website edits.

## Scope And Evidence Rules

Read extracted section III and the credit-related context in IV. Block identifiers below refer to `/tmp/fund-doc100-audit/blocks.json` and the bracketed identifiers in `document.txt`. Excluded NBS/PBOC aggregate data, AI, individual equity financial claims, and investment rankings.

Supported means that the cited primary material supports the specific proposition, not every surrounding interpretation. Unverified means insufficient primary evidence in this bounded audit, not a finding that an event did not happen. Publication dates, contractual payment dates, funding completion, and investor receipt are kept separate. Later information is not silently inserted into the November 16 archive.

Effort disclosure: 18 web search/fetch calls, plus one unsuccessful direct reread of an already-open IMF page. This modestly exceeded the approximately 15-lookup target; the last three calls located and verified the priority IMF report, its definition, and publication metadata. No further sourcing was attempted.

## 1. IMF: Supported, With A More Precise Definition

Doc100 blocks 47-49, 360.

**Correct original:** *Local Government Finances in China: Policy Options to Tackle the Debt Overhang*, IMF Departmental Papers, 2026, Issue 019, DOI `10.5089/9798229047272.087.A001`.

- Publication metadata explicitly says **25 Sep 2026**.
- Section 2.A: "Recent financial statement data show that almost 95 percent of LGFV debt is issued by entities that cannot service interest payments from earnings, equivalent to almost 50 percent of GDP (Figure 4, panel 1)."
- Figure 4 note: "Debt-at-risk is defined as debt where the borrower's ratio of earnings before interest and taxes (EBIT) to interest expense is below 1."
- The same note specifies a **balanced panel of about 1,500 LGFVs accounting for 87 percent of estimated total LGFV debt**, with results scaled up by estimated total LGFV debt.
- Interest expense **includes capitalized interest expense**.

**Denominator:** Estimated LGFV debt, not the number of LGFVs, not only exchange-traded or interbank LGFV bonds, and not all official local-government debt. The underlying sample covers 87% of the estimated debt; the national presentation is an extrapolation, not a census. "Almost 95%" is the source's wording, not an exact 95.00%.

**Timing:** September 25, 2026 is the official publication date. The stronger wording "first-ever public disclosure" was not independently established through release timestamps or archived versions. The financial-statement observation endpoint for the 95% figure was not separately established from the chart image; do not label it a November 2026 point-in-time reading. The introduction's end-2025 overall debt estimates are not, by themselves, proof of the 95% chart's observation date.

**Contradicted interpretations:** 95% of LGFV debt has defaulted; 95% of LGFV borrowers have defaulted; or a claim that this is a default probability. EBIT coverage is not the same as cash actually paid, and refinancing or fiscal support can permit payment despite inadequate standalone earnings. The Figure 4 definition does not impose a three-consecutive-year test.

**Source identity correction:** An initially located April 30, 2025 China Financial System Stability Assessment, Country Report 2025/100, was a related but different report. It must not be substituted for this September 2026 source or used to import a different "non-viable" definition.

Original metadata/full-text page:
https://www.elibrary.imf.org/view/journals/087/2026/019/article-A001-en.xml

Original PDF, section 2.A and Figure 4 note:
https://www.elibrary.imf.org/downloadpdf/view/journals/087/2026/019/article-A001-en.pdf

**Archive implication:** Retain the figure with the debt-weighting, sampling, extrapolation, and EBIT definition. Keep block 48's rejection of a direct market-causation claim: publication chronology alone cannot establish that this report caused an A-share decline.

## 2. Zhuhai Huafa: Obligation Verified; Stress And Repricing Not Established

Doc100 blocks 53-54, 361.

An issuer-authored **October 26, 2026** notice, reproduced by Xinhua's China Financial Information platform and attributed to the Beijing Financial Assets Exchange, concerns **Zhuhai Huafa Industrial Co., Ltd.**, not automatically every entity in the Huafa group:

- Instrument: `22华发实业MTN003(并购)`, code `102200256.IB`.
- Outstanding principal and investor put amount: **100,000万元**, or **RMB 1 billion**.
- Coupon: **2.95%**.
- Principal plus interest payable: **102,950万元**, or **RMB 1.0295 billion / 10.295亿元**.
- Stated contractual date: October 31, 2026; adjusted to **November 2, 2026** because October 31 was a non-business day.

This is a payment-arrangement notice. It does **not** say funds were insufficient, payment had failed, a standstill had been agreed, or a default had occurred. It also does not independently prove that holders subsequently received the money.

Issuer notice text as reproduced, with source attribution and original-document link:
https://www.cnfin.com/announ/detail/index.html?announ=lc&code=600325&dannoun=lcdetail&id=846343136616

Original exchange document link exposed by that page, **not separately retrieved**:
https://www.cfae.cn/connector/selectOnePortalView?infoId=731130

Search surfaced media accounts of group financing concerns, offshore-loan repayment, and trust-payment developments, but no relevant original default, liquidity-shortfall, or trust-settlement disclosure was retrieved within the audit budget. Those accounts were not promoted to verified facts.

**Verdict:** The late-October payment obligation is supported. Block 53's generic "credit pressure" and block 54's statement that peer repricing already had local market evidence remain **unverified** here. The excerpt alone neither confirms nor disproves broader Huafa stress. Huafa Group, Huafa Industrial, offshore subsidiaries, and trust counterparties must be identified separately.

**Archive implication:** Label impairment of implicit guarantees and broader credit-risk-premium increases as hypotheses unless backed by instrument-level prices/spreads and issuer-specific disclosures. No systemic contagion or explanation of the entire A-share correction is established.

## 3. Qiaoyin Convertible: Both Notices Supported; Funding Is Not Same-Day Investor Receipt

Doc100 blocks 68-69, 361.

### November 13 Risk Notice

Original company disclosure, announcement **2026-138**, signed **November 13, 2026**: *关于“侨银转债”可能存在不能按期足额兑付本息的重大风险提示性公告*.

Original disclosure on CNINFO's document-rendering service:
https://dataclouds.cninfo.com.cn/xc2pdf2h5/2026/20261114/HTML5/c376fb3f-428a-4fa0-b7ea-f582cc6f9ae6.html

The URL is dated November 14, while the document is signed November 13. Its exact first-publication timestamp was not independently retrieved; the archive should cite the document date without inventing an intraday release time.

The disclosure explicitly states:

- Recent funding turnover pressure and short-term mismatch of liquid funds.
- Redemption funds were not fully in place.
- Existing monetary funds could not redeem principal and interest.
- **4,196,454** convertible bonds remained unconverted at November 12, **99.92%** of the original **4,200,000** bonds.
- Contractual maturity/registration: **November 16, 2026**; distribution to holders: **November 17, 2026**.
- Redemption price: **RMB 130 per bond**, including tax and final-year interest, not merely the RMB 100 face value.

For scale only, `4,196,454 x RMB 130 = RMB 545,539,020` at the November 12 unconverted count. This is an audit calculation, **not** the company's final settlement amount; subsequent conversions could reduce the final obligation.

The same company notice attributes collection difficulties to downstream regional fiscal pressure and reports September 30 receivables of **24.14亿元** plus contract assets of **11.31亿元**, totaling **35.45亿元**, about **43%** of assets of **82.54亿元**. This is an issuer's disclosed explanation and balance-sheet context, not independently proven causation across the public-services industry.

### November 16 Funding Follow-Up

Original company disclosure signed **November 16, 2026**: *关于侨银转债已足额缴付本息的公告*.

https://static.cninfo.com.cn/finalpage/2026-11-16/1225672485.PDF

Exact operative statement: "截至本公告披露日，公司已足额筹措‘侨银转债’到期兑付资金，并完成资金缴付。"

The disclosure schedules CSDC Shenzhen distribution through custodian securities firms on **November 17, 2026**, and states the company can pay the convertible's principal and interest in full on schedule.

**Verdict:** Block 68's November 13 cash-risk disclosure and November 16 completed-funding follow-up are **supported**. Reading November 16 as the date funds had already reached holders is **contradicted by the disclosed schedule**. The follow-up does not identify the funding source, so shareholder support, bank refinancing, asset sales, or collection success must not be asserted as the actual cure.

No exact November 16 intraday posting time was verified. Do not assume that this follow-up was known before that day's stock-market close. A November 18 settlement-results disclosure surfaced in search but was not used as evidence available to the November 16 archive.

**Archive implication:** Preserve both the demonstrated issuer-specific cash mismatch and the funding cure. Neither proves systemic failure, nor that all remaining cash-flow risks disappeared.

## 4. Bond ETFs: The Two Historical Numerical Claims Remain Unverified

Doc100 blocks 58-60, 361.

**Unverified:** Both 广发 `159397` and 南方 `159700` closed November 13, 2026 at approximately **0.5% discounts** to their official same-day NAVs.

**Unverified:** Bond ETFs had aggregate net outflows of **217亿元 / RMB 21.7 billion** over **November 10-13, 2026**.

No official historical closing-price/NAV pair for both funds and no reproducible fund-universe/flow methodology was obtained. No figure was guessed from screenshots, recent quotes, or media snippets.

The official Guangfa page was identified in search, but its current quote is not evidence of the claimed historical discount:
https://trade.gffunds.com.cn:4343/funds/?fundcode=159397

There is no verified historical evidence URL for the 159700 figure or the 217亿元 claim in this audit.

Minimum necessary evidence:

- Same-day unadjusted exchange close and final official NAV for each fund. Compute `discount = closing_price / same_day_NAV - 1`; distinguish final NAV from intraday IOPV and prior-day NAV.
- Specify the ETF universe, whether the dates are inclusive, and whether "net outflow" means primary-market net redemptions or a vendor's secondary-market trading-flow estimate.
- A change in assets under management is not, alone, a net-redemption measure because NAV changes also alter assets.

**Archive implication:** Block 59's proposed redemption feedback loop is a plausible mechanism, not a verified reconstruction of these dates. NAV exposure and secondary-market discount are components of an ETF's market price, not two independent losses to add together. Neither an ETF discount nor a price decline proves underlying defaults. R1 is not a capital guarantee, but no individual wealth-management product's contractual protections were audited.

## 5. Bond Tax: Enacted Rules Supported; November Rumor And Market Causation Unverified

Doc100 block 64, 361.

Primary tax-authority guidance quotes the operative legislation:
https://12366.chinatax.gov.cn/fwtz/print?bh=0000000002025080400003&iszs=1

### Enacted VAT Change

**财政部、税务总局公告2025年第4号**, *关于国债等债券利息收入增值税政策的公告*:

- Effective **August 8, 2025**.
- Restores VAT on interest from **newly issued treasury bonds, local-government bonds, and qualifying financial bonds** issued on or after that date.
- Bonds issued earlier, **including later reopenings of those pre-existing bonds**, remain VAT-exempt until maturity.
- The guidance gives a specific definition of financial bonds, including issuance by legally established domestic financial-institution legal persons and holding by financial institutions.

This was an enacted rule, not a new November 2026 rumor. It is not a blanket new income tax on every corporate or LGFV credit bond. The original signed notice's issue date was not separately retrieved; August 8 is its verified effective date, not an assumed publication date.

### Separate Foreign-Institution Exemptions

The same official guidance quotes **2026年第5号**:

- **January 1, 2026-December 31, 2027**: temporary corporate-income-tax and VAT exemption on domestic bond-market interest earned by foreign institutions.
- The corporate-income-tax exemption excludes income effectively connected with a foreign institution's establishment/place of business in China.

Original tax-policy database entry identified in search; **not separately opened**:
https://fgk.chinatax.gov.cn/zcfgk/c102416/c5247077/content.html

The guidance also quotes **2026年第6号**, exempting qualifying foreign institutions' interest on China's treasury and local-government bonds issued offshore, effective **August 8, 2025-December 31, 2027**. These distinct exemptions must not be conflated with domestic VAT treatment or with an ETF's investor-level tax treatment.

**Verdict:** These enacted-rule terms are **supported by primary tax-authority guidance**, although the standalone original notices and their issue dates were not all retrieved. Block 64's specific early-November 2026 rumor, what tax or taxpayer category it concerned, and its contribution to concentrated selling remain **unverified**. No newly enacted November 2026 blanket withdrawal of exemptions was established.

**Archive implication:** Specify tax type, taxpayer, bond type, issuance date, and grandfathering before inferring after-tax yields or valuation effects.

## Section IV And Equity Value-Fund Implications

Block 81 presents monitoring hypotheses, not a verified bank-capital-bond or LGFV spread series. This audit supplies no evidence that those specific November stock/bond divergences occurred. It does not audit the individual bank equity claims in section IV.

For equity value-fund research, the supported evidence justifies examining exposures, not assigning automatic sector-wide conclusions:

- For holdings tied to local public-service payments, distinguish accounting earnings from receivable conversion, liquid cash, and upcoming principal-plus-interest obligations.
- For banks, insufficient LGFV standalone interest coverage is an exposure question. It does not quantify any particular bank's loss rate, capital shortfall, or dividend impairment.
- For locally supported SOEs, identify the actual obligor, guarantees, funding arrangements, and restrictions on transferable cash; state ownership is not itself a verified payment guarantee.
- Do not treat unverified ETF outflows/discounts as evidence of equity-fund redemptions, systemic contagion, or a required change in equity valuation.
- A funding cure can remove a single scheduled-payment risk without establishing durable improvement in collections. Tax changes can affect after-tax bond yields without demonstrating a contemporaneous equity earnings shock.

## Suggested Archive Disposition

Retain IMF and Qiaoyin facts with the precision above. Downgrade Huafa stress/peer repricing, the two ETF numbers, November tax-rumor causation, and the specific section-IV market divergences to **unverified research questions**. Preserve the archive's existing rejection of blanket default, systemic-crisis, and market-causation claims.
