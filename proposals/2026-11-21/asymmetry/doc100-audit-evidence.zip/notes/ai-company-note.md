# Doc100 AI 与公司主张独立事实审计

核验日：2026-11-21。被审计文本：`/tmp/fund-doc100-audit/document.txt`，档案截止日为 2026-11-16。

范围仅限 AI/TPU、Alphabet 财务、腾讯/阿里财报日期、平高、药明、圆通及可便利取得的亿联数据。未开展经理、基金、持仓、交易或网站修改工作。

## 结论口径

- **TRUE / 证实**：已取得相应原始披露或明确的官方原文摘录。技术性能数字仍是厂商披露，不等于独立实验验证。
- **CONTRADICTED / 反驳**：取得直接相反证据。须区分档案当前表述与档案已经撤回的旧错误。
- **UNKNOWN / 未知**：在本次有限核验中未取得足够原始证据；不等于该主张为假。
- **HYPOTHESIS / 假说**：事实可以支持提出问题，但不能证明利润、估值、因果关系或未来结果。

时间边界：2026-10-28 Alphabet 资料和平高三季报可用于档案截止日前的事实核验；腾讯、阿里 11-18/19 的实际发布用于事后核实事件日期，不能当作 11-16 已知业绩。Google/Oracle 网页返回正文没有发布日期，不将其倒填为 11-16 已知信息。

## 主张逐项判定

| 档案编号 | 被审计主张 | 判定 | 依据与限制 |
| --- | --- | --- | --- |
| [143] | Google 已开展对外 TPU 系统销售，不仅是内部使用或出租云算力 | **TRUE** | Alphabet Q3 原始财报明确说 TPU systems sales 对收入增长有实质贡献；CFO 明确说明签约、备货、交付和开票的销售现金周期。[S1][S2] |
| [143] | 这些系统已销售给“自有数据中心客户”，并在客户自有机房部署 | **UNKNOWN，表述应收窄** | 已证实购买系统，但没有取得能确认客户机房产权或每种部署模式的官方原文。电话会 p18 的“own ... infrastructure/data centers”来自分析师问题，不能当作管理层对产权的确认。Oracle 官方资料描述的是 OCI 云部署，且计划从 2027 年开始，不等于当前企业自有机房销售。[S2][S3] |
| [144] | TPU 外售仍可能增加库存和营运资金占用，不能据此直接宣布 Alphabet CapEx 下降 | **TRUE，且已有实际财务证据** | CFO 说库存先增长、现金先流出，再交付开票；Q3 经营现金流受到 TPU 销售备货影响。2026 CapEx 指引仍为 1950-2050 亿美元，管理层预计 2027 显著增加。[S2] |
| [144]-[145] | 外售已经降低客户部署门槛、替代原有 Cloud 收入，或提高 TPU 独立利润率/ROIC | **HYPOTHESIS / UNKNOWN** | 产品级利润率不披露；没有量化收入替代、客户总成本、资本回报的原始证据。Google Cloud 综合利润率不能代替 TPU 系统利润率。[S2] |
| [149]-[150] | Alphabet 比 Broadcom 有更大的重新估值机会 | **HYPOTHESIS** | 对架构、软件和客户关系的控制是研究机制，不是估值或额外利润的证明。没有估值比较或增量利润归属测算。 |
| [150] | Alphabet 系统定义权增强必然导致 Broadcom 收入/利润下降 | **UNKNOWN，不可断言** | 该必然推论未获支持；官方电话会仍明确提到与 Anthropic “both directly and via Broadcom”的合作。这也不证明 Broadcom 未来必然增长。档案 [150] 对此保留边界是正确的。[S2] |
| [165] | TPU 存在 ICI/OCS 联合设计，互连拓扑不同，能动态处理部分链路故障 | **TRUE，厂商技术披露** | Google 官方说明 ICI 与 OCS 配合、重新路由光路径、绕开故障，并给出 goodput 指标。[S3] |
| [165]-[167] | OCS/NPO 已经减少特定交换机、PCB 或光模块公司的价值量/盈利 | **UNKNOWN；利润重分配只能标为 HYPOTHESIS** | 本次没有取得客户/供应商级 BOM、端口、采购、售价、毛利的原始数据。OCS 技术用途不等于全系统无需电网络；官方 OCI 描述仍包含 SmartNIC、网络 fabric、数据库和存储连接。[S3] |
| [165] | 华为 SuperPoD/NPO 的具体部署、连接数量与器件替代关系 | **UNKNOWN** | 本次未取得相应华为原始资料。不能用 Google OCS 资料替代对 NPO 的证明，也不能将两个技术名词当成同一机制。 |
| [131] | 腾讯财报日为 2026-11-18 | **TRUE** | 腾讯官方原始公告首段明确为 Hong Kong, 18 November 2026；官方业绩演示也标 Nov 18, 2026。[S4] |
| [131] | 阿里财报日为 2026-11-19 | **TRUE** | 阿里官方原始公告 p1 明确为 Hong Kong, China, November 19, 2026。[S5] |
| [218] | 平高负经营现金流的重要原因是主动缩短供应商付款账期、提高现金支付占比，而销售回款增加 | **TRUE：公司解释与报表方向一致** | 原始 2026 三季报明确作此解释；销售商品/劳务收到现金同比增加约 12.62 亿元。[S6] |
| [218]、[306] 已撤回旧错误 | 平高负经营现金流“证明公共项目回款恶化” | **CONTRADICTED，作为充分解释不成立** | 回款现金增加，原报表明确指向付款安排。不能据此反向证明所有客户账龄、逾期或未来回款均无风险。[S6] |
| [218] | 平高 10月/11月约 9.98 亿元中标，11月初公告 | **金额 UNKNOWN；公告日期有官方索引支持** | 巨潮公司公告索引列 2026-11-04 中标公告，但本次未读到对应中标公告原文及项目表。搜索中媒体报道支持 9.98 亿元，不升级为原始金额证据。不将其他月份的中标公告替代这一公告。[S7] |
| [223] | 药明康德已从 1260H 名单移除 | **TRUE** | 美国官方 Federal Register / GovInfo 2026-11-10 通知点名 WuXi AppTec Co., Ltd. 移除。[S8] |
| [223] | 一次 1260H 移除意味着 BIOSECURE/BCC 或所有美国监管风险解除 | **CONTRADICTED，就“全面解除”而言** | 官方移除通知明确保留在追加或补充理由基础上重新列入的可能。本次没有取得证明 BIOSECURE/BCC 清除的美国官方名单或决定；不能断言已清除。[S8] |
| [223] | 药明当前是否被正式认定为 BCC、是否已经获得该制度下的正式排除 | **UNKNOWN** | 本次未取得 OMB/BCC 官方名单或排除决定。律所对不同路径的分析只作为法律核验线索，不作为美国政府认定。[S9] |
| [223] | 药明 Q3 订单、持续经营利润和经营现金流强劲 | **UNKNOWN，本次未核财务** | 优先完成政策核验，未取得药明 2026 Q3 原始财务报告，不将档案评价升级为已核事实。 |
| [213] | 圆通 Q3 利润约 +39%，前三季度经营现金流约 +42% | **UNKNOWN** | 仅定位到上交所索引中 2026-10-21 三季报，未取得该报告原始数字。不得用搜索返回的 2025 三季报或媒体数字补齐。[S10] |
| [228] | 亿联收入、利润和经营现金流增速放缓，存货明显增长；战略备货可转为订单 | **财务 UNKNOWN；订单转化 HYPOTHESIS** | 本次未取得亿联 2026 Q3 原始报告。该可选项停止核验，未猜测存货、现金余额或增速；“战略备货”及可回收性也需管理层披露和周转数据。 |

## Alphabet 最新已定位财报与现金含义

已定位原始 Q3 2026 财报：2026-10-28 发布，期间截至 2026-09-30。[S1] 本次没有对其后所有可能的临时公告作穷尽性扫描，“最新”指已定位的最近季度业绩。

| 项目 | 原始披露 | 解释边界 |
| --- | --- | --- |
| Q3 总收入 | 1275.77 亿美元，约 +25% | 收入增长不是自由现金流增长。 |
| Q3 Google Cloud 收入 | 307.09 亿美元，约 +103% | 包含 TPU 系统销售贡献，不能将其全部视为经常性云服务收入。 |
| Q3 Cloud 经营利润 | 111.21 亿美元 | 综合经营利润率约 36.2%，为计算值；不是 TPU 独立毛利率或经营利润率。 |
| Q3 合并经营利润 / 归属普通股净利润 | 405.76 / 261.70 亿美元 | 经营利润同比上升，净利润同比下降；不能笼统说所有利润指标同步增长。 |
| Q3 经营现金流 / CapEx / FCF | 约 423 / 514 / -91 亿美元 | CFO 披露；423 - 514 = -91，单季 FCF 为负。[S2, p10-11] |
| 滚动十二个月 FCF | 约 197 亿美元 | 不能把单季负值直接外推为全年负值。[S2, p11] |
| 现金、现金等价物及可交易证券 | 2650.98 亿美元 | CFO 指其中约 904 亿美元为可交易股权证券；不能全部当成等同现金的低波动流动性。[S1][S2, p11] |
| 长期债务 | 1251.02 亿美元 | 现金余额增加不等于全部来自经营活动；当季另有债券及 ATM 股份融资。[S1] |
| 存货，期末 / 2025年末 | 133.08 / 24.39 亿美元 | 比较的是年末基期，不是同比。CFO 说明 TPU 系统备货影响 OCF。[S1][S2] |
| 2026 CapEx 指引 / 2027 方向 | 1950-2050 亿美元 / 预计显著增加 | 是管理层前瞻，不是已发生的 2027 支出；直接否定“当前官方已指引总 CapEx 下降”的说法。[S2, p12] |

重要现金机制：销售库存与自用固定资产是不同会计类别，二者都可消耗现金。TPU 外售某部分设备不计入传统 CapEx，不能据此推导合并现金支出、融资需求或资本回报必然改善。CFO 还指出 Q3 OCF 受到 52 亿美元欧盟罚款现金支付影响，不能将全部现金压力归给 TPU。[S2, p10-11、18-19]

## 平高原报表数字

原始三季报未经审计，披露日 2026-10-22。[S6]

- 1-9月经营现金流净额：-416,572,648.88 元，即约 -4.17 亿元；同比 -419.23%。
- 销售商品、提供劳务收到现金：11,052,877,246.77 元，上年同期 9,790,962,718.11 元；差额约 +12.62 亿元。
- 应收账款期末 6,143,005,667.38 元，2025年末 6,168,086,527.59 元。这是年末基期的余额比较，不是逾期/账龄或同比回款指标。
- 应付票据期末 8.98 亿元，2025年末 19.62 亿元；应付账款期末 50.54 亿元，2025年末 57.76 亿元。付款负债余额下降与公司解释方向一致，但不能仅凭余额变化计算全部现金付款因果。
- 存货期末约 27.87 亿元，2025年末约 17.65 亿元。供应商付款纠错不等于营运资本压力消失。
- Q3 归母净利润约 4.14 亿元、+30.50%；1-9月约 12.31 亿元、+25.34%。这些是平高数据，不应与圆通约 +39% 的待核主张混用。

公司给出的原因是已披露事实；它不是对全部现金流驱动因素的独立因果审计。档案应保留 [218] 的纠错，同时保留库存、订单交付、账龄和现金回收待观察项。

## 官方来源与原文摘录

### S1 Alphabet Q3 2026 原始财报，SEC Exhibit 99.1

URL: https://www.sec.gov/Archives/edgar/data/1652044/000165204426000080/googexhibit991q32026.htm

披露日：2026-10-28。

> "TPU systems sales were also a meaningful contributor to revenue growth."

> "Google Cloud ... revenues increased 103% to $30.7 billion."

余额表原始单位为百万美元：现金及证券合计 265,098；存货 13,308（2025年末 2,439）；长期债务 125,102。Cloud 收入 30,709、经营利润 11,121。

### S2 Alphabet 官方电话会及其官方链接逐字稿

HTML: https://abc.xyz/investor/events/event-details/2026/2026-Q3-Earnings-Call-2026-Ujou16CTw9/default.aspx

PDF: https://s206.q4cdn.com/479360582/files/doc_events/2026/Oct/28/2026_Q3_Earnings_Transcript.pdf

电话会日：2026-10-28。页码为 PDF 页码。HTML 首次提取成功但在关键段落前截断；随后直连 HTML 返回 403，没有重试该受阻页面；已从官方页面明确链接的 PDF 读取原文。

p9，Thomas Kurian：

> "In addition to our work with Anthropic, both directly and via Broadcom..."

p10-11，CFO：

> "Operating cash flow was negatively impacted by the buildup of inventory for TPU system sales, as well as a $5.2 billion cash payment for a 2018 EC fine..."

> "CapEx was $51.4 billion in the third quarter..."

> "We had negative free cash flow of $9.1 billion in the third quarter..."

p12，CFO：

> "our full-year 2026 CapEx guidance range of $195-$205 billion remain unchanged. We continue to expect our CapEx to increase significantly in 2027..."

p18，CFO：

> "we don't provide specific financials at the product level"

> "a TPU system is not just a chip ... including hardware, compute, storage, networking"

> "We build the inventory ahead of getting the revenue stream in."

> "as we start delivering and billing customers for these TPU systems, then you see cash coming in. So it's not the traditional kind of CapEx ... but rather a different cycle of cash flow generation."

p19，CFO：

> "to date we've had some system sales recorded as revenue, but expect more of it to come in through 2027."

### S3 Google Cloud / Oracle TPU 官方说明

URL: https://cloud.google.com/blog/products/infrastructure/bringing-google-tpus-to-oracle-cloud-infrastructure/

抓取正文未显示发布日期，因此不认定其首次披露早于档案截止日。

> "making OCI the first hyperscaler outside Google to offer TPUs ... deploy TPU capacity on OCI starting in the calendar year 2027."

> "By pairing on-die Inter-Chip Interconnect (ICI) routing with Optical Circuit Switching (OCS), the control plane ... dynamically routes optical paths around faults..."

> "While TPUs move chip-to-chip traffic over ICI and OCS, Oracle Acceleron provides the networking foundation that connects TPU capacity to the rest of OCI."

这些原文支持系统级互连及另一云平台的部署计划，不支持客户机房产权、上市供应商订单下降或 NPO 利润测算。

### S4 腾讯官方 Q3 2026 公告

URL: https://www.tencent.com/wp-content/uploads/2026/11/tencent-announces-2026-third-quarter-results.pdf

官方检索结果原文：

> "Hong Kong, 18 November 2026 ... today announced the unaudited consolidated results for the quarter ended 30 September 2026"

交叉官方演示 URL: https://static.www.tencent.com/website-2026-upload/Tencent-3Q26-earnings-presentation-1dfb9c.pdf

> "Nov 18, 2026"

日期核验成立；本次未另作腾讯财务数字审计。

### S5 阿里官方 September Quarter 2026 公告

URL: https://data.alibabagroup.com/ecms-files/1532295521/e676aff4-e76d-489b-960a-47b9cf36485d/Alibaba%20Group%20Announces%20September%20Quarter%202026%20Results%20and%20Interim%20Results%20for%20the%20Six%20Months%20Ended%20September%2030,%202026.pdf

已直接提取原始 PDF p1：

> "Hong Kong, China, November 19, 2026 ... today announced its financial results for the quarter and the six months ended September 30, 2026."

日期核验成立；本次未另作阿里财务数字审计。

### S6 平高电气 2026 年第三季度报告，上交所原件

URL: https://static.sse.com.cn/disclosure/listedinfo/announcement/c/new/2026-10-22/600312_20261022_7ZV9.pdf

主要会计数据变动原因：

> "本期加大回款力度，货款回收同比增加，同时公司积极履行社会责任，主动缩短付款账期、提升现金支付占比，切实保障中小企业利益、强化供应链安全和韧性，导致经营现金流净额同比减少。"

合并现金流量表原文：销售商品、提供劳务收到的现金 11,052,877,246.77 / 9,790,962,718.11 元，分别为 2026 / 2025 前三季度。

### S7 平高中标公告官方索引，仅作定位

URL: https://www.cninfo.com.cn/new/disclosure/stock?f002v=001001&stockCode=600312

官方索引摘录：

> "平高电气：河南平高电气股份有限公司中标公告 | 2026-11-04"

未取得对应原始公告项目表，故本索引不是 9.98 亿元金额证据。

### S8 美国政府原始移除通知

GovInfo 原文: https://www.govinfo.gov/content/pkg/FR-2026-11-10/html/2026-22840.htm

Federal Register: https://www.federalregister.gov/documents/2026/11/10/2026-22840/notice-of-removal-of-designated-chinese-military-company

官方 XML: https://www.federalregister.gov/documents/full_text/xml/2026/11/10/2026-22840.xml

官方 PDF: https://www.govinfo.gov/content/pkg/FR-2026-11-10/pdf/2026-22840.pdf

91 FR 72536，2026-11-10 发布；文书签署 11-05，11-09 提交。已直接读取 GovInfo 原文。

> "decided to delist ... without prejudice to relisting the entity on additional or supplementary grounds: WuXi AppTec Co., Ltd. (WuXi AppTec)"

> "should be removed from the most recent Section 1260H List ... in compliance with the order ... on August 7, 2026 ... Motion for Preliminary Injunction"

这是官方移除事件证据，不是全部监管风险已消失的证明。初步禁令及依令移除不应写为案件最终胜诉或永久不得再列入。

### S9 BIOSECURE/BCC 法律分析线索，非美国政府决定

URL: https://www.ropesgray.com/en/insights/alerts/2026/11/dod-removes-wuxi-apptec-from-the-1260h-list

日期：2026-11-11。

> "nor does it preclude WuXi from being named a biotechnology company of concern (BCC) under the BIOSECURE Act through an alternative pathway."

来源性质：律所分析。它描述 1260H 相关路径及另一 OMB 认定路径，但本次未取得完整原始法律文本及 BCC 官方名单，不将其制度细节、实施时间预测或药明最终认定写作已核政府事实。

### S10 圆通 2026 Q3 报告官方索引，仅作定位

URL: https://www.sse.com.cn/assortment/stock/list/info/announcement/index.shtml?productId=600233

官方索引摘录：

> "600233 | 圆通速递 | 圆通速递股份有限公司2026年第三季度报告 | 2026-10-21"

未取得对应原始报表正文。约 +39% / +42% 保留 UNKNOWN，不用不同年份的数据拼接。

## 只应保留为假说的结论

1. Alphabet 会从系统定义权取得最多额外利润、获得最大估值重估。
2. TPU 外售会净替代原有云收入、降低合并投资强度，或改善独立业务利润率与 ROIC。
3. OCS/NPO 导致特定交换机、PCB、光模块厂商业绩下修，或必然损害 Broadcom。
4. AI 设计提速会缩短 ASIC 护城河或经济寿命；这需要实际迭代、迁移和盈利证据。
5. 海外 AI 投资变化与中国内需风险必然共振；资本开支增速、绝对金额、采购结构和单企收入仍须分别核验。
6. 平高中标必然转为及时收入和回款；药明移除一份名单即消除商业尾部风险；亿联备货必然兑现订单。

## 边界与停止点

执行了 18 次定向 WebSearch/WebFetch 操作，随后不再新增搜索。为补足截断和直接读取原件，又对已定位来源作 5 次读取请求：Alphabet HTML（403 后停止）、GovInfo、阿里原始 PDF、Alphabet 官方逐字稿 PDF 两次。这是实际请求数量披露，不把补读声称为零成本或已穷尽。

没有为填满结论追查圆通原报表、平高中标金额原表、亿联可选项、华为 NPO 原始材料或美国 BCC 官方清单。上述未完成项均已标 UNKNOWN。不得将“未找到”改写为不存在，亦不得将相邻的真实技术/财务事实用作具体供应商利润变化的替代证明。
