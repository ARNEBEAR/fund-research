2026-11-22原生基金净值与组合筛查证据。CSV内wealth为已按分红重建的财富序列；基金份额不拼接。高鑫C仅使用2021.01.11以后；新兴蓝筹C仅使用2024.11.28以后。portfolio-engine.js可用Node require后调用compare/assess独立重算。适配阈值是人工筛查，不是预测概率。
