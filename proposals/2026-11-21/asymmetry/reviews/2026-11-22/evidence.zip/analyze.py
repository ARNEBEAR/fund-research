from pathlib import Path
import json,re,calendar
import numpy as np,pandas as pd
from bs4 import BeautifulSoup

ROOT=Path("/tmp/market-review-20261122")
SRC=json.loads((ROOT/"collection.json").read_text())
OLD=json.loads(Path("/Users/bytedance/Documents/Trae-CN/default/asymmetry-report/research-data.json").read_text())
END="2026-11-19"
def metric(wealth):
    a=wealth.to_numpy()/wealth.iloc[0];r=a[1:]/a[:-1]-1
    peak=np.maximum.accumulate(a);dd=a/peak-1;ti=int(np.argmin(dd));pi=int(np.argmax(a[:ti+1]))
    recovery=next((i for i in range(ti+1,len(a)) if a[i]>=a[pi]),None) if dd.min()<0 else 0
    return {"start":str(wealth.index[0].date()),"end":str(wealth.index[-1].date()),"n":len(r),
            "return":float(a[-1]-1),"mdd":float(dd.min()),"vol":float(np.std(r,ddof=1)*np.sqrt(252)),
            "current_dd":float(dd[-1]),"ulcer":float(np.sqrt(np.mean(dd**2))),
            "underwater_share":float(np.mean(dd[1:]<-1e-10)),
            "recovery_days":int((wealth.index[recovery]-wealth.index[pi]).days) if recovery is not None else None,
            "recovery_date":str(wealth.index[recovery].date()) if recovery is not None else None}
def window(series,start,end=END):
    last=series.loc[:end]
    if len(last)<4 or series.index[0]>pd.Timestamp(start):return None
    before=last.loc[:start]
    if before.empty or (pd.Timestamp(start)-before.index[-1]).days>7:return None
    use=last.loc[before.index[-1]:]
    if len(use)<4:return None
    return use
def basics(code,f):
    p=ROOT/"raw"/f"basic-{code}.html"
    out={}
    if p.exists():
        soup=BeautifulSoup(p.read_bytes(),"html.parser");table=soup.select_one(".info.w790")
        if table:
            for tr in table.select("tr"):
                cells=tr.find_all(["th","td"])
                for i in range(0,len(cells)-1,2):out[cells[i].get_text(" ",strip=True)]=cells[i+1].get_text(" ",strip=True)
    return out
def tenure(code):
    p=ROOT/"raw"/f"manager-{code}.html"
    if not p.exists():return []
    soup=BeautifulSoup(p.read_bytes(),"html.parser");result=[]
    for table in soup.select("table"):
        t=table.get_text(" ",strip=True)
        if "起始期" in t and "截止期" in t and "基金经理" in t:
            for tr in table.select("tr"):
                cells=[c.get_text(" ",strip=True) for c in tr.find_all("td")]
                if len(cells)>=3 and re.fullmatch(r"\d{4}-\d{2}-\d{2}",cells[0]):
                    result.append({"start":cells[0],"end":cells[1],"manager":cells[2],"raw":cells})
    return result

funds={};series={}
for c,f in SRC["funds"].items():
    if "nav" not in f:continue
    b=basics(c,f);inception=b.get("成立日期/规模","")[:11]
    im=re.match(r"(\d{4})年(\d{2})月(\d{2})日",inception);inc="-".join(im.groups()) if im else None
    rows=f["nav"]
    if inc:rows=[r for r in rows if r[0]>=inc]
    dates=pd.to_datetime([r[0] for r in rows]);v=pd.Series([r[2] for r in rows],index=dates).sort_index()
    if v.index.has_duplicates:raise ValueError(c+" duplicate dates")
    series[c]=v
    stages=tenure(c)
    alloc=f.get("allocation_feed",{});cats=alloc.get("categories") or []
    equity=next((x["data"][-1] for x in alloc.get("series",[]) if x["name"]=="股票占净比" and x.get("data")),None)
    funds[c]={"code":c,"name":f["name"],"category":f["category"],"origin":"new","discovery":f["selected_by"],
              "manager":[x["name"] for x in f["manager_feed"]],"tenure":stages,"basics":b,
              "inception":inc,"first":str(v.index[0].date()),"last":str(v.index[-1].date()),
              "equity_feed":equity,"equity_date":cats[-1] if cats else None,
              "fee_display":{k:v for k,v in b.items() if "费率" in k},"events":f["events"],
              "sources":[x for x in SRC["sources"] if c in x["file"] and x["status"]=="retrieved"],
              "gaps":[x["file"].split("-")[0] for x in SRC["sources"] if c in x["file"] and x["status"]!="retrieved"]}
for c in list(OLD["names"])+["510300","510880","006075","002611"]:
    f=OLD["workbench"]["funds"][c]
    if not f["nav"]:continue
    series[c]=pd.Series([r[1] for r in f["nav"]],index=pd.to_datetime([r[0] for r in f["nav"]]))
    funds[c]={"code":c,"name":f["name"],"category":f.get("family"),"origin":"existing" if c in OLD["names"] else "benchmark",
              "manager":[f.get("manager")],"tenure":f.get("tenure"),"basics":{},"inception":f["first_date"],
              "first":f["first_date"],"last":f["data_asof"],"equity_feed":f.get("equity_pct"),"equity_date":f.get("holdings_asof"),
              "sources":f["sources"],"thesis":f.get("thesis"),"risk":f.get("risk"),"gaps":[]}
periods={"1M":1,"3M":3,"6M":6,"1Y":12,"2Y":24,"3Y":36,"5Y":60}
for c,f in funds.items():
    v=series[c];f["metrics"]={}
    for name,months in periods.items():
        start=(pd.Timestamp(END)-pd.DateOffset(months=months)).strftime("%Y-%m-%d");w=window(v,start)
        f["metrics"][name]=metric(w) if w is not None else None
    f["annual"]={}
    for year in range(2022,2027):
        w=window(v,str(year-1)+"-12-31",min(END,str(year)+"-12-31"))
        f["annual"][str(year)]=metric(w) if w is not None else None
    f["metrics"]["2026Q3"]=None;w=window(v,"2026-06-30","2026-09-30")
    if w is not None:f["metrics"]["2026Q3"]=metric(w)
    stage=f["tenure"]
    if isinstance(stage,list) and stage:
        current=next((s for s in stage if s["end"] in ["至今","—","--"]),None)
        if current:
            start=current["start"];w=window(v,start);f["current_stage"]={**current,"metrics":metric(w) if w is not None else None}
    rolling=[]
    for end in pd.date_range("2023-12-31","2026-10-31",freq="ME"):
        start=end-pd.DateOffset(years=1);w=window(v,str(start.date()),str(end.date()))
        if w is not None:rolling.append(metric(w))
    f["rolling12"]={"count":len(rolling),"positive_share":float(np.mean([x["return"]>0 for x in rolling])) if rolling else None,
                    "min":min([x["return"] for x in rolling]) if rolling else None,"median":float(np.median([x["return"] for x in rolling])) if rolling else None,
                    "note":"月末观察的重叠12月历史窗口，正收益占比不是未来胜率"}
    f["curve"]=[[str(d.date()),round(float(x),10)] for d,x in v.loc["2021-11-01":].items()]

weights=OLD["workbench"]["reference_weights"]
base=pd.concat({c:series[c] for c in weights},axis=1).dropna().loc["2026-04-15":END]
basewealth=sum(base[c]/base[c].iloc[0]*w/100 for c,w in weights.items())
comparison={}
for c,f in funds.items():
    frame=pd.concat({"base":basewealth,"candidate":series[c]},axis=1).dropna()
    if len(frame)<20:continue
    original=frame.base/frame.base.iloc[0];candidate=frame.candidate/frame.candidate.iloc[0]
    changed=original*.9+candidate*.1
    bm=metric(original);cm=metric(changed);bret=original.pct_change().iloc[1:];cret=candidate.pct_change().iloc[1:]
    down=bret<0
    comparison[c]={"base":bm,"variant":cm,"return_delta":cm["return"]-bm["return"],"mdd_delta":cm["mdd"]-bm["mdd"],"vol_delta":cm["vol"]-bm["vol"],
                   "correlation":float(bret.corr(cret)),"downside_correlation":float(bret[down].corr(cret[down])) if down.sum()>=10 else None,
                   "sample_note":"现有五基金等比例划出10%，换入该基金；期初配置后自然漂移、同日净值。事后实验。"}
    f["marginal10"]=comparison[c]
result={"asof":"2026-11-22","nav_cutoff":END,"funds":funds,"reference":{"weights":weights,"metrics":metric(basewealth),"curve":[[str(d.date()),float(v)] for d,v in basewealth.items()]},
        "universe_counts":{k:{"loaded":len(v["rows"]),"reported":v["reported_total"]} for k,v in SRC["ranks"].items()},"periods":periods}
(ROOT/"analysis.json").write_text(json.dumps(result,ensure_ascii=False,separators=(",",":"),allow_nan=False))
show=[]
for c,f in funds.items():
    if f["origin"]!="new":continue
    m=f["metrics"];three=m["3Y"] or {};two=m["2Y"] or {};one=m["1Y"] or {};latest=m["3M"] or {};effect=f.get("marginal10",{})
    show.append({"code":c,"name":f["name"],"manager":f["manager"],"3y_return":round(three.get("return",0)*100,2),"3y_mdd":round(three.get("mdd",0)*100,2),"1y_return":round(one.get("return",0)*100,2),"3m_return":round(latest.get("return",0)*100,2),"delta_return":round(effect.get("return_delta",0)*100,2),"delta_mdd":round(effect.get("mdd_delta",0)*100,2),"correlation":round(effect.get("correlation",0),2)})
print(json.dumps(show,ensure_ascii=False,indent=2))
