# -*- coding: utf-8 -*-
from pathlib import Path
import json,re,html,shutil,hashlib,zipfile,importlib.util
import pandas as pd
import numpy as np

R=Path("/tmp/market-review-20261122")
OUT=Path("/Users/bytedance/Documents/Trae-CN/default/asymmetry-report/reviews/2026-11-22")
BASE=OUT.parent.parent
A=json.loads((R/"analysis.json").read_text())
C=json.loads((R/"collection.json").read_text())
Q=json.loads((R/"quality-research.json").read_text())
V=json.loads((R/"value-research.json").read_text())
own=json.loads((R/"main-judgments.json").read_text())
own["162201"].update({"why":"原文确认科技创新进攻方法，三年产品回报突出；现任孙硕2025.04.10加入，不能继承全部三年成绩。",
                     "counter":"Q3亏29.01%，三年最大回撤超过50%，9月21日基准提高成长比例；当前角色与平滑核心不匹配。",
                     "manager_note":"孙硕原报任职2025.04.10起；产品历史包含前任。基准2026.09.21变更，跨期超额需按各阶段分别评价。"})
for code,update in {
 "001198":{"why":"原文确认半导体核心赛道集中，是主动进攻而非灵活配置名称暗示的平衡。","counter":"A类Q3亏35.08%；经理持续重仓存储、晶圆等半导体，三年高收益与深回撤同时存在，不适合平滑核心。"},
 "008988":{"why":"原文明确反思重仓AI硬件的损失，并计划更均衡，过程可继续验证。","counter":"A类Q3亏37.02%，显著弱于基准；承认失误是信息，不等于后续风险控制已改善。"},
 "009707":{"why":"原文确认聚焦半导体、设备/GPU/晶圆及零部件；不是广泛制造分散。","counter":"A类Q3亏30.58%，技术前沿进步与股东现金回报仍需分开，三年回报不抵消深回撤。"},
 "001194":{"why":"原文确认这是高权益AI算力、应用、AIDD和机器人配置；不能按“稳健”二字使用。","counter":"A类Q3亏29.98%，股票约91%净资产；名称不是风险承诺。原报与净值已对账，但长期特殊事件仍不能由一季认证。"},
 "450004":{"why":"现任较长任期，原文同时配置电子、通信、设备和周期制造；不能按名称推断纯防守价值。","counter":"A类Q3亏20.89%，自称均衡仍遭成长估值压缩；多周期及换入实验没有支持当前替换。"}
}.items():own[code].update(update)
vz=json.loads((R/"value-zh.json").read_text())
old=json.loads((BASE/"research-data.json").read_text())
SOURCES=[];source_by_url={};source_ids={}
def source(key,title,url,date=None,kind="原始披露",note=""):
    if not url:return None
    if url in source_by_url:
        i=source_by_url[url];source_ids[key]=i;return i
    i=len(SOURCES)+1;source_ids[key]=i;source_by_url[url]=i
    SOURCES.append({"id":i,"title":title,"url":url,"date":date or "本轮读取2026-11-22","kind":kind,"note":note})
    return i
universe=json.loads((R/"universe.json").read_text())
source("universe","公开基金名称、代码与类别目录",universe["url"],"2026-11-22","平台目录","份额记录数不是独立基金数，也不是已完成全面评审数。")
for row in C["sources"]:
    if row["status"]=="retrieved" and row["file"].startswith("ranking"):
        source(row["file"],"开放式"+("混合型" if "hh" in row["file"] else "股票型")+"排名发现目录",row["url"],"2026-11-20","平台发现数据","收益排名仅作发现，不作未来适配评级。")
for pack in [Q,V]:
    for s in pack["sources"]:
        source(s["id"],s.get("title") or (s.get("code","基金")+" "+("原始季度披露" if "Q3" in s["id"] else "经理/产品补证")),s.get("url"),
               s.get("published_on") or s.get("source_date"),s.get("type","原始披露"),s.get("limitations",""))
for path in ["main-quarter-sources.json","more-sources.json","final-quarter-sources.json","macro-sources.json"]:
    for s in json.loads((R/path).read_text()):
        if s["status"]!="retrieved" or s.get("parse_error"):continue
        key=s["file"];c=re.search(r"(\d{6})",key);name=A["funds"].get(c.group(1),{}).get("name",c.group(1)) if c else ""
        source(key,(name+"2026年第三季度报告") if key.startswith("quarter") else {"macro-stats.html":"国家统计局1—10月投资原表","macro-brief.html":"国家统计局10月经济发布会","macro-pbc.html":"央行10月金融统计","macro-fed.html":"美联储10月28日决议","index-rule.pdf":"中证红利低波动指数编制方案（11月20日文件）"}.get(key,name+"官方产品/经理页面"),
               s["url"],"2026-10-27" if key.startswith("quarter") else "2026-11-22读取",
               "原始报告（镜像不算独立信源）" if key.startswith("quarter") else "官方页面/规则")
source("doc","Doc100市场机制审议与原文依据（私人仓位已排除）","../../index.html#document","2026-11-22","参考输入的独立审议")
source("nav","本轮原生份额净值、复算程序和原文证据包","evidence.zip","净值截止2026-11-19","公开供数序列＋原报季度交叉核验","净值平台仍是单一底层供数；季度对账不等于每个历史日独立审计。")
source("prior","既有31只候选的经理与方法研究","../../index.html#managers","2026-11-22","既有研究记录","旧池不虚报为本轮全量重新检索；经理分数不参与本轮评级。")

funds=A["funds"]
quality_by={f["code"]:f for f in Q["funds"]}
value_by={f["code"]:f for f in V["funds"]}
for c,f in funds.items():
    if c in own:f.update(own[c])
    if c in quality_by:
        q=quality_by[c]
        status={"candidate":"观察","observe":"观察","not_default":"暂不纳入"}[q["status"]]
        if c=="000628":status="同产品份额"
        f.update({"status":status,"group":{"161005":"质量成长","260108":"消费质量","110011":"A/H质量","001938":"成长轮动","163417":"成长医疗","519772":"应用成长","000663":"制造周期","000628":"同产品A类","000577":"集中成长","005267":"资源价值"}[c],
                  "why":q["thesis"],"counter":q["counter"],"replace":"；".join(q["replace"]),"trigger":q["conditions"],
                  "failure":q["shared_failure"],"manager_note":q["attribution"],"tenure":q["stages"],"manager":q["managers"],
                  "fees":q["fees"],"execution":q["purchase"],"equity_note":f"原文股票占净资产{q['equity_pct_net']:.2f}%；港股占净资产{q.get('hk_pct_net',0):.2f}%。",
                  "size_note":f"全产品净资产{q['total_net_assets_cny']/1e8:.2f}亿元，A/C等份额合计；不是只取A类规模。",
                  "q3_return":q["returns_quoted"]["q3"],"source_ids":[source_ids[s] for s in q["source_ids"] if s in source_ids],
                  "gap_note":"；".join(q["evidence_gaps"])})
    if c in value_by:
        v=value_by[c];f.update(vz[c]);mgr=v["manager"];fee=v["fees"]
        equity_net=v.get("equities_pct_net_assets_reported")
        if equity_net is None:equity_net=v.get("equities_pct_net_assets_calculated")
        equity_total=v.get("equities_pct_total_assets_reported")
        equity_text=(f"{equity_net:.2f}%" if equity_net is not None else "未核")
        total_text=(f"{equity_total:.2f}%" if equity_total is not None else "未核")
        f.update({"manager":[mgr["name"]],"manager_note":f"{mgr['name']}加入日期{mgr['appointed']}；现独管阶段{mgr['current_sole_segment_start']}起。共管/前任阶段单列，不将全产品历史归现任。",
                  "equity_note":f"季报股票占净资产{equity_text}（原文或由股票金额/全份额净资产复算）；占总资产{total_text}；行业/十大为9月末。",
                  "size_note":f"全份额净资产{v['net_assets_whole_fund_100m_yuan']:.2f}亿元；十大合计{v['top_ten_weight_pct_net_assets_sum_rounded']:.2f}%净资产。",
                  "fees":f"管理{fee.get('management_pct_pa')}%＋托管{fee.get('custody_pct_pa')}%＋销售服务{fee.get('sales_service_pct_pa')}%/年；A标准申购最高{fee.get('subscription_standard_max_pct')}%。玉衡费率有原始概要；其余部分仍为平台费率快照，赎回/渠道另核。",
                  "execution":"申赎与额度仅有本轮平台快照；实际渠道当日状态及全部正式限额公告未齐。",
                  "q3_return":v["q3_return_pct_reported"],"source_ids":[source_ids[s] for s in v["source_ids"] if s in source_ids],
                  "gap_note":"当前同日估值、容量上限、全部季报后人员及交易公告覆盖未齐。"})
    if f["origin"]!="new":
        group_names={"growth":"成长主动","flexible_value":"灵活价值","resource_rotation":"资源/产业轮动","quality":"企业质量","value":"价值主动","global":"全球股票","global_technology":"海外科技","manufacturing_growth":"制造成长","index":"指数参照","gold":"黄金参照","dividend":"红利策略","quant":"量化策略"}
        category=f.get("category") or "现有研究"
        f.update({"status":"现池基线" if f["origin"]=="existing" else "市场参照","group":group_names.get(category,category if re.search(r"[\u4e00-\u9fff]",category) else "现有研究"),
                  "why":f.get("thesis") or "用于检验主动基金和新候选的收益、损失与成本。",
                  "counter":f.get("risk") or "指数/资产参照也有市场风险，不保证对冲。",
                  "replace":"本轮比较基线，不因保留就等于验证最优。","trigger":"新增证据、成本和相同风险预算支持替换时改判。",
                  "failure":"与既定职责不符或长期扣费后没有新增价值。","source_ids":[source_ids["prior"],source_ids["nav"]]})
    else:
        sourcekeys=f.get("sources",[])
        if isinstance(sourcekeys,list) and sourcekeys and isinstance(sourcekeys[0],str):
            f["source_ids"]=[source_ids[s] for s in sourcekeys if s in source_ids]
        f.setdefault("source_ids",[])
        # Full-report supplements supersede limited directory evidence.
        if "quarter-"+c+".pdf" in source_ids:
            f["source_ids"]=list(dict.fromkeys([source_ids["quarter-"+c+".pdf"]]+f["source_ids"]))
    f["source_ids"]=list(dict.fromkeys(f.get("source_ids",[])+[source_ids["nav"]]))
    f.setdefault("status","观察");f.setdefault("why","原文与多周期资料待综合判断。");f.setdefault("counter","身份、当前估值和执行须核。")
    f.setdefault("replace","资料不足，暂不替换。");f.setdefault("trigger","补齐证据后再评。");f.setdefault("failure","事实与判断机制不符。")
    f.setdefault("group","其它")
    if not f.get("fees"):
        b=f.get("basics") or {}
        fee=[str(b[k]).split("（")[0] for k in ["管理费率","托管费率","销售服务费率"] if b.get(k)]
        if fee:f["fees"]="平台费率快照（管理/托管/销售服务）："+"/".join(fee)+"；当前合同和个人申赎另核，不能视为全部成本。"
    f["evidence_note"]="现池历史研究＋共同窗口净值；本轮未将旧资料伪装为新全面核验。" if f["origin"]!="new" else "原生份额净值复算；季度原文对账状态见下。官方报告不意味着经理观点已被证明。"
    if c not in own and c not in quality_by and c not in value_by and f["origin"]=="new":raise ValueError("Missing manual assessment "+c)

# Check exactly the same Q3 against primary-report stated class performance.
checks=[]
for c,f in funds.items():
    if f["origin"]!="new" or c=="013263":continue
    original=f.get("q3_return")
    p=R/"raw"/f"quarter-{c}.txt"
    if p.exists():
        s=re.sub(r"\s+"," ",p.read_text())
        if original is None:
            m=re.search(r"过去\s*三\s*个\s*月\s+(-?\d+(?:\.\d+)?)\s*%",s)
            if m:original=float(m.group(1))
    if original is not None:
        calc=f["metrics"]["2026Q3"]["return"]*100
        check={"code":c,"official_q3_pct":original,"calculated_pct":calc,"difference_pp":calc-original,"match":abs(calc-original)<.015}
        f["quarter_check"]=check;checks.append(check)
        if not check["match"]:f["evidence_note"]="季度原文与净值重算存在待解决差异，不升级为可执行候选。";f["status"]="数据待核"
    else:f["evidence_note"]="已取得原文，但季度对应份额的数值尚未完成自动对账；不冒充全历史双源核验。"
    f.setdefault("gap_note","最新全部重仓估值、盈利一致预期、完整持有人现金流与实际渠道未齐。")

priority={"006624":0,"519702":1,"007466":2,"161125":3,"007343":4,"011437":5}
for c,f in funds.items():f["order"]=priority.get(c,{"候选":6,"候选待执行":7,"卫星观察":8,"观察":10,"对照保留":15,"现池基线":20,"市场参照":25,"同产品份额":30,"隔离对照":35,"暂不纳入":40,"排除":99}.get(f["status"],50))

# Attributable current segment, separately from product trailing periods.
for c,f in funds.items():
    if c not in C["funds"]:continue
    start=None;mode="平台记录的当前阶段，原公告覆盖另核"
    if c in value_by:start=value_by[c]["manager"]["current_sole_segment_start"];mode="原文/人员资料支持的现任独管阶段"
    elif c in quality_by:
        current=[s for s in quality_by[c]["stages"] if s.get("end") is None]
        if current:
            st=max(current,key=lambda s:s["start"]);start=st["start"];mode="现共管阶段" if st.get("mode") in ["co","co-managed","comanaged","co_management"] or len(st.get("managers",[]))>1 else "现任独管阶段"
    elif isinstance(f.get("tenure"),list):
        current=[s for s in f["tenure"] if s.get("end") in [None,"至今","--"]]
        if current:start=max(current,key=lambda s:s["start"])["start"]
    if start:
        rows=[x for x in C["funds"][c]["nav"] if start<=x[0]<=A["nav_cutoff"]]
        if len(rows)>=3:
            wealth=np.array([x[2]/rows[0][2] for x in rows])
            f["stage_metrics"]={"start":rows[0][0],"end":rows[-1][0],"n":len(rows)-1,"return":float(wealth[-1]-1),
                               "mdd":float(np.min(wealth/np.maximum.accumulate(wealth)-1)),"mode":mode,
                               "note":"从任职日起首个可得收盘净值计算，不是经理任职当日交易归因或能力因果证明。"}

# Dated, one-seat counterfactuals. Same public-NAV intersection, no invented long L5 record.
def calc(w):
    nav={c:pd.Series([x[1] for x in funds[c]["curve"]],index=pd.to_datetime([x[0] for x in funds[c]["curve"]])) for c in w}
    frame=pd.concat(nav,axis=1).dropna().loc["2026-04-15":A["nav_cutoff"]]
    wealth=sum(frame[c]/frame[c].iloc[0]*v/100 for c,v in w.items())
    ar=wealth.to_numpy();r=ar[1:]/ar[:-1]-1;dd=ar/np.maximum.accumulate(ar)-1
    return {"start":str(frame.index[0].date()),"end":str(frame.index[-1].date()),"return":float(ar[-1]-1),"mdd":float(dd.min()),"vol":float(np.std(r,ddof=1)*np.sqrt(252))}
base=A["reference"]["weights"]
experiments=[]
for name,out,inc,w in [
    ("当前五基金","022415","022415",20),
    ("玉衡替换前海20%","022415","006624",20),
    ("交银趋势替换产业15%","021180","519702",15),
    ("红利低波替换前海10%","022415","007466",10),
    ("开阳替换高鑫25%","011066","011437",25),
    ("标普替换环球10%（暂停申购）","027170","161125",10)]:
    weights=dict(base);weights[out]-=w;weights[inc]=weights.get(inc,0)+w;weights={c:x for c,x in weights.items() if x>0}
    experiments.append({"name":name,"weights":weights,"metrics":calc(weights)})

statuses=sorted({f["status"] for f in funds.values() if f["status"]!="排除"})
data={"asof":"2026-11-22","nav_cutoff":A["nav_cutoff"],"periods":A["periods"],
      "period_labels":{"1M":"一个月","3M":"三个月","6M":"六个月","1Y":"一年","2Y":"两年","3Y":"三年","5Y":"五年"},
      "funds":funds,"sources":SOURCES,"reference":A["reference"],"experiments":experiments,"quarter_checks":checks,
      "coverage":{"directory_share_classes":universe["total_share_classes"],"discovery_rows":9726,
                  "added_share_classes":41,"added_underlying_products":40,"existing":31,"benchmarks":4,"identity_exclusion":1,
                  "q3_reconciled":sum(x["match"] for x in checks)},
      "limitations":["不是全市场穷尽审查，存续与人工选样偏差保留。","净值单一平台，原报季度对账不等于每一日独立审计。",
                     "所有长周期是产品/份额路径，经理阶段另列。","当前组合仅4月以来的共同历史，不构造三年组合战绩。",
                     "宏观场景是条件推演，不给无依据概率/收益目标。","本轮没有完成所有重仓同日估值及所有渠道执行确认，因此候选入池不等于立即交易。"]}
data["excluded_identity"]=funds["013263"]
# Preserve only fields consumed by the report and traceable downloadable data.
for f in funds.values():f.pop("sources",None);f.pop("events",None)
(OUT/"assets/report-data.js").write_text("window.MARKET_REVIEW="+json.dumps(data,ensure_ascii=False,separators=(",",":"),allow_nan=False).replace("</","<\\/")+";\n")
(OUT/"review-data.json").write_text(json.dumps(data,ensure_ascii=False,separators=(",",":"),allow_nan=False))
(R/"complete-checks.json").write_text(json.dumps(checks,ensure_ascii=False,indent=2))
(R/"experiments.json").write_text(json.dumps(experiments,ensure_ascii=False,indent=2))

e=html.escape
def cite(key):return f'<sup><a href="#cite-{source_ids[key]}">[{source_ids[key]}]</a></sup>'
def percent(x):return f'{x:+.2%}'
def refs_for(c):return "".join(f'<sup><a href="#cite-{i}">[{i}]</a></sup>' for i in funds[c]["source_ids"][:2])
newrows=[f for f in funds.values() if f["origin"]=="new" and f["status"]!="排除"]
short_html=""
for c,heading in [("006624","价值席第一挑战者"),("519702","产业席第一挑战者"),("007466","规则型红利备选"),("161125","海外工具备选 · 暂不可执行"),("007343","成长卫星观察"),("011437","原池仍最强的核心竞争者")]:
    f=funds[c];m=f["metrics"]["3Y"]
    short_html+=f'<article class="decision"><span class="label">{heading} · {e(f["status"])}</span><h3>{e(f["name"])} <small>{c}</small></h3><p><strong>{e(f["why"])}</strong>{refs_for(c)}</p><p>{e(f["replace"])}</p><p class="negative">{e(f["counter"])}</p><a href="#fund-{c}" data-open="{c}">查看原文、费用与改判条件 →</a></article>'
exp_html=""
for x in experiments:
    m=x["metrics"];composition=" / ".join(funds[c]["name"]+" "+str(w)+"%" for c,w in x["weights"].items())
    exp_html+=f'<tr><td>{e(x["name"])}<div class="small">{e(composition)}</div></td><td class="num">{percent(m["return"])}</td><td class="num">{percent(m["mdd"])}</td><td class="num">{m["vol"]:.2%}</td></tr>'
scenarios=[
 ("弱内需持续，信用仍稳定","工业与出口未完全传到消费和民间投资；融资增长不等于终端付款。","玉衡/交银趋势需验证成本、供给出清与现金回收；红利可参与，但必须核分红。","不能把低估值、银行股息或经理低仓位当硬保护。","macro-stats.html"),
 ("财政传导与盈利修复","连续至少两期实际支出/回款改善，同时订单、利润或经营现金流有确认；两期为研究观察规则。","产业/周期候选可提升参与，先替换已有同类预算；招商核心竞争力、工银需额外地产证据。","同季回弹不证明趋势，更不能在盈利上修后忽略涨价已计入的部分。","macro-pbc.html"),
 ("海外实际利率上行","关注实际收益率、期限溢价及估值调整。联邦基金利率不等同实际利率；本轮只核政策基准。","缩减新增长久期科技风险，检查成熟企业自由现金流；资源能否受益取决于需求/成本。","标普也有大科技集中；红利也可能因贴现率和信用共同下跌。","macro-fed.html"),
 ("AI利润兑现且扩散","检验客户使用率/付费、供应商毛利和收现，区分新增订单、库存、交付与最终现金。","嘉实科技与科益/万家竞争同一卫星预算；不把平台和硬件的共同资本开支风险算成独立。","单个公司收入强或科技经理说看好，不足以支持全链条和任何买价。","doc"),
 ("信用压力外溢","逐主体利差、到期兑付、银行逾期/拨备、分红现金覆盖与理财赎回出现一致恶化。","先降总风险；停止用金融占比较高的红利低波加码防守。外部现金独立比较。","局部个案不能推出系统危机；反过来，AAA利差也不能排除低等级压力。","doc"),
 ("流动性与拥挤冲击","成交深度、申赎、仓位集中及微盘/动量因子共振，经营未变也可先跌。","量化、小盘、集中科技按共同失效方式限额；单基金分散持股不等于组合分散。","用历史相关0.1或几百只股票承诺保护，属于证据越级。","quarter-006195.pdf")]
sc_html="".join(f'<article class="scenario"><h3>{e(h)}</h3><p><strong>看什么：</strong>{e(s)}</p><p><strong>怎么用：</strong>{e(use)}</p><small>{e(no)}{cite(src)}</small></article>' for h,s,use,no,src in scenarios)
source_html="".join(f'<li id="cite-{s["id"]}"><span class="src-title">{e(s["title"])}</span> · {e(s["date"])} · {e(s["kind"])}<a class="src-url" href="{e(s["url"])}" target="_blank" rel="noopener noreferrer">{e(s["url"])}</a>{("<span>"+e(s["note"])+"</span>") if s["note"] else ""}</li>' for s in SOURCES)
options="".join(f'<option value="{e(s)}">{e(s)}</option>' for s in statuses)
period_html="".join(f'<button type="button" data-period="{k}" class="{"active" if k=="3Y" else ""}" aria-pressed="{"true" if k=="3Y" else "false"}">{v}</button>' for k,v in data["period_labels"].items())
content=f'''<!-- Generated by Trae Work -->
<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>2026.11.22 市场候选复评｜非对称研究</title><link rel="stylesheet" href="assets/report.css"></head><body>
<nav class="topnav" aria-label="研究页导航"><div class="wrap"><a href="../../index.html#current">← 当前组合</a><a class="current" href="#conclusion">2026.11.22评测</a><a href="#comparison">多周期比较</a><a href="#experiments">替换实验</a><a href="#scenarios">未来适配</a><a href="#all-reviews">逐只评审</a><a href="#method">方法与证据</a></div></nav>
<div class="wrap"><header class="hero"><div class="eyebrow">2026.11.22 / 候选池扩展评审</div><h1>市场扩池：三项候选，暂不换仓。</h1><p class="lede"><strong>优先把中泰玉衡、交银趋势、红利低波联接纳入竞争池。</strong>分别挑战价值、产业与规则红利席；嘉实科技只作成长观察。当前五基金权重暂不改，候选仍需通过买价、共同风险与执行检验。</p><div class="meta"><span>净值共同截止 2026.11.19</span><span>持仓原文截至 2026.09.30</span><span>现任/交易信息读取 2026.11.22</span><span>文档观点逐项核验，私人仓位排除</span></div>
<div class="statrow"><div class="stat"><b>9,726</b><span>混合/股票份额排名记录用于发现</span></div><div class="stat"><b>40</b><span>新增独立产品 · 41个份额</span></div><div class="stat"><b>31 + 4</b><span>现池基金＋市场参照</span></div><div class="stat"><b>{sum(x["match"] for x in checks)}/41</b><span>新评份额Q3原文与净值对账通过</span></div></div><p class="small">基金总目录28,407个份额；本轮采用策略分层＋排名发现的有限深查，不是全市场逐只穷尽。高鑫A与现有C属于同产品；另纠正1个错码并排除。{cite("universe")}{cite("ranking-hh.js")}{cite("ranking-gp.js")}</p></header>
<section id="conclusion"><div class="sectionhead"><div><h2>最终观点：三项竞争，两个边界。</h2><p>候选优先级是研究顺序。先明确它替换哪个席位，再核买价、共同风险和执行；不把较好回测变成未来第一名。</p></div></div><div class="decisions">{short_html}</div>
<div class="note"><strong>为什么没有立即重做持仓：</strong>红利低波的目标ETF金融业占净资产56.33%；玉衡股票82.02%，六个持仓各超8%；交银趋势股票65.84%，较低权益解释了部分缓冲。它们都没有解决全部共同风险。标普工具官网显示暂停申购。本轮保留原组合只表示替换证据未充分，并不认证原组合“最优”。{cite("quarter-512890.pdf")}{refs_for("006624")}{refs_for("519702")}{cite("official-161125.html")}</div></section>
<section id="comparison"><div class="sectionhead"><div><h2>同口径看收益、损失与修复。</h2><p>总回报由原生份额净值和分红复算；产品记录与现任经理能力分别审议。不拼接A/C、不填缺失收益，不把三年正收益率当未来胜率。</p></div></div>
<div class="periods" id="periods" role="group" aria-label="观察周期">{period_html}</div><div class="controls"><label>名称 / 代码 / 经理<input id="search" type="search" placeholder="例如：中泰 / 007466 / 杨金金"></label><label>范围<select id="scope"><option value="new">本轮新增及同产品份额</option><option value="existing">原31只候选</option><option value="all">全部含参照</option></select></label><label>结论<select id="status"><option value="">全部结论</option>{options}</select></label><label>排序<select id="sort"><option value="decision">评审优先级</option><option value="return">区间收益从高到低</option><option value="mdd">最大回撤从浅到深</option><option value="vol">波动从低到高</option></select></label><button type="button" id="export-json">导出当前评审</button></div><p id="count-note"></p>
<div class="table-wrap"><table id="fund-table"><thead><tr><th>基金 / 经理 / 方法</th><th>结论</th><th>所选期收益</th><th>最大回撤</th><th>年化波动</th><th>距前高</th><th>最大回撤修复日</th><th>换入10%<br>收益变化/百分点</th><th>换入10%<br>回撤变化/百分点</th><th>观察</th></tr></thead><tbody></tbody></table></div><p class="small">最后两列固定为2026.04.15—11.19的独立10%等比例换入实验，不随左侧观察周期改变；回撤变化为正表示变浅。它们不是未来收益预测。低权益产品、宽基与成长基金不能直接按收益排“能力”。{cite("nav")}</p>
<div id="curve-section"><figure class="chart-figure"><figcaption id="curve-caption">候选原生份额曲线</figcaption><div class="controls"><label>图形<select id="view-mode"><option value="return">累计收益</option><option value="drawdown">距各自前高的回撤</option></select></label><label><span>额外对照</span><span><input id="base-check" type="checkbox"> 当前五基金（历史不足会明确排除）</span></label><button id="reset-curves" type="button">恢复默认三只</button></div><div id="selected-curves" class="chartchoices"></div><p id="chart-note" role="status"></p><div class="chart" id="curves" role="img" aria-label="候选基金收益与回撤图"></div></figure></div></section>
<section id="experiments"><h2>替换一席，付出什么、得到什么。</h2><p>固定共同日期2026.04.15—11.19、期初配置后自然漂移。列出完整预算，保留机会成本；不按这七个月收益机械改成最佳权重。{cite("nav")}</p><div class="table-wrap compact"><table><thead><tr><th>独立实验 / 完整配置</th><th>区间收益</th><th>最大回撤</th><th>年化波动</th></tr></thead><tbody>{exp_html}</tbody></table></div><div class="note"><strong>本轮不会据此直接换仓：</strong>玉衡替换后的收益优势只有约0.02个百分点，远不足以压倒交易费和样本误差；交银趋势替产业在本窗口明显损失收益、最大回撤也未改善，只保留为不同周期选股方法的候选。红利小幅改善路径，但金融集中不能忽略。开阳仍是原池中最强的反证之一。候选优先级不等于立即替换优先级。</div><p class="small">没有真实账户流水；均为研究回放。净值已含日常运作费，申赎/转换、QDII在途、个人浮动管理费等另核。安信价值精选存在额外浮动管理费，不能仅用净值称“最终到手”。</p></section>
<section id="scenarios"><h2>未来适配：机制、触发与反证。</h2><p>宏观决定总风险，基金方法决定委托方式。以下为条件推演，无虚构概率、点位、收益目标或自动买卖阈值。</p><div class="scenario-grid">{sc_html}</div>
<div class="note"><strong>Doc100真正提供的增量：</strong>财政融资→实际支付→企业收现；AI技术进步→客户付费→供应商利润；高分红→现金覆盖。它没有证明七成现金最优，也没有证明某基金必须买卖。私人账户、外部AI分数不进入本轮判断。{cite("doc")}</div></section>
<section id="all-reviews"><div class="sectionhead"><div><h2>逐只评审：只写会改变决策的内容。</h2><p>跟随上方搜索与结论过滤。每只包含角色、替换对象、任期、持仓/规模、费用、缺项及改判条件；无经理总分。</p></div><div class="linkrow"><button id="all-open" type="button">全部展开</button><button id="all-close" type="button">全部收起</button></div></div><div id="reviews" class="reviewcards"></div></section>
<section id="action"><h2>下一步只做三件事。</h2><div class="steps"><div><h3>1. 价值席做竞争</h3><p>先将玉衡与前海放在相同权益强度、估值及永久损失条件下比较；玉衡与原池星元同为姜诚，不因两个产品名增加分散。</p></div><div><h3>2. 产业席看兑现</h3><p>交银趋势对产业机遇，观察产能退出、订单/毛利/收现和持仓流动性。不能只因最近下跌较少而换仓。</p></div><div><h3>3. 红利与海外先过执行关</h3><p>红利先穿透银行/资源总风险；海外先核额度与费用。暂停申购时不自动改买高溢价LOF或科技QDII。</p></div></div><p class="small">下一正式复核：新的季度持仓/经理变更/交易状态变化优先触发；期间按两个非重叠月度窗口记录净值相对表现，不因一天涨跌推翻整个委托结构。当前份额费率需按你的实际持有期限和渠道选择。</p></section>
<section id="method" class="method"><h2>口径与覆盖边界。</h2><details open><summary>筛选范围与选择偏差</summary><p>读取全部公开代码目录28,407个份额，以及混合8,625＋股票1,101条排名记录。按价值/质量成长/周期/量化/指数/海外/偏债分层选35个初始代码，再加入6个三年排名发现样本；纠正招商错码后实际评审41个份额，其中高鑫A与原C是同产品，因此新增40个产品。原31只与4参照作为基线。未声称对其它全部份额的持仓、任期、估值做完整审计。存续者偏差、人工选样和事后观察均保留。</p></details>
<details><summary>收益、回撤、分红与经理归因</summary><p>一个月至五年按日历月回退，起点取此前最近可得净值。收益为复权财富变化；最大回撤由完整窗口峰谷计算，窗口起点归1；年化波动为日收益样本标准差×√252。净值缺失不填0；远期日期剔除。分红/拆分事件使用平台日回报，原季报对账验证季度汇总，但不冒充每个历史日双源审计。完整财富序列与程序在证据包。</p><p>原生份额不足对应周期则留空；经理加入、共管、独管、合同变更单列。当前五基金共有历史从2026.04.15开始，不能据此证明完整牛熊。滚动12月窗口高度重叠，其正收益占比不是独立样本胜率。</p></details>
<details><summary>费用、规模与指数穿透</summary><p>股票占总资产与占净资产分别注明；A类规模与全产品规模分开。基金内部存款不等于外部现金；ETF联接穿透目标股票基金。基金净值已扣日常运作费，交易和持有人特有费用另核，不重复扣费。官网展示与平台口径冲突时，保留原文分母和日期；官方页面的供数小部件也未必是独立信源。</p></details>
<details><summary>为什么没有综合评分、未来概率或自动最优权重</summary><p>本轮判断按角色是否新增、跨期路径、现任可归因性、集中/共同风险、成本/容量、当前买价与执行六个维度。缺项不能用其它维度高分抵消，管理人分数不进入权重。历史最好的一组参数容易过拟合；预测概率、完整一致预期和所有重仓同日估值未齐，因此只给有反证的候选与条件。</p></details>
<details><summary>失败与冲突记录</summary><p>部分基金档案接口返回514限流，已停止高频重试并转向原报告；缺失元数据保留，不静默补齐。代码013263实际为金鹰债券，已排除并改用招商014412。高鑫A/C不计作两种策略。许多基金已换经理/共管，旧标签不继续套用。完整记录与来源哈希在证据包。日审模型仍未完成，不将本次静态页面声称为全自动实时研究。</p></details>
<div class="linkrow"><a href="evidence.zip" download>净值、提取文本与复算包</a><a href="primary-reports.zip" download>原始季报与说明书PDF包</a><a href="review-data.json" download>结构化评测</a><a href="../../index.html#workbench">自定义组合实验</a></div></section>
<footer><div class="sources"><details><summary>展开原始来源（{len(SOURCES)}项；同源转载不重复计算独立性）</summary><ol>{source_html}</ol></details></div><p class="small">冻结版本 2026.11.22。此页按日期留档；以当日可得证据判断，后续改判应新增版本并说明原因。</p></footer></div>
<script src="./_shared/js/echarts.min.js"></script><script src="assets/report-data.js"></script><script src="assets/charts.js"></script></body></html>'''
(OUT/"2026-11-22.html").write_text(content)
skill=Path("/Users/bytedance/.trae-cn/plugins/trae-remote-official/html-report-presentation/0.1.0/skills/html-report")
shutil.copyfile(skill/"assets/js/echarts.min.js",OUT/"_shared/js/echarts.min.js")
shutil.copyfile(skill/"canvas-fonts/DMMono-Regular.ttf",OUT/"_shared/fonts/DMMono-Regular.ttf")
shutil.copyfile(skill/"canvas-fonts/DMMono-OFL.txt",OUT/"_shared/fonts/DMMono-OFL.txt")
summary={"date":"2026-11-22","title":"市场扩池评测","path":"reviews/2026-11-22/2026-11-22.html","added_products":40,"assessed_share_classes":41,
 "primary_candidates":["006624","519702","007466"],"satellite_watch":["007343"],"overseas_unavailable":["161125"],"current_portfolio_change":False,
 "conclusion":"新增玉衡、交银趋势与红利低波作为席位竞争者；当前五基金不自动改权重。海外工具暂停申购，科技只留卫星观察。",
 "q3_checks_passed":sum(x["match"] for x in checks),"latest_nav":"2026-11-19","holdings_asof":"2026-09-30"}
(R/"review-summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(json.dumps({"funds":len(funds),"new_evaluated":len(newrows),"checks":len(checks),"passed":sum(x["match"] for x in checks),"sources":len(SOURCES),"html":str(OUT/"2026-11-22.html"),"experiments":experiments},ensure_ascii=False))
