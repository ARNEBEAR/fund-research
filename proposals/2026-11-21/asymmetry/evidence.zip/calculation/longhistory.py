import json,re,datetime,urllib.request,concurrent.futures
from pathlib import Path
import pandas as pd,numpy as np
from bs4 import BeautifulSoup
P=Path('/tmp/fund-research-20261121');V=P/'verified'
codes=['001856','519212','217017','000477','005775','001162','160613','001564','012196']
def run(c):
    try:
        url=f'https://fund.eastmoney.com/pingzhongdata/{c}.js'
        raw=urllib.request.urlopen(url,timeout=30).read();(V/f'history-{c}.js').write_bytes(raw)
        s=raw.decode('utf-8-sig');m=re.search(r'var\s+Data_netWorthTrend\s*=\s*(\[.*?\])\s*;',s,re.S)
        if not m:return c,'missing array'
        data=json.loads(m.group(1));name=re.search(r'var\s+fS_name\s*=\s*"(.*?)"',s)
        rows=[];prev=None;wealth=1
        for row in data:
            dt=datetime.datetime.fromtimestamp(row['x']/1000,datetime.timezone(datetime.timedelta(hours=8))).strftime('%Y-%m-%d')
            if dt>'2026-11-21':continue
            n=float(row['y']);vendor=float(row.get('equityReturn') or 0)/100
            if prev is None:r=0
            elif not row.get('unitMoney'):r=n/prev-1
            else:r=vendor
            # Split adjustments and non-dividend events are explicitly handled by the vendor.
            if prev and abs(r-vendor)>.03:r=vendor
            wealth*=1+r;rows.append({'date':dt,'nav':n,'return':r,'wealth':wealth,'event':row.get('unitMoney','')});prev=n
        pd.DataFrame(rows).to_csv(V/f'long-{c}.csv',index=False)
        return c,name.group(1) if name else '',len(rows),rows[0]['date'],rows[-1]['date']
    except Exception as e:return c,str(e)
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:print(list(pool.map(run,codes)))
def metric(r):
    w=np.r_[1,(1+r).cumprod().values];return {'n':len(r),'start':r.index[0],'end':r.index[-1],'return':float(w[-1]-1),
    'mdd':float((w/np.maximum.accumulate(w)-1).min()),'vol':float(r.std()*np.sqrt(252))}
frames={c:pd.read_csv(V/f'long-{c}.csv').set_index('date') for c in codes if (V/f'long-{c}.csv').exists()}
out={}
for c,df in frames.items():
    out[c]={}
    for yr in range(2019,2027):
        r=df.loc[df.index.str.startswith(str(yr)),'return']
        if len(r):out[c][str(yr)]=metric(r)
    for k,lo in [('3Y','2023-11-21'),('1Y','2025-11-21')]:
        r=df.loc[df.index>=lo,'return']
        if df.index[0]<lo:out[c][k]=metric(r)
own=pd.concat({c:frames[c]['return'] for c in ['217017','001856','519212']},axis=1).dropna()
w=np.array([190300.66,328836.42,339683.44]);w/=w.sum()
out['screenshot_static']={}
for lab,lo in [('3Y','2023-11-21'),('1Y','2025-11-21'),('YTD','2026-01-01')]:
    a=own.loc[own.index>=lo];r=pd.Series(a.values@w,index=a.index)
    bhwealth=((1+a).cumprod()*w).sum(axis=1);bhr=bhwealth.pct_change();bhr.iloc[0]=bhwealth.iloc[0]-1
    out['screenshot_static'][lab]={'fixed_weight':metric(r),'buyhold':metric(bhr),'dates':list(a.index),
    'curve':list(map(float,(1+r).cumprod()-1)),'bhcurve':list(map(float,bhwealth-1))}
(P/'long-analysis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print('Screenshot',[(k,{z:v for z,v in x.items() if z in ['fixed_weight','buyhold']}) for k,x in out['screenshot_static'].items()])
