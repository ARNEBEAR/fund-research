"""Run from the extracted evidence.zip folder: python3 calculation/recompute.py."""
from pathlib import Path
import json, math
import pandas as pd
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
saved=json.loads((ROOT/'calculation/results.json').read_text())
frames={f.stem.replace('clean-',''):pd.read_csv(f,dtype={'date':str}).set_index('date').sort_index()
        for f in (ROOT/'evidence').glob('clean-*.csv')}
codes=set(c for p in saved['plans'].values() for c in p['weights'])
returns=pd.concat({c:frames[c]['return'].astype(float) for c in codes},axis=1).dropna()
def metric(r):
    wealth=np.r_[1,(1+r).cumprod().values]
    return {'n':len(r),'start':r.index[0],'end':r.index[-1],'return':float(wealth[-1]-1),
            'mdd':float((wealth/np.maximum.accumulate(wealth)-1).min()),'vol':float(r.std(ddof=1)*math.sqrt(252))}
result={}
for key,plan in saved['plans'].items():
    cs=list(plan['weights']);w=np.array([plan['weights'][c] for c in cs])
    rp=pd.Series(returns[cs].values@w,index=returns.index)
    result[key]=metric(rp)
    for name in ['return','mdd','vol']:
        if not math.isclose(result[key][name],plan['common'][name],abs_tol=1e-8):
            raise AssertionError(f'{key} {name} does not reproduce the frozen report')
    if not math.isclose(float(w.sum()),1,abs_tol=1e-12):raise AssertionError('weights do not sum to one')
print(json.dumps(result,ensure_ascii=False,indent=2))
print('All common-date returns, drawdowns, volatilities and weight budgets reproduce within 1e-8.')
