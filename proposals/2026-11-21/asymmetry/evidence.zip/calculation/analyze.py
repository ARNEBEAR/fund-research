import json, math, re, hashlib
from pathlib import Path
import numpy as np
import pandas as pd

P=Path('/tmp/fund-research-20261121')
R=P/'fund-research-main'
V=P/'verified'
N=P/'latest-dataset/data/ideal_review/2026-11-21/nav'
J=R/'proposals/2026-11-20/judgment'
cards=json.loads((J/'analysis.json').read_text())['cards']
for card in cards:
    if card['code']=='027170':
        card['q3_equity_pct']=78.13+9.69  # Primary Q3 p9/12: direct equity plus NASDAQ ETFs, on NAV.
names={x['code']:x['name'] for x in cards}
frames={}
freshchecks=[]
for folder in [J/'evidence',N]:
    for f in folder.glob('*.csv'):
        if re.fullmatch(r'\d{6}',f.stem):
            df=pd.read_csv(f,dtype={'date':str}).set_index('date').sort_index()
            # Inception has no preceding investable observation: never treat its synthetic zero as a return.
            df.iloc[0,df.columns.get_loc('return')]=np.nan
            frames[f.stem]=df
for code,df in list(frames.items()):
    f=V/f'nav-{code}.json'
    if not f.exists():continue
    d=json.loads(f.read_text())
    rows=(d.get('Data') or {}).get('LSJZList') or []
    for row in sorted(rows,key=lambda x:x['FSRQ']):
        date=row['FSRQ']
        if date>'2026-11-21':continue
        nav=float(row['DWJZ']);cum=float(row['LJJZ']);p_return=float(row['JZZZL'])/100 if row.get('JZZZL') else 0
        if date in df.index:
            freshchecks.append({'code':code,'date':date,'match':abs(float(df.loc[date,'unit_nav'])-nav)<1e-7})
        else:
            prev=df.loc[df.index<date].iloc[-1]
            # Ordinary distribution increments use reinvestment. A negative cumulative increment is flagged.
            dist=(cum-nav)-(float(prev['cumulative_nav'])-float(prev['unit_nav']))
            ret=(nav+max(0,dist))/float(prev['unit_nav'])-1 if dist>=-1e-6 else p_return
            df.loc[date]=[nav,cum,ret,p_return,'fresh_nav_plus_dividend' if dist>=-1e-6 else 'vendor_event_return', '',float(prev['wealth'])*(1+ret)]
    frames[code]=df.sort_index()

def metric(r):
    r=r.dropna()
    w=(1+r).cumprod()
    w0=np.r_[1,w.values]
    dd=w0/np.maximum.accumulate(w0)-1
    return {'n':len(r),'start':str(r.index[0]),'end':str(r.index[-1]),
            'return':float(w.iloc[-1]-1),'mdd':float(dd.min()),
            'vol':float(r.std(ddof=1)*np.sqrt(252))}

metrics={}
nodes={}
for code,df in frames.items():
    rr=df['return'].astype(float)
    metrics[code]={}
    for n in [5,10,20,60,120,252]:
        if len(rr)>n:metrics[code][str(n)]=metric(rr.iloc[-n:])
    for label,start in [('YTD','2026-01-01'),('3Y','2023-11-21')]:
        if rr.index[0]<start:metrics[code][label]=metric(rr.loc[rr.index>=start])
    nodes[code]=[{'date':dt,'nav':float(x['unit_nav']),'return':float(x['return'])}
                 for dt,x in df.tail(8).iterrows()]

benchmark_codes=['510300','515880','510880','512400','512010','512480']
bench=pd.concat({c:frames[c]['return'].astype(float) for c in benchmark_codes},axis=1).dropna()
fitcodes=['022415','021902','021180','010390','022714','011370','519697','011066','008270','019032','017787']
fits={}
for c in fitcodes:
    data=pd.concat([frames[c]['return'].rename('fund').astype(float),bench],axis=1).dropna()
    fits[c]={}
    for n in [60,120]:
        a=data.tail(n)
        # Industry contrasts reduce double counting the broad market.
        X=np.column_stack([np.ones(len(a)),a['510300']]+[(a[b]-a['510300']).values for b in benchmark_codes[1:]])
        y=a['fund'].values
        b=np.linalg.lstsq(X,y,rcond=None)[0];e=y-X@b
        fits[c][str(n)]={'n':len(a),'start':a.index[0],'end':a.index[-1],
                         'coef':dict(zip(['const','market','communication_excess','dividend_excess','metal_excess','medical_excess','semi_excess'],map(float,b))),
                         'r2':float(1-np.sum(e*e)/np.sum((y-y.mean())**2)),
                         'residual_std':float(e.std(ddof=1)),
                         'condition':float(np.linalg.cond(X[:,1:]))}
    # Frozen 60-day model before November; November becomes a genuine holdout for this specification.
    train=data.loc[data.index<='2026-10-30'].tail(60)
    test=data.loc[data.index>='2026-11-02']
    def xmat(a):
        return np.column_stack([np.ones(len(a)),a['510300']]+[(a[b]-a['510300']).values for b in benchmark_codes[1:]])
    b=np.linalg.lstsq(xmat(train),train['fund'].values,rcond=None)[0]
    pred=xmat(test)@b;e=test['fund'].values-pred
    fits[c]['holdout']={'train_end':train.index[-1],'test_start':test.index[0],'test_end':test.index[-1],
                       'n':len(test),'actual':float(np.prod(1+test['fund'].values)-1),
                       'mapped':float(np.prod(1+pred)-1),'residual_sum':float(e.sum()),
                       'rmse':float(np.sqrt(np.mean(e*e)))}
    fits[c]['windows']={}
    for lab,lo,hi in [('Q3','2026-07-01','2026-09-30'),('Oct','2026-10-01','2026-10-30'),('Nov','2026-11-02','2026-11-20')]:
        a=data.loc[(data.index>=lo)&(data.index<=hi)]
        fits[c]['windows'][lab]={'n':len(a),'return':float(np.prod(1+a['fund'])-1),
                              'communication_correlation':float(a['fund'].corr(a['515880'])),
                              'metal_correlation':float(a['fund'].corr(a['512400'])),
                              'medical_correlation':float(a['fund'].corr(a['512010']))}

plans={
 'A':{'022415':50,'021902':40,'011066':30,'021180':25,'010390':20,'022714':25,'027170':25,'519697':15},
 'B':{'022415':45,'021902':30,'011066':30,'021180':25,'010390':30,'022714':30,'027170':40},
 'DS1':{'021180':30,'010390':30,'008270':60,'022415':50,'021902':35,'027170':15,'022184':10},
 'DS2_raw':{'019032':50,'017787':30,'021180':30,'022415':60,'004407':30,'021902':30,'027170':10},
 'Screenshot_proxy':{'004407':190300.66,'019032':328836.42,'017787':339683.44},
 'ARNE_5':{'022415':30,'021902':30,'021180':15,'011066':15,'012817':10}
}
planout={}
commoncodes=set(c for pl in plans.values() for c in pl)
allreturns=pd.concat({c:frames[c]['return'].astype(float) for c in commoncodes},axis=1).dropna()
end=allreturns.index[-1]
for key,pl in plans.items():
    codes=list(pl);weight=np.array(list(pl.values()),dtype=float);weight/=weight.sum()
    a=allreturns[codes];rp=pd.Series(a.values@weight,index=a.index)
    # Buy and hold: only initial weights are fixed; all weights subsequently drift.
    total=(((1+a).cumprod())*weight).sum(axis=1)
    bh=total.pct_change()
    bh.iloc[0]=float(total.iloc[0]-1)
    cov=a.tail(60).cov().values;variance=float(weight@cov@weight)
    rc=weight*(cov@weight)/variance
    eqs={c:next((x.get('q3_equity_pct',0) for x in cards if x['code']==c),0)/100 for c in codes}
    out={'amounts':pl,'total':sum(pl.values()),'weights':dict(zip(codes,map(float,weight))),
         'equity_q3':float(sum(weight[i]*eqs[c] for i,c in enumerate(codes))),
         'common':metric(rp),'buyhold_common':metric(bh),
         'risk_contribution_60':dict(zip(codes,map(float,rc))),
         'metrics':{},'dates':list(rp.index),'curve':list(map(float,(1+rp).cumprod()-1))}
    for lab,lo in [('Nov','2026-11-02'),('Oct','2026-10-01')]:
        r=rp.loc[rp.index>=lo]
        if len(r)>1:out['metrics'][lab]=metric(r)
    for n in [20,60,120]:
        if len(rp)>=n:out['metrics'][str(n)]=metric(rp.tail(n))
    # Separate long histories for each configuration, avoiding hypothetical share class backfill.
    own=pd.concat({c:frames[c]['return'].astype(float) for c in codes},axis=1).dropna()
    ownrp=pd.Series(own.values@weight,index=own.index)
    for lab,lo in [('YTD','2026-01-01'),('1Y','2025-11-21'),('3Y','2023-11-21')]:
        out['metrics'][lab]=metric(ownrp.loc[ownrp.index>=lo]) if own.index[0]<lo else None
    planout[key]=out

corr={lab:allreturns.tail(n).corr().to_dict() for lab,n in [('20',20),('60',60),('120',120)]}
paircodes=['021902','008270','011066','519697','022415','021180','010390','022714','011370','019032','017787']
pair=pd.concat({c:frames[c]['return'].astype(float) for c in paircodes},axis=1).dropna()
pairs={str(n):pair.tail(n).corr().to_dict() for n in [20,60,120]}
stress={ '分化磨底':[0,0,-.01,-.02,-.01,-.02],
         '盈利与科技修复':[.05,.12,0,.03,.04,.07],
         '增长担忧':[ -.07,-.13,-.03,-.12,-.08,-.10],
         '利率与估值再压缩':[-.08,-.14,-.07,-.07,-.10,-.11]}
# Scenarios are user-inspectable shocks, never calibrated probabilities. Overseas is a direct assumed sleeve response.
scenarios={}
for sk,shocks in stress.items():
    mapped={}
    for c in fitcodes:
        f=fits[c]['60']['coef']
        keys=['market','communication_excess','dividend_excess','metal_excess','medical_excess','semi_excess']
        mapped[c]=float(f['market']*shocks[0]+sum(f[k]*(shocks[i]-shocks[0]) for i,k in enumerate(keys[1:],1)))
    mapped['027170']={'分化磨底':-.01,'盈利与科技修复':.07,'增长担忧':-.09,'利率与估值再压缩':-.12}[sk]
    mapped['022184']={'分化磨底':-.025,'盈利与科技修复':.11,'增长担忧':-.14,'利率与估值再压缩':-.17}[sk]
    scenarios[sk]={'shocks':shocks,'fund_response':mapped,'plans':{}}
    for key in ['A','B','DS1']:
        estimates=[]
        for n in ['60','120']:
            tot=0
            for c,w in planout[key]['weights'].items():
                if c in fits:
                    f=fits[c][n]['coef'];keys=['market','communication_excess','dividend_excess','metal_excess','medical_excess','semi_excess']
                    val=f['market']*shocks[0]+sum(f[k]*(shocks[i]-shocks[0]) for i,k in enumerate(keys[1:],1))
                else:val=mapped[c]
                tot+=w*val
            estimates.append(float(tot))
        scenarios[sk]['plans'][key]={'low':min(estimates),'high':max(estimates),'center':estimates[0]}

data={'asof':'2026-11-21','names':names,'metrics':metrics,'nodes':nodes,'fits':fits,'plans':planout,
      'corr':corr,'pairs':pairs,'scenarios':scenarios,'fresh_verification':{'matched':sum(x['match'] for x in freshchecks),
      'checked':len(freshchecks),'mismatches':[x for x in freshchecks if not x['match']]},
      'benchmark_codes':benchmark_codes,'common_start':allreturns.index[0],'common_end':end}
(P/'analysis.json').write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False))
print('freshcheck',data['fresh_verification'])
for k,v in planout.items():print(k,'total',v['total'],'equity',v['equity_q3'],'common',v['common'],'YTD',v['metrics']['YTD'])
print('pairs60',[(x,y,round(pairs['60'][x][y],3)) for x,y in [('021902','008270'),('021902','011066'),('010390','011370'),('010390','022714'),('019032','017787'),('021902','519697')]])
for s,x in scenarios.items():print(s,x['plans'])
for c,f in fits.items():print('HOLDOUT',c,f['holdout'])
for c,df in frames.items():df.to_csv(V/f'clean-{c}.csv')
