非对称 · 230万持有人独立研究
研究日期：2026-11-21
直接打开 index.html；无外部字体、图片或脚本依赖。
网页包含冻结研究、情景算术、共同期回放、经理档案和本地观察簿。
本地观察记录只保存在当前浏览器，导出后自行保管。

evidence.zip：
原始正式净值JSON、清洗总回报CSV、原文PDF与文本、来源及SHA256、计算脚本。
原始对话与用户/第三人的持仓图片不在证据包。
分红/事件口径参考CSV的method字段；新检索一致性不等于独立来源认证。

复算方法：
1. 解压 evidence.zip 到任意文件夹。
2. 安装 Python 包：python3 -m pip install numpy pandas
3. 执行：python3 calculation/recompute.py
独立复算脚本使用 evidence/clean-*.csv 校验相同146个日收益的全部配置。
analyze.py与longhistory.py是归档研究管线，包含本次运行的临时路径；
原始输入保存在inputs/与evidence/nav-*.json，便于核验清洗口径。
